import { PrismaClient } from '@prisma/client'
import { hash } from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  // ⚠️ IMPORTANT: This seed only creates categories and settings
  // It does NOT delete existing users or data
  
  // Check if admin user already exists
  const adminExists = await prisma.user.findUnique({
    where: { email: 'admin@gfxstore.com' }
  })
  
  // Only create admin user if it doesn't exist
  if (!adminExists) {
    const hashedPassword = await hash('admin123', 10)
    await prisma.user.create({
      data: {
        email: 'admin@gfxstore.com',
        username: 'admin',
        password: hashedPassword,
        role: 'ADMIN',
        isActive: true,
      },
    })
    console.log('✅ Admin user created: admin@gfxstore.com / admin123')
  }
  
  // Check if Akash admin user exists
  const akashExists = await prisma.user.findUnique({
    where: { email: 'kakmare.pa@gmail.com' }
  })
  
  // Create Akash admin user if it doesn't exist
  if (!akashExists) {
    const hashedPassword = await hash('akash9x1', 10)
    await prisma.user.create({
      data: {
        email: 'kakmare.pa@gmail.com',
        username: 'akash9x1',
        password: hashedPassword,
        role: 'ADMIN',
        isActive: true,
      },
    })
    console.log('✅ Akash admin user created: kakmare.pa@gmail.com / akash9x1')
  }
  
  // Create categories
  const categories = [
    {
      name: 'Plugins',
      slug: 'plugins',
      description: 'Server plugins for Bukkit, Spigot, Paper, and more',
      icon: 'plugin',
      background: 'plugins-bg.jpg',
      sortOrder: 1,
    },
    {
      name: 'Mods',
      slug: 'mods',
      description: 'Client-side and server-side mods for Minecraft',
      icon: 'mod',
      background: 'mods-bg.jpg',
      sortOrder: 2,
    },
    {
      name: 'Texture Packs',
      slug: 'texture-packs',
      description: 'Custom textures and resource packs',
      icon: 'texture',
      background: 'textures-bg.jpg',
      sortOrder: 3,
    },
    {
      name: 'Maps',
      slug: 'maps',
      description: 'Custom maps and worlds',
      icon: 'map',
      background: 'maps-bg.jpg',
      sortOrder: 4,
    },
    {
      name: 'Shaders',
      slug: 'shaders',
      description: 'Visual enhancement shaders',
      icon: 'shader',
      background: 'shaders-bg.jpg',
      sortOrder: 5,
    },
    {
      name: 'Server Setups',
      slug: 'server-setups',
      description: 'Complete server configurations',
      icon: 'server',
      background: 'servers-bg.jpg',
      sortOrder: 6,
    },
  ]

  for (const categoryData of categories) {
    await prisma.category.upsert({
      where: { slug: categoryData.slug },
      update: categoryData,
      create: categoryData,
    })
  }

  // Create subcategories for plugins
  const pluginCategory = await prisma.category.findUnique({
    where: { slug: 'plugins' }
  })

  if (pluginCategory) {
    const pluginSubcategories = [
      { name: 'Economy', slug: 'economy', categoryId: pluginCategory.id },
      { name: 'Minigames', slug: 'minigames', categoryId: pluginCategory.id },
      { name: 'Utilities', slug: 'utilities', categoryId: pluginCategory.id },
      { name: 'Role-playing', slug: 'roleplaying', categoryId: pluginCategory.id },
      { name: 'World Editing', slug: 'world-editing', categoryId: pluginCategory.id },
    ]

    for (const subcategoryData of pluginSubcategories) {
      await prisma.subcategory.upsert({
        where: { slug: subcategoryData.slug },
        update: subcategoryData,
        create: subcategoryData,
      })
    }
  }

  // Create site settings
  await prisma.siteSettings.upsert({
    where: { id: 'default' },
    update: {
      siteName: 'GfxStore',
      siteLogo: '/logo.png',
      uploadLimit: 100,
    },
    create: {
      id: 'default',
      siteName: 'GfxStore',
      siteLogo: '/logo.png',
      uploadLimit: 100,
    },
  })

  console.log('Database seeded successfully!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })