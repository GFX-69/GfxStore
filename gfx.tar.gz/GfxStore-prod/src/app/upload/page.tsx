'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Upload, X, Loader2, Image as ImageIcon, Plus, Trash2 } from 'lucide-react'

export default function UploadPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const screenshotInputRef = useRef<HTMLInputElement>(null)
  const logoInputRef = useRef<HTMLInputElement>(null)
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    shortDesc: '',
    moreInfo: '',
    categoryId: '',
    price: 0,
    tags: '' as string,
    version: '1.0.0',
    gameVersion: '1.20.1',
    accessType: 'FREE',
    requiredRole: '',
  })
  const [memberships, setMemberships] = useState<any[]>([])
  
  const [files, setFiles] = useState<File[]>([])
  const [screenshots, setScreenshots] = useState<File[]>([])
  const [logo, setLogo] = useState<File | null>(null)
  const [categories, setCategories] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [uploadProgress, setUploadProgress] = useState(0)
  const [screenshotPreviews, setScreenshotPreviews] = useState<Array<{ name: string; url: string; size: number }>>([])
  const [filePreviews, setFilePreviews] = useState<Array<{ name: string; url: string; size: number }>>([])
  const [logoPreview, setLogoPreview] = useState<{ url: string; name: string } | null>(null)

  useEffect(() => {
    if (status === 'loading') return
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
      return
    }
    fetchCategories()
    fetchMemberships()
    // Auto-refresh memberships every 2 seconds to show newly created ones
    const interval = setInterval(fetchMemberships, 2000)
    return () => clearInterval(interval)
  }, [status, router])

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/categories')
      if (response.ok) {
        const data = await response.json()
        setCategories(data)
      }
    } catch (error) {
      console.error('Failed to fetch categories:', error)
    }
  }

  const fetchMemberships = async () => {
    try {
      const response = await fetch(`/api/memberships?t=${Date.now()}`)
      if (response.ok) {
        const data = await response.json()
        setMemberships(Array.isArray(data) ? data : data.memberships || [])
      }
    } catch (error) {
      console.error('Failed to fetch memberships:', error)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || [])
    const newFiles = [...files, ...selectedFiles]
    setFiles(newFiles)

    selectedFiles.forEach(file => {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader()
        reader.onloadend = () => {
          setFilePreviews(prev => [...prev, {
            name: file.name,
            url: reader.result as string,
            size: file.size
          }])
        }
        reader.readAsDataURL(file)
      } else {
        setFilePreviews(prev => [...prev, {
          name: file.name,
          url: '/placeholder-item.png',
          size: file.size
        }])
      }
    })
  }

  const handleScreenshotChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || [])
    const newScreenshots = [...screenshots, ...selectedFiles]
    setScreenshots(newScreenshots)

    selectedFiles.forEach(file => {
      const reader = new FileReader()
      reader.onloadend = () => {
        setScreenshotPreviews(prev => [...prev, {
          name: file.name,
          url: reader.result as string,
          size: file.size
        }])
      }
      reader.readAsDataURL(file)
    })
  }

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index))
    setFilePreviews(prev => prev.filter((_, i) => i !== index))
  }

  const removeScreenshot = (index: number) => {
    setScreenshots(prev => prev.filter((_, i) => i !== index))
    setScreenshotPreviews(prev => prev.filter((_, i) => i !== index))
  }

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setLogo(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setLogoPreview({
          name: file.name,
          url: reader.result as string
        })
      }
      reader.readAsDataURL(file)
    }
  }

  const removeLogo = () => {
    setLogo(null)
    setLogoPreview(null)
    if (logoInputRef.current) {
      logoInputRef.current.value = ''
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!session) return

    if (!formData.title || !formData.description || !formData.categoryId || files.length === 0) {
      setError('Please fill in all required fields and upload at least one file')
      return
    }

    setLoading(true)
    setError('')

    try {
      const formDataToSend = new FormData()
      
      formDataToSend.append('title', formData.title)
      formDataToSend.append('description', formData.description)
      formDataToSend.append('shortDesc', formData.shortDesc)
      formDataToSend.append('moreInfo', formData.moreInfo)
      formDataToSend.append('categoryId', formData.categoryId)
      formDataToSend.append('price', formData.price.toString())
      formDataToSend.append('tags', formData.tags)
      formDataToSend.append('version', formData.version)
      formDataToSend.append('gameVersion', formData.gameVersion)
      formDataToSend.append('authorId', session.user.id)

      files.forEach((file) => {
        formDataToSend.append(`files`, file)
      })

      screenshots.forEach((screenshot) => {
        formDataToSend.append(`screenshots`, screenshot)
      })

      if (logo) {
        formDataToSend.append('logo', logo)
      }

      const response = await fetch('/api/items/upload', {
        method: 'POST',
        body: formDataToSend
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || 'Failed to upload item')
      } else {
        setError('')
        setTimeout(() => {
          router.push('/dashboard')
        }, 1500)
      }
    } catch (error) {
      setError('An error occurred during upload')
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container mx-auto p-6 max-w-5xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Upload Content</h1>
          <p className="text-muted-foreground text-lg">
            Share your Minecraft creations with the community
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Create New Item</CardTitle>
            <CardDescription>
              Fill in the details about your Minecraft content. All fields with * are required.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-8">
              {error && (
                <Alert variant={error.includes('successfully') ? 'default' : 'destructive'}>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Tabs defaultValue="basic" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="basic">Basic Info</TabsTrigger>
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="media">Media & Files</TabsTrigger>
                </TabsList>

                {/* Basic Information */}
                <TabsContent value="basic" className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="title">Title *</Label>
                      <Input
                        id="title"
                        value={formData.title}
                        onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                        placeholder="Enter item title"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="category">Category *</Label>
                      <Select value={formData.categoryId} onValueChange={(value) => setFormData(prev => ({ ...prev, categoryId: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category.id} value={category.id}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="shortDesc">Short Description</Label>
                    <Input
                      id="shortDesc"
                      value={formData.shortDesc}
                      onChange={(e) => setFormData(prev => ({ ...prev, shortDesc: e.target.value }))}
                      placeholder="Brief description (max 200 chars)"
                      maxLength={200}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Full Description *</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Detailed description of your content"
                      rows={6}
                      required
                    />
                  </div>
                </TabsContent>

                {/* Details Tab */}
                <TabsContent value="details" className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="gameVersion">Minecraft Version *</Label>
                      <Input
                        id="gameVersion"
                        value={formData.gameVersion}
                        onChange={(e) => setFormData(prev => ({ ...prev, gameVersion: e.target.value }))}
                        placeholder="e.g., 1.20.1"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="version">Content Version *</Label>
                      <Input
                        id="version"
                        value={formData.version}
                        onChange={(e) => setFormData(prev => ({ ...prev, version: e.target.value }))}
                        placeholder="e.g., 1.0.0"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="accessType">Access Level *</Label>
                      <Select value={formData.accessType} onValueChange={(value) => {
                        setFormData(prev => ({ 
                          ...prev, 
                          accessType: value,
                          requiredRole: value === 'ROLE' ? prev.requiredRole : '',
                          price: value === 'PAID' ? prev.price : 0
                        }))
                      }}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select access level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="FREE">🎁 Free for All</SelectItem>
                          <SelectItem value="ROLE">🔐 Membership Required</SelectItem>
                          <SelectItem value="PAID">💰 Paid Item</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {formData.accessType === 'ROLE' && (
                      <div className="space-y-2">
                        <Label htmlFor="requiredRole">Required Membership</Label>
                        <Select value={formData.requiredRole} onValueChange={(value) => setFormData(prev => ({ ...prev, requiredRole: value }))}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select membership" />
                          </SelectTrigger>
                          <SelectContent>
                            {memberships.map((m) => (
                              <SelectItem key={m.id} value={m.roleName}>
                                {m.name} - ${m.price}/month
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    {formData.accessType === 'PAID' && (
                      <div className="space-y-2">
                        <Label htmlFor="price">Price ($)</Label>
                        <Input
                          id="price"
                          type="number"
                          min="0"
                          step="0.01"
                          value={formData.price}
                          onChange={(e) => setFormData(prev => ({ ...prev, price: parseFloat(e.target.value) || 0 }))}
                          placeholder="0.00"
                        />
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="tags">Tags (comma-separated)</Label>
                    <Input
                      id="tags"
                      value={formData.tags}
                      onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value }))}
                      placeholder="e.g., survival, pvp, utility"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="moreInfo">Additional Information</Label>
                    <Textarea
                      id="moreInfo"
                      value={formData.moreInfo}
                      onChange={(e) => setFormData(prev => ({ ...prev, moreInfo: e.target.value }))}
                      placeholder="Installation instructions, requirements, compatibility notes, etc."
                      rows={5}
                    />
                  </div>
                </TabsContent>

                {/* Media & Files Tab */}
                <TabsContent value="media" className="space-y-6">
                  <div className="space-y-4">
                    {/* Logo Upload */}
                    <div className="space-y-2">
                      <Label>Item Logo/Icon (Displayed on Browse & Detail Pages)</Label>
                      <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center hover:border-muted-foreground/50 transition">
                        <ImageIcon className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                        <div className="text-lg font-medium mb-1">Upload logo or icon</div>
                        <div className="text-sm text-muted-foreground mb-4">
                          PNG, JPG, WebP (Recommended: Square image, 512x512px)
                        </div>
                        <input
                          ref={logoInputRef}
                          type="file"
                          accept="image/*"
                          onChange={handleLogoChange}
                          className="hidden"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => logoInputRef.current?.click()}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Select Logo
                        </Button>
                      </div>
                      
                      {logoPreview && (
                        <div className="flex items-center justify-between p-3 border rounded-lg bg-muted/50">
                          <div className="flex items-center gap-3 flex-1">
                            <img
                              src={logoPreview.url}
                              alt={logoPreview.name}
                              className="h-16 w-16 object-cover rounded"
                            />
                            <div className="min-w-0">
                              <p className="font-medium text-sm truncate">{logoPreview.name}</p>
                              <p className="text-xs text-muted-foreground">Logo Preview</p>
                            </div>
                          </div>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={removeLogo}
                            className="ml-2"
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      )}
                    </div>

                    {/* Main Content Files */}
                    <div className="space-y-2">
                      <Label>Main Content Files * (Your plugin, mod, texture pack, etc.)</Label>
                      <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center hover:border-muted-foreground/50 transition">
                        <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                        <div className="text-lg font-medium mb-1">Drop files here or click to browse</div>
                        <div className="text-sm text-muted-foreground mb-4">
                          Supported: .zip, .rar, .jar, .mcworld, .mcpack, .mcaddon
                        </div>
                        <input
                          ref={fileInputRef}
                          type="file"
                          multiple
                          onChange={handleFileChange}
                          className="hidden"
                          accept=".zip,.rar,.jar,.mcworld,.mcpack,.mcaddon"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => fileInputRef.current?.click()}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Select Files
                        </Button>
                      </div>
                      
                      {filePreviews.length > 0 && (
                        <div className="space-y-2">
                          <Label className="text-sm font-medium">Selected Files ({files.length}):</Label>
                          <div className="grid grid-cols-1 gap-2">
                            {filePreviews.map((file, index) => (
                              <div key={index} className="flex items-center justify-between p-3 border rounded-lg bg-muted/50">
                                <div className="flex items-center gap-3 flex-1">
                                  {file.url.startsWith('data:') ? (
                                    <img
                                      src={file.url}
                                      alt={file.name}
                                      className="h-12 w-12 object-cover rounded"
                                    />
                                  ) : (
                                    <div className="h-12 w-12 bg-muted rounded flex items-center justify-center">
                                      <Upload className="h-6 w-6 text-muted-foreground" />
                                    </div>
                                  )}
                                  <div className="min-w-0">
                                    <p className="font-medium text-sm truncate">{file.name}</p>
                                    <p className="text-xs text-muted-foreground">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                                  </div>
                                </div>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => removeFile(index)}
                                  className="ml-2"
                                >
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Screenshots */}
                    <div className="space-y-2">
                      <Label>Screenshots (Show your content in action)</Label>
                      <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center hover:border-muted-foreground/50 transition">
                        <ImageIcon className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                        <div className="text-lg font-medium mb-1">Add screenshots</div>
                        <div className="text-sm text-muted-foreground mb-4">
                          Upload multiple images (PNG, JPG, WebP) to showcase your content
                        </div>
                        <input
                          ref={screenshotInputRef}
                          type="file"
                          multiple
                          accept="image/*"
                          onChange={handleScreenshotChange}
                          className="hidden"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => screenshotInputRef.current?.click()}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Select Screenshots
                        </Button>
                      </div>
                      
                      {screenshotPreviews.length > 0 && (
                        <div className="space-y-2">
                          <Label className="text-sm font-medium">Selected Screenshots ({screenshots.length}):</Label>
                          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {screenshotPreviews.map((screenshot, index) => (
                              <div key={index} className="relative group">
                                <img
                                  src={screenshot.url}
                                  alt={screenshot.name}
                                  className="w-full aspect-video object-cover rounded-lg border"
                                />
                                <Button
                                  type="button"
                                  variant="destructive"
                                  size="sm"
                                  onClick={() => removeScreenshot(index)}
                                  className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition"
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>

              <div className="flex gap-4">
                <Button type="submit" className="flex-1" disabled={loading}>
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    'Upload Content'
                  )}
                </Button>
                <Button type="button" variant="outline" onClick={() => router.back()}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  )
}
