import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const user = await db.user.findUnique({
      where: { id: session.user.id },
      select: { role: true }
    })

    if (!user) {
      return NextResponse.json([], { status: 200 })
    }

    const memberships = await db.membership.findMany({
      where: { isActive: true },
      orderBy: { sortOrder: 'asc' },
      select: {
        id: true,
        name: true,
        roleName: true,
        price: true,
        color: true,
        description: true
      }
    })

    const membershipsWithStatus = memberships.map(m => ({
      ...m,
      owned: user.role === m.roleName
    }))

    return NextResponse.json(membershipsWithStatus, { status: 200 })
  } catch (error) {
    console.error('Error fetching user memberships:', error)
    return NextResponse.json({ error: 'Failed to fetch memberships' }, { status: 500 })
  }
}
