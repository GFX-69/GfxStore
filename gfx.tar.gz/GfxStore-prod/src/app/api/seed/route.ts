import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    await db.$connect()
    
    // Create default categories
    const categories = [
      { name: 'Plugins', slug: 'plugins', description: 'Enhance your server with powerful plugins', icon: 'Package' },
      { name: 'Mods', slug: 'mods', description: 'Transform your gameplay with amazing mods', icon: 'Star' },
      { name: 'Texture Packs', slug: 'texture-packs', description: 'Redesign your world with beautiful textures', icon: 'Download' },
      { name: 'Maps', slug: 'maps', description: 'Explore incredible custom maps', icon: 'Users' },
      { name: 'Shaders', slug: 'shaders', description: 'Add stunning visual effects to your game', icon: 'Shield' },
      { name: 'Server Setups', slug: 'server-setups', description: 'Complete server configurations ready to deploy', icon: 'Package' }
    ]
    
    for (const category of categories) {
      await db.category.upsert({
        where: { slug: category.slug },
        update: category,
        create: category
      })
    }
    
    // Create admin users
    const hashedPassword = await import('bcryptjs').then(bcrypt => bcrypt.hash('admin123', 12))
    const hashedPassword2 = await import('bcryptjs').then(bcrypt => bcrypt.hash('akash@12345', 12))
    
    await db.user.upsert({
      where: { email: 'admin@gfxstore.com' },
      update: {},
      create: {
        email: 'admin@gfxstore.com',
        username: 'admin',
        password: hashedPassword,
        role: 'ADMIN'
      }
    })

    await db.user.upsert({
      where: { email: 'kakmare.pa@gmail.com' },
      update: {
        role: 'ADMIN',
        password: hashedPassword2
      },
      create: {
        email: 'kakmare.pa@gmail.com',
        username: 'akash12312',
        password: hashedPassword2,
        role: 'ADMIN'
      }
    })
    
    const categoryCount = await db.category.count()
    const userCount = await db.user.count()
    
    await db.$disconnect()
    
    return NextResponse.json({
      status: 'success',
      message: 'Seed data created successfully',
      data: {
        categoryCount,
        userCount,
        timestamp: new Date().toISOString()
      }
    })
  } catch (error) {
    await db.$disconnect()
    return NextResponse.json(
      { 
        status: 'error', 
        message: 'Seed failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}