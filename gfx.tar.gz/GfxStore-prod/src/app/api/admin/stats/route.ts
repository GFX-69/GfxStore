import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user || (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Get comprehensive stats
    const [
      totalUsers,
      totalItems,
      totalDownloads,
      pendingItems,
      approvedItems
    ] = await Promise.all([
      db.user.count(),
      db.item.count(),
      db.item.aggregate({
        _sum: { downloads: true }
      }),
      db.item.count({
        where: { status: 'PENDING' }
      }),
      db.item.count({
        where: { status: 'APPROVED' }
      })
    ])

    // Calculate total revenue from paid items
    const revenueData = await db.item.aggregate({
      where: {
        status: 'APPROVED',
        price: { gt: 0 }
      },
      _sum: { price: true }
    })

    // Get truly active users (users who were active in the last 24 hours)
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000)
    const activeUsers = await db.user.count({
      where: {
        updatedAt: {
          gte: oneDayAgo
        }
      }
    })

    return NextResponse.json({
      totalUsers,
      totalItems,
      totalDownloads: totalDownloads._sum.downloads || 0,
      totalRevenue: revenueData._sum.price || 0,
      activeUsers,
      pendingItems,
      approvedItems
    })
  } catch (error) {
    console.error('Error fetching admin stats:', error)
    return NextResponse.json(
      { 
        status: 'error', 
        message: 'Failed to fetch admin stats',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}