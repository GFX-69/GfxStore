import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  try {
    // Get or create default settings
    let settings = await db.siteSettings.findFirst()
    
    if (!settings) {
      // Create default settings if none exist
      settings = await db.siteSettings.create({
        data: {
          siteName: 'GfxStore'
        }
      })
    }
    
    return NextResponse.json(settings || {})
  } catch (error) {
    console.error('Error fetching settings:', error)
    return NextResponse.json({ 
      siteName: 'GfxStore',
      nagadNumber: '',
      bkashNumber: '',
      announcement: ''
    }, { status: 200 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { nagadNumber, bkashNumber, siteName, announcement } = body

    // Find existing settings
    let settings = await db.siteSettings.findFirst()

    if (!settings) {
      // Create new settings if none exist
      settings = await db.siteSettings.create({
        data: {
          nagadNumber: nagadNumber?.trim() || '',
          bkashNumber: bkashNumber?.trim() || '',
          siteName: siteName?.trim() || 'GfxStore',
          announcement: announcement?.trim() || ''
        }
      })
      return NextResponse.json({ success: true, data: settings })
    }

    // Update existing settings with all values provided
    const updated = await db.siteSettings.update({
      where: { id: settings.id },
      data: {
        nagadNumber: nagadNumber?.trim() || '',
        bkashNumber: bkashNumber?.trim() || '',
        siteName: siteName?.trim() || settings.siteName,
        announcement: announcement?.trim() || settings.announcement
      }
    })

    return NextResponse.json({ success: true, data: updated })
  } catch (error) {
    console.error('Error updating settings:', error)
    return NextResponse.json({ error: String(error) }, { status: 500 })
  }
}
