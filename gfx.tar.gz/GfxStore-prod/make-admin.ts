import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function makeAdmin(email: string) {
  try {
    if (!email) {
      console.log('Usage: npx tsx make-admin.ts user@example.com')
      process.exit(1)
    }

    const user = await prisma.user.update({
      where: { email },
      data: { role: 'ADMIN' }
    })

    console.log(`✅ ${user.email} is now an ADMIN`)
  } catch (error: any) {
    console.error('❌ Error:', error.message)
  } finally {
    await prisma.$disconnect()
  }
}

makeAdmin(process.argv[2])
