# GfxStore - Admin Credentials

## Auto-Created Admin Users (First Run)

When you deploy this on VPS, these users are automatically created on first startup:

### Admin User 1
- **Email:** admin@gfxstore.com
- **Password:** admin123

### Admin User 2 (Akash)
- **Email:** kakmare.pa@gmail.com
- **Password:** akash9x1

Both users have full admin access and can manage the entire platform.

## Login
Visit: `http://YOUR_VPS_IP:5000/auth/signin`

Use either email/password combination above to login as admin.

## Make Additional Users Admin

```bash
cd /var/www/GfxStore-prod
npx tsx make-admin.ts user@example.com
```

## Important Notes
- ✅ Users are created ONLY on first run
- ✅ Existing users are NEVER deleted on server restart
- ✅ Database is persistent (not reset)
