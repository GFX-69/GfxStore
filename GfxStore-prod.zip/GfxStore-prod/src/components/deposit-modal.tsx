'use client'

import { useState } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { AlertCircle, CheckCircle2, Copy, Smartphone } from 'lucide-react'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'

interface DepositModalProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
}

export function DepositModal({ isOpen, onClose, onSuccess }: DepositModalProps) {
  const [step, setStep] = useState<'method' | 'details'>('method')
  const [selectedMethod, setSelectedMethod] = useState<'nagad' | 'bkash' | null>(null)
  const [paymentInfo, setPaymentInfo] = useState<any>(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSelectMethod = async (method: 'nagad' | 'bkash') => {
    setError('')
    setSelectedMethod(method)
    setLoading(true)
    
    try {
      const res = await fetch('/api/payment/deposit-info', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ method })
      })
      
      const data = await res.json()
      
      if (!res.ok) {
        setError(data.error || 'Failed to get payment info')
        setLoading(false)
        return
      }
      
      setPaymentInfo(data)
      setStep('details')
    } catch (error) {
      console.error('Failed to get payment info:', error)
      setError('Network error. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const handleCopyNumber = () => {
    if (paymentInfo?.phoneNumber) {
      navigator.clipboard.writeText(paymentInfo.phoneNumber)
      alert('Number copied to clipboard!')
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        {step === 'method' ? (
          <>
            <DialogHeader className="pb-4">
              <DialogTitle className="text-2xl">Add Funds to Wallet</DialogTitle>
              <DialogDescription className="text-base">Choose a payment method to deposit funds</DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              {error && (
                <Alert variant="destructive" className="border-red-500/50 bg-red-50/50">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-red-700">{error}</AlertDescription>
                </Alert>
              )}
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Card 
                  className={`cursor-pointer transition-all hover:shadow-lg hover:border-orange-500 ${selectedMethod === 'nagad' ? 'border-orange-500 ring-2 ring-orange-200' : 'border'}`}
                  onClick={() => !loading && handleSelectMethod('nagad')}
                >
                  <CardHeader className="pb-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <CardTitle className="text-xl text-orange-600">Nagad</CardTitle>
                        <CardDescription>Instant payment</CardDescription>
                      </div>
                      <Badge className="bg-orange-100 text-orange-700">Popular</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      className="w-full bg-orange-600 hover:bg-orange-700" 
                      disabled={loading}
                    >
                      {loading && selectedMethod === 'nagad' ? 'Loading...' : 'Select Nagad'}
                    </Button>
                  </CardContent>
                </Card>

                <Card 
                  className={`cursor-pointer transition-all hover:shadow-lg hover:border-pink-500 ${selectedMethod === 'bkash' ? 'border-pink-500 ring-2 ring-pink-200' : 'border'}`}
                  onClick={() => !loading && handleSelectMethod('bkash')}
                >
                  <CardHeader className="pb-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <CardTitle className="text-xl text-pink-600">bKash</CardTitle>
                        <CardDescription>Direct transfer</CardDescription>
                      </div>
                      <Badge className="bg-pink-100 text-pink-700">Available</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      className="w-full bg-pink-600 hover:bg-pink-700"
                      disabled={loading}
                    >
                      {loading && selectedMethod === 'bkash' ? 'Loading...' : 'Select bKash'}
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <Alert className="bg-blue-50 border-blue-200">
                <Smartphone className="h-4 w-4 text-blue-600" />
                <AlertDescription className="text-blue-700">
                  Both methods are instant and secure. Choose your preferred payment service.
                </AlertDescription>
              </Alert>
            </div>
          </>
        ) : (
          <>
            <DialogHeader className="pb-4">
              <DialogTitle className="text-2xl">Send Payment via {paymentInfo?.methodName}</DialogTitle>
              <DialogDescription className="text-base">Follow the steps to complete your deposit</DialogDescription>
            </DialogHeader>

            {paymentInfo && (
              <div className="space-y-4">
                <Alert className="bg-green-50 border-green-200">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-700 font-medium">
                    Send any amount to this {paymentInfo.methodName} number
                  </AlertDescription>
                </Alert>

                <div className="space-y-3 bg-gradient-to-br from-slate-50 to-slate-100 p-6 rounded-lg border-2 border-dashed border-slate-300">
                  <p className="text-sm font-semibold text-slate-600 uppercase tracking-wide">Payment Number</p>
                  <div className="flex items-center justify-between bg-white p-4 rounded-lg shadow-sm border border-slate-200">
                    <span className="font-mono font-bold text-2xl text-slate-900 tracking-wider">
                      {paymentInfo.phoneNumber}
                    </span>
                    <Button
                      size="sm"
                      variant="default"
                      onClick={handleCopyNumber}
                      className="gap-2"
                    >
                      <Copy className="h-4 w-4" />
                      Copy
                    </Button>
                  </div>
                  <p className="text-xs text-slate-600 italic">Long press to copy if needed</p>
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 space-y-2">
                  <p className="text-sm font-semibold text-amber-900">⏱️ Next Steps</p>
                  <ol className="text-sm text-amber-800 space-y-1 list-decimal list-inside">
                    <li>Send money to the number above via {paymentInfo.methodName}</li>
                    <li>Save your transaction ID/reference number</li>
                    <li>Click "Submit Transaction" below</li>
                    <li>Wait for admin approval (usually within 24 hours)</li>
                  </ol>
                </div>

                <Alert className="bg-blue-50 border-blue-200">
                  <AlertCircle className="h-4 w-4 text-blue-600" />
                  <AlertDescription className="text-blue-700">
                    Your transaction will be reviewed and verified by our admin team before crediting your wallet.
                  </AlertDescription>
                </Alert>

                <div className="flex gap-3 pt-2">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      setStep('method')
                      setError('')
                      setSelectedMethod(null)
                      setPaymentInfo(null)
                    }}
                  >
                    Back to Methods
                  </Button>
                  <Button
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    onClick={() => {
                      onClose()
                      window.location.href = '/transactions/submit'
                    }}
                  >
                    Submit Transaction
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}
