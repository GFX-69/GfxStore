'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { io, Socket } from 'socket.io-client'
import { Bell, X, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

interface Notification {
  id: string
  title: string
  content: string
  type: string
  isRead: boolean
  createdAt: string
  itemId?: string
}

export function NotificationBell() {
  const { data: session } = useSession()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [isOpen, setIsOpen] = useState(false)
  const socketRef = useRef<Socket | null>(null)

  useEffect(() => {
    if (!session?.user) return

    try {
      const socket = io(window.location.origin, {
        path: '/socket.io/',
        transports: ['websocket', 'polling'],
        auth: {
          userId: session.user.id,
          sessionId: session.user.id
        }
      })

      socket.on('connect', () => {
        console.log('✅ Notification bell connected')
      })

      // Listen to notifications namespace
      const notifSocket = io(`${window.location.origin}/notifications`, {
        path: '/socket.io/',
        transports: ['websocket', 'polling']
      })

      notifSocket.on('connect', () => {
        console.log('✅ Notifications namespace connected')
        fetchNotifications()
      })

      notifSocket.on('notification', (notification: Notification) => {
        console.log('🔔 New notification:', notification)
        setNotifications(prev => [notification, ...prev].slice(0, 20))
        setUnreadCount(prev => prev + 1)
      })

      notifSocket.on('notifications', (notifs: Notification[]) => {
        console.log('📬 Loaded notifications:', notifs.length)
        setNotifications(notifs)
        setUnreadCount(notifs.filter(n => !n.isRead).length)
      })

      socketRef.current = notifSocket

      return () => {
        if (socketRef.current) {
          socketRef.current.disconnect()
        }
      }
    } catch (error) {
      console.error('Failed to connect to notifications:', error)
    }
  }, [session?.user])

  const fetchNotifications = async () => {
    try {
      const response = await fetch('/api/notifications?limit=20')
      if (response.ok) {
        const data = await response.json()
        setNotifications(data.notifications)
        setUnreadCount(data.unreadCount)
      }
    } catch (error) {
      console.error('Failed to fetch notifications:', error)
    }
  }

  const markAsRead = async (notificationId: string) => {
    try {
      await fetch('/api/notifications', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notificationIds: [notificationId], isRead: true })
      })
      
      setNotifications(prev =>
        prev.map(n => n.id === notificationId ? { ...n, isRead: true } : n)
      )
      setUnreadCount(prev => Math.max(0, prev - 1))
    } catch (error) {
      console.error('Failed to mark as read:', error)
    }
  }

  const getNotificationIcon = (type: string) => {
    const icons: { [key: string]: string } = {
      ITEM_APPROVED: '✅',
      ITEM_REJECTED: '❌',
      ITEM_LIKED: '❤️',
      NEW_REVIEW: '⭐',
      TRANSACTION_APPROVED: '💰',
      DEPOSIT_APPROVED: '💰',
      NEW_MESSAGE: '💬',
      USER_MENTIONED: '👋',
      ADMIN_ANNOUNCEMENT: '📢',
      SYSTEM_ANNOUNCEMENT: '📣',
      DOWNLOAD_COMPLETE: '⬇️'
    }
    return icons[type] || '🔔'
  }

  if (!session?.user) return null

  return (
    <div className="relative">
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setIsOpen(!isOpen)}
        className="relative"
      >
        <Bell className="h-5 w-5" />
        {unreadCount > 0 && (
          <span className="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </Button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-96 bg-background border border-border rounded-lg shadow-lg z-50">
          <Card className="border-0 shadow-none">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Notifications</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-2 max-h-96 overflow-y-auto">
              {notifications.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No notifications yet</p>
              ) : (
                notifications.map(notif => (
                  <div
                    key={notif.id}
                    className={`p-3 border rounded-lg cursor-pointer transition ${
                      notif.isRead ? 'bg-background' : 'bg-primary/5 border-primary/20'
                    }`}
                    onClick={() => !notif.isRead && markAsRead(notif.id)}
                  >
                    <div className="flex items-start gap-2">
                      <span className="text-xl mt-1">{getNotificationIcon(notif.type)}</span>
                      <div className="flex-1">
                        <p className="font-semibold text-sm">{notif.title}</p>
                        <p className="text-xs text-muted-foreground">{notif.content}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(notif.createdAt).toLocaleTimeString()}
                        </p>
                      </div>
                      {!notif.isRead && (
                        <div className="w-2 h-2 bg-primary rounded-full mt-2" />
                      )}
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
