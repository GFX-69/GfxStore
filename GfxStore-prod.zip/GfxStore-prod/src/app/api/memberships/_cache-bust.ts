// Cache bust marker
export const CACHE_VERSION = Date.now()
