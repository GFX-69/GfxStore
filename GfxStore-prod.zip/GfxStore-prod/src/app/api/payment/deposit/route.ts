import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { amount, method } = body

    if (!amount || !method || amount <= 0) {
      return NextResponse.json({ error: 'Invalid amount or method' }, { status: 400 })
    }

    // Get payment settings
    const settings = await db.siteSettings.findFirst()
    const phoneNumber = method === 'nagad' ? settings?.nagadNumber : settings?.bkashNumber

    if (!phoneNumber) {
      return NextResponse.json({ error: 'Payment method not configured' }, { status: 400 })
    }

    // Create transaction record
    const transaction = await db.transaction.create({
      data: {
        userId: session.user.id,
        amount,
        method,
        type: 'DEPOSIT',
        status: 'PENDING'
      }
    })

    return NextResponse.json({
      success: true,
      transaction,
      phoneNumber,
      message: `Send $${amount} to ${phoneNumber} with reference: ${transaction.id}`
    })
  } catch (error) {
    console.error('Payment error:', error)
    return NextResponse.json({ error: 'Payment failed' }, { status: 500 })
  }
}
