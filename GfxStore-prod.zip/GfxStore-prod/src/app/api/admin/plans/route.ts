import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    // Check if this is a public request for active plans only
    const searchParams = request.nextUrl.searchParams
    const publicOnly = searchParams.get('public') === 'true'

    // If public request, allow it. Otherwise require auth
    if (!publicOnly) {
      const session = await getServerSession(authOptions)
      if (!session?.user?.id) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
      }
    }

    // Get all plans or just active ones for public view
    const where = publicOnly ? { isActive: true } : undefined
    const plans = await db.serverPlan.findMany({
      where,
      orderBy: { sortOrder: 'asc' }
    })

    return NextResponse.json({ plans })
  } catch (error) {
    console.error('Error fetching plans:', error)
    return NextResponse.json({ error: 'Failed to fetch plans' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id || (session.user?.role !== 'ADMIN' && session.user?.role !== 'SUPER_ADMIN')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { name, description, price, features, specs, isActive, sortOrder } = body

    const plan = await db.serverPlan.create({
      data: {
        name,
        description,
        price: parseFloat(price),
        features: Array.isArray(features) ? features : [],
        specs: specs || {},
        isActive: isActive ?? true,
        sortOrder: parseInt(sortOrder) || 0
      }
    })

    return NextResponse.json({ plan }, { status: 201 })
  } catch (error) {
    console.error('Error creating plan:', error)
    return NextResponse.json({ error: 'Failed to create plan: ' + (error instanceof Error ? error.message : 'Unknown error') }, { status: 500 })
  }
}
