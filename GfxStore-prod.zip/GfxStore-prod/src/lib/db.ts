import { PrismaClient } from '@prisma/client'

const globalForPrisma = global as unknown as {
  prisma: PrismaClient | undefined
}

let prismaInstance: PrismaClient | null = null

function createPrismaClient() {
  return new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['error', 'warn'] : ['error'],
  })
}

if (!prismaInstance) {
  prismaInstance = globalForPrisma.prisma ?? createPrismaClient()
}

export const db = prismaInstance

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prismaInstance
}