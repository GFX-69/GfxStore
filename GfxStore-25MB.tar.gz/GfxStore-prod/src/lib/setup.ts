import { exec } from 'child_process'
import { promisify } from 'util'
import { existsSync } from 'fs'
import path from 'path'

const execAsync = promisify(exec)

export async function setupDatabase(): Promise<void> {
  try {
    console.log('🔍 Checking database setup...')
    
    // Check if database exists
    const dbPath = path.join(process.cwd(), 'gfxstore.db')
    const dbExists = existsSync(dbPath)
    
    if (dbExists) {
      console.log('✅ Database already exists, skipping setup')
      return
    }
    
    console.log('📦 Setting up database for the first time...')
    
    // Run prisma db push
    console.log('⏳ Creating database schema...')
    await execAsync('npx prisma db push --skip-generate', {
      cwd: process.cwd(),
      stdio: 'inherit',
      maxBuffer: 10 * 1024 * 1024
    })
    console.log('✅ Database schema created')
    
    // Run prisma seed
    console.log('⏳ Seeding initial data...')
    await execAsync('npx tsx prisma/seed.ts', {
      cwd: process.cwd(),
      stdio: 'inherit',
      maxBuffer: 10 * 1024 * 1024
    })
    console.log('✅ Database seeded with initial data')
    
    console.log('🎉 Database setup completed successfully!')
    console.log('📝 Admin credentials:')
    console.log('   Email: admin@gfxstore.com')
    console.log('   Password: admin123')
    
  } catch (error) {
    console.error('❌ Database setup failed:', error)
    console.log('\n⚠️  Please manually run:')
    console.log('   npm run db:push')
    console.log('   npm run db:seed')
    console.log('\nThen restart the server')
    // Don't throw - let server continue running
  }
}
