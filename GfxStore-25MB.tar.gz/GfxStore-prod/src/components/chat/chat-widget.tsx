'use client'

import { useEffect, useState, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Send, Users, MessageCircle, Loader2, AtSign, GripHorizontal } from 'lucide-react'
import { io, Socket } from 'socket.io-client'

interface Message {
  id: string
  username: string
  message: string
  timestamp: Date
  mentions?: string[]
}

interface User {
  id: string
  username: string
  email: string
  avatar?: string
}

interface ChatWidgetProps {
  isOpen: boolean
  onToggle: () => void
}

export function ChatWidget({ isOpen, onToggle }: ChatWidgetProps) {
  const { data: session } = useSession()
  const [messages, setMessages] = useState<Message[]>([])
  const [onlineCount, setOnlineCount] = useState(0)
  const [message, setMessage] = useState('')
  const [isConnected, setIsConnected] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [allUsers, setAllUsers] = useState<User[]>([])
  const [showMentionSuggestions, setShowMentionSuggestions] = useState(false)
  const [mentionSearch, setMentionSearch] = useState('')
  const [filteredUsers, setFilteredUsers] = useState<User[]>([])
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })
  const [isMobile, setIsMobile] = useState(false)
  const [isInitialized, setIsInitialized] = useState(false)
  const socketRef = useRef<Socket | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const scrollAreaRef = useRef<HTMLDivElement>(null)
  const chatWidgetRef = useRef<HTMLDivElement>(null)

  // Initialize position and detect mobile on mount
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    
    checkMobile()
    window.addEventListener('resize', checkMobile)
    
    // Set initial position to bottom-right
    setPosition({
      x: window.innerWidth - 400,
      y: window.innerHeight - 420
    })
    
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  // Fetch all users on mount
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await fetch('/api/users/list')
        if (res.ok) {
          const users = await res.json()
          setAllUsers(users)
        }
      } catch (error) {
        console.error('Failed to fetch users:', error)
      }
    }
    
    fetchUsers()
  }, [])

  useEffect(() => {
    if (!isOpen || !session?.user) return

    setIsLoading(true)

    try {
      const socket = io(window.location.origin, {
        path: '/socket.io/',
        transports: ['websocket', 'polling'],
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        reconnectionAttempts: 5,
        auth: {
          userId: session.user.id || '',
          username: (session.user.name || session.user.email || 'User').toString(),
          sessionId: session.user.id || ''
        }
      })

      socket.on('connect', () => {
        console.log('✅ Chat connected:', socket.id)
        setIsConnected(true)
        setIsLoading(false)
      })

      socket.on('disconnect', () => {
        console.log('❌ Chat disconnected')
        setIsConnected(false)
      })

      socket.on('chatMessages', (msgs: any) => {
        console.log('📨 Received initial messages:', msgs?.length || 0)
        if (Array.isArray(msgs)) {
          setMessages(msgs.map((m: any) => ({
            id: m.id || '',
            username: m.username || 'Unknown',
            message: m.message || '',
            timestamp: new Date(m.timestamp),
            mentions: m.mentions || []
          })))
        }
      })

      socket.on('newMessage', (msg: any) => {
        console.log('💬 New message received:', msg)
        if (msg && msg.id) {
          setMessages(prev => [...prev, {
            id: msg.id,
            username: msg.username || 'Unknown',
            message: msg.message || '',
            timestamp: new Date(msg.timestamp),
            mentions: msg.mentions || []
          }])
        }
      })

      socket.on('onlineUsers', (count: number) => {
        console.log('👥 Online users:', count)
        setOnlineCount(count || 0)
      })

      socket.on('error', (err: any) => {
        console.error('Chat error:', err)
        setIsLoading(false)
      })

      socket.on('connect_error', (err: any) => {
        console.error('Connection error:', err)
        setIsLoading(false)
      })

      socketRef.current = socket

      return () => {
        if (socketRef.current) {
          socketRef.current.disconnect()
        }
      }
    } catch (error) {
      console.error('Failed to initialize chat:', error)
      setIsLoading(false)
    }
  }, [isOpen, session])

  useEffect(() => {
    const scrollViewport = scrollAreaRef.current?.querySelector('[data-radix-scroll-area-viewport]') as HTMLElement
    if (scrollViewport) {
      setTimeout(() => {
        scrollViewport.scrollTop = scrollViewport.scrollHeight
      }, 50)
    }
  }, [messages])

  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('input, button')) return
    
    setIsDragging(true)
    if (chatWidgetRef.current) {
      const rect = chatWidgetRef.current.getBoundingClientRect()
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      })
    }
  }

  useEffect(() => {
    if (!isDragging) return

    const handleMouseMove = (e: MouseEvent) => {
      let newX = e.clientX - dragOffset.x
      let newY = e.clientY - dragOffset.y

      // Constrain position to viewport
      newX = Math.max(0, Math.min(newX, window.innerWidth - 384))
      newY = Math.max(0, Math.min(newY, window.innerHeight - 384))

      setPosition({
        x: newX,
        y: newY
      })
    }

    const handleMouseUp = () => {
      setIsDragging(false)
    }

    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)

    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    }
  }, [isDragging, dragOffset])

  const extractMentions = (text: string): string[] => {
    const mentionRegex = /@(\w+)/g
    const matches = text.match(mentionRegex) || []
    return matches.map(m => m.slice(1))
  }

  const handleMessageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const text = e.target.value
    setMessage(text)

    const lastAtIndex = text.lastIndexOf('@')
    if (lastAtIndex !== -1) {
      const afterAt = text.substring(lastAtIndex + 1)
      const isValidMentionStart = lastAtIndex === 0 || text[lastAtIndex - 1] === ' '
      
      if (isValidMentionStart && afterAt && !afterAt.includes(' ')) {
        setMentionSearch(afterAt.toLowerCase())
        const filtered = allUsers.filter(user =>
          user.username.toLowerCase().includes(afterAt.toLowerCase())
        )
        setFilteredUsers(filtered)
        setShowMentionSuggestions(true)
      } else {
        setShowMentionSuggestions(false)
      }
    } else {
      setShowMentionSuggestions(false)
    }
  }

  const handleUserMention = (username: string) => {
    const lastAtIndex = message.lastIndexOf('@')
    const beforeAt = message.substring(0, lastAtIndex)
    const afterAt = message.substring(lastAtIndex + 1)
    const afterSearch = afterAt.substring(mentionSearch.length)
    
    const newMessage = beforeAt + '@' + username + ' ' + afterSearch
    setMessage(newMessage)
    
    inputRef.current?.focus()
    
    setTimeout(() => {
      const event = new Event('input', { bubbles: true })
      inputRef.current?.dispatchEvent(event)
    }, 0)
  }

  const handleSend = () => {
    if (!message.trim() || !socketRef.current) {
      console.log('❌ Cannot send: empty message or no socket')
      return
    }

    try {
      const mentions = extractMentions(message.trim())
      console.log('📤 Sending message:', message.trim(), 'Mentions:', mentions)
      socketRef.current.emit('sendMessage', {
        text: message.trim(),
        mentions
      })
      setMessage('')
      setShowMentionSuggestions(false)
      console.log('✅ Message emitted')
    } catch (error) {
      console.error('❌ Failed to send message:', error)
    }
  }

  if (!isOpen) {
    return (
      <Button
        onClick={onToggle}
        className="fixed bottom-4 right-4 z-50 rounded-full w-14 h-14 shadow-lg"
        size="icon"
      >
        <MessageCircle className="h-6 w-6" />
        {onlineCount > 0 && (
          <Badge className="absolute -top-1 -right-1 bg-green-500 text-white text-xs">
            {onlineCount}
          </Badge>
        )}
      </Button>
    )
  }

  return (
    <div
      ref={chatWidgetRef}
      style={{
        position: 'fixed',
        left: `${position.x}px`,
        top: `${position.y}px`,
        width: '384px',
        height: '384px',
        zIndex: 50,
        boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)',
        overflow: 'hidden'
      }}
      className="flex flex-col rounded-lg"
    >
      <Card className="h-full flex flex-col">
        <CardHeader 
          onMouseDown={handleMouseDown}
          className="flex flex-row items-center justify-between space-y-0 pb-3 cursor-move select-none"
        >
          <div className="flex items-center gap-2">
            <GripHorizontal className="h-4 w-4 text-muted-foreground" />
            <CardTitle className="text-lg flex items-center gap-2">
              <MessageCircle className="h-5 w-5" />
              Chat
            </CardTitle>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs">
              <Users className="h-3 w-3 mr-1" />
              {onlineCount}
            </Badge>
            <Button variant="ghost" size="sm" onClick={onToggle}>
              ×
            </Button>
          </div>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col p-0 gap-0 overflow-hidden min-w-0">
          <ScrollArea ref={scrollAreaRef} className="flex-1 w-full overflow-hidden">
            <div className="space-y-2 px-2 py-2 w-full min-w-0">
              {isLoading && (
                <div className="flex items-center justify-center py-8 text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Loading...
                </div>
              )}
              {!isLoading && messages.length === 0 && (
                <div className="text-center text-xs text-muted-foreground py-8 px-2">
                  No messages yet. Use @username to mention someone!
                </div>
              )}
              {!isLoading && messages.length > 0 && messages.map((msg) => {
                const username = session?.user?.name?.split('@')[0] || session?.user?.username?.split('@')[0] || ''
                const hasHighlight = msg.mentions?.includes(username)
                const highlightClass = hasHighlight ? 'bg-yellow-500/20 border border-yellow-500/50' : ''

                return (
                  <div key={msg.id} className={`flex flex-col gap-0.5 p-1.5 rounded min-w-0 ${highlightClass}`}>
                    <div className="flex items-baseline gap-1 flex-wrap min-w-0">
                      <span className="font-semibold text-xs text-primary truncate min-w-0">
                        {msg.username}
                      </span>
                      <span className="text-xs text-muted-foreground whitespace-nowrap flex-shrink-0">
                        {msg.timestamp.toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="text-xs text-foreground pl-1 min-w-0 overflow-hidden break-words">
                      {msg.message}
                    </div>
                    {msg.mentions && msg.mentions.length > 0 && (
                      <div className="text-xs mt-0.5 text-blue-600 min-w-0 break-words">
                        📌 @{msg.mentions.join(', @')}
                      </div>
                    )}
                  </div>
                )
              })}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          {session?.user ? (
            <div className="p-3 border-t">
              <div className="relative">
                <div className="flex gap-2">
                  <Input
                    ref={inputRef}
                    value={message}
                    onChange={handleMessageChange}
                    onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Message... (type @ to mention)"
                    disabled={!isConnected}
                    className="flex-1 text-sm"
                  />
                  <Button
                    onClick={handleSend}
                    size="icon"
                    disabled={!isConnected || !message.trim()}
                    className="h-9 w-9"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>

                {showMentionSuggestions && filteredUsers.length > 0 && (
                  <div className="absolute bottom-full mb-2 left-0 right-0 bg-background border border-primary rounded-lg shadow-lg max-h-40 overflow-y-auto z-50">
                    <div className="p-2 space-y-1">
                      {filteredUsers.map((user) => (
                        <button
                          key={user.id}
                          onClick={() => handleUserMention(user.username)}
                          className="w-full text-left px-3 py-2 rounded hover:bg-muted flex items-center gap-2 text-sm transition-colors"
                        >
                          <AtSign className="h-3 w-3 text-blue-600" />
                          <span className="font-medium">{user.username}</span>
                          <span className="text-xs text-muted-foreground ml-auto">
                            ({user.email})
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="p-3 border-t text-center text-xs text-muted-foreground">
              Sign in to chat
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
