'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Wallet, Zap, Gift, DollarSign, TrendingUp } from 'lucide-react'

interface UserData {
  id: string
  username: string
  email: string
  walletBalance?: number
  badges?: string[]
  avatar?: string
}

interface Transaction {
  id: string
  amount: number
  method: string
  type: string
  status: string
  createdAt: string
}

interface Membership {
  id: string
  name: string
  roleName: string
  price: number
  color: string
  description?: string
  owned?: boolean
}

export default function WalletPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [userData, setUserData] = useState<UserData | null>(null)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [memberships, setMemberships] = useState<Membership[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === 'loading') return
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
      return
    }
    fetchUserData()
    fetchTransactions()
    fetchMemberships()
  }, [status, router])

  const fetchMemberships = async () => {
    try {
      const res = await fetch('/api/user/memberships')
      if (res.ok) {
        const data = await res.json()
        setMemberships(Array.isArray(data) ? data : [])
      }
    } catch (error) {
      console.error('Failed to fetch memberships:', error)
    }
  }

  const fetchUserData = async () => {
    try {
      const res = await fetch('/api/users/me')
      if (res.ok) {
        const data = await res.json()
        setUserData(data)
      }
    } catch (error) {
      console.error('Failed to fetch user data:', error)
    }
  }

  const fetchTransactions = async () => {
    try {
      const res = await fetch('/api/transactions')
      if (res.ok) {
        const data = await res.json()
        setTransactions(data)
      }
    } finally {
      setLoading(false)
    }
  }

  const handleBuyMembership = async (membership: Membership) => {
    if (!userData || (userData.walletBalance || 0) < membership.price) {
      alert('Insufficient balance. Please deposit funds first.')
      router.push('/payment')
      return
    }

    try {
      const res = await fetch('/api/memberships/purchase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ membershipId: membership.id })
      })

      const data = await res.json()

      if (res.ok && data.success) {
        alert(`✅ Successfully purchased ${membership.name}! Your role has been updated to ${data.newRole}.`)
        // Refresh all data
        setTimeout(async () => {
          await fetchUserData()
          await fetchMemberships()
        }, 500)
      } else {
        const errorMsg = data.error || data.message || 'Failed to purchase membership'
        console.error('Purchase error:', data)
        alert(`❌ Error: ${errorMsg}`)
      }
    } catch (error) {
      console.error('Purchase failed:', error)
      alert('❌ Purchase failed. Please try again.')
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!userData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Failed to load wallet data</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <div className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">My Wallet</h1>
          <p className="text-muted-foreground">Manage your balance and purchase memberships</p>
        </div>

        <Tabs defaultValue="balance" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="balance">Balance</TabsTrigger>
            <TabsTrigger value="nitro">Memberships</TabsTrigger>
            <TabsTrigger value="transactions">History</TabsTrigger>
          </TabsList>

          {/* Balance Tab */}
          <TabsContent value="balance" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Wallet className="h-5 w-5" />
                    Wallet Balance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold mb-4 text-green-600">
                    ${userData.walletBalance.toFixed(2)}
                  </div>
                  <Button onClick={() => router.push('/payment')} className="w-full">
                    <DollarSign className="h-4 w-4 mr-2" />
                    Add Funds
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Gift className="h-5 w-5" />
                    Current Badges
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {userData.badges && userData.badges.length > 0 ? (
                    <div className="space-y-2">
                      {userData.badges.map(badge => (
                        <Badge key={badge} variant="secondary" className="mr-2">
                          {badge}
                        </Badge>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No badges purchased yet</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Nitro/Memberships Tab */}
          <TabsContent value="nitro" className="space-y-6">
            {memberships.length === 0 ? (
              <Alert>
                <AlertDescription>No memberships available at this time.</AlertDescription>
              </Alert>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {memberships.map(membership => (
                  <Card key={membership.id} className="relative">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Zap className="h-5 w-5" />
                        {membership.name}
                      </CardTitle>
                      {membership.description && (
                        <p className="text-sm text-muted-foreground mt-1">{membership.description}</p>
                      )}
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <p className="text-2xl font-bold text-primary mb-2">
                          ${membership.price.toFixed(2)}
                        </p>
                        <p className="text-sm text-muted-foreground">per month</p>
                      </div>
                      
                      {membership.owned ? (
                        <Badge className="w-full justify-center py-2">✅ Active Membership</Badge>
                      ) : (
                        <Button
                          onClick={() => handleBuyMembership(membership)}
                          disabled={userData.walletBalance < membership.price}
                          className="w-full"
                        >
                          {userData.walletBalance < membership.price ? 'Insufficient Balance' : 'Subscribe'}
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Transaction History Tab */}
          <TabsContent value="transactions">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Transaction History
                </CardTitle>
              </CardHeader>
              <CardContent>
                {transactions.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">No transactions yet</p>
                ) : (
                  <div className="space-y-3">
                    {transactions.map(tx => (
                      <div key={tx.id} className="flex justify-between items-center p-3 bg-muted rounded-lg">
                        <div>
                          <p className="font-medium">{tx.type}</p>
                          <p className="text-sm text-muted-foreground">
                            {tx.method} • {new Date(tx.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold">${tx.amount.toFixed(2)}</p>
                          <Badge variant={tx.status === 'COMPLETED' ? 'default' : 'secondary'}>
                            {tx.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <Footer />
    </div>
  )
}
