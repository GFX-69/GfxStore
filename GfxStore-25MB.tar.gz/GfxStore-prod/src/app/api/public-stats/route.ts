import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    await db.$connect()

    const [totalUsers, totalItems, totalDownloadsResult] = await Promise.all([
      db.user.count(),
      db.item.count({ where: { status: 'APPROVED' } }),
      db.item.aggregate({
        _sum: { downloads: true }
      })
    ])

    await db.$disconnect()

    return NextResponse.json({
      totalUsers,
      totalItems,
      totalDownloads: totalDownloadsResult._sum.downloads || 0
    })
  } catch (error) {
    await db.$disconnect()
    return NextResponse.json({
      totalUsers: 0,
      totalItems: 0,
      totalDownloads: 0
    })
  }
}
