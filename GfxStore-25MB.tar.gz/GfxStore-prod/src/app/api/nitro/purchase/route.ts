import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

const BADGE_PRICES: Record<string, number> = {
  gold: 9.99,
  platinum: 19.99,
  diamond: 49.99
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { badgeId } = body

    if (!badgeId || !BADGE_PRICES[badgeId]) {
      return NextResponse.json({ error: 'Invalid badge' }, { status: 400 })
    }

    const price = BADGE_PRICES[badgeId]

    // Get user and check balance
    const user = await db.user.findUnique({
      where: { id: session.user.id },
      select: { walletBalance: true, badges: true }
    })

    if (!user || user.walletBalance < price) {
      return NextResponse.json({ error: 'Insufficient balance' }, { status: 400 })
    }

    // Check if already has badge
    if (user.badges.includes(badgeId)) {
      return NextResponse.json({ error: 'Badge already owned' }, { status: 400 })
    }

    // Deduct from wallet and add badge
    await db.user.update({
      where: { id: session.user.id },
      data: {
        walletBalance: user.walletBalance - price,
        badges: [...user.badges, badgeId]
      }
    })

    // Create transaction record
    await db.transaction.create({
      data: {
        userId: session.user.id,
        amount: price,
        method: 'WALLET',
        type: 'BADGE_PURCHASE',
        reference: badgeId,
        status: 'COMPLETED'
      }
    })

    return NextResponse.json({ success: true, message: 'Badge purchased successfully' })
  } catch (error) {
    console.error('Purchase error:', error)
    return NextResponse.json({ error: 'Purchase failed' }, { status: 500 })
  }
}
