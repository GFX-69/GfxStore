import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user || (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { itemId, status } = await request.json()
    const item = await db.item.findUnique({ where: { id: itemId } })
    
    if (!item) return NextResponse.json({ error: 'Item not found' }, { status: 404 })

    const globalSendNotification = (global as any).sendNotification
    if (globalSendNotification) {
      if (status === 'APPROVED') {
        await globalSendNotification(item.authorId, {
          title: '✅ Item Approved!',
          content: `Your item "${item.title}" has been approved and is now live!`,
          type: 'ITEM_APPROVED',
          itemId: item.id
        })
      } else if (status === 'REJECTED') {
        await globalSendNotification(item.authorId, {
          title: '❌ Item Rejected',
          content: `Your item "${item.title}" was rejected. Please review and resubmit.`,
          type: 'ITEM_REJECTED',
          itemId: item.id
        })
      }
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error sending status notification:', error)
    return NextResponse.json({ error: 'Failed to send notification' }, { status: 500 })
  }
}
