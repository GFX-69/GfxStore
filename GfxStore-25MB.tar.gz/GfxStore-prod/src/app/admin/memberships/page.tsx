'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Plus, Edit2, Trash2, Loader2 } from 'lucide-react'

interface Membership {
  id: string
  name: string
  roleName: string
  description?: string
  price: number
  color: string
  isActive: boolean
  sortOrder: number
}

export default function MembershipsAdminPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [memberships, setMemberships] = useState<Membership[]>([])
  const [loading, setLoading] = useState(true)
  const [isOpen, setIsOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    roleName: '',
    description: '',
    price: 0,
    color: '#6366f1',
  })

  useEffect(() => {
    if (status === 'loading') return
    if (status === 'unauthenticated' || (session?.user?.role !== 'ADMIN' && session?.user?.role !== 'SUPER_ADMIN')) {
      router.push('/')
      return
    }
    fetchMemberships()
    const interval = setInterval(fetchMemberships, 1500)
    return () => clearInterval(interval)
  }, [status, session, router])

  const fetchMemberships = async () => {
    try {
      const res = await fetch(`/api/memberships?t=${Date.now()}`)
      if (res.ok) {
        const data = await res.json()
        setMemberships(Array.isArray(data) ? data : [])
      }
    } catch (error) {
      console.error('Error fetching memberships:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    if (!formData.name || !formData.roleName || formData.price < 0) {
      alert('Please fill all required fields')
      return
    }

    try {
      setLoading(true)
      const method = editingId ? 'PATCH' : 'POST'
      const endpoint = editingId ? `/api/memberships/${editingId}` : '/api/memberships'
      
      const payload = {
        name: formData.name,
        roleName: formData.roleName.toUpperCase(),
        description: formData.description,
        price: parseFloat(formData.price.toString()),
        color: formData.color,
        sortOrder: 0,
        isActive: true
      }
      
      const res = await fetch(endpoint, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })

      if (res.ok) {
        const response = await res.json()
        console.log('✅ Membership saved:', response)
        setTimeout(() => {
          fetchMemberships()
          resetForm()
          setIsOpen(false)
        }, 300)
      } else {
        const errorData = await res.json()
        alert(`Error: ${errorData.error || 'Failed to save membership'}`)
      }
    } catch (error) {
      console.error('Error saving membership:', error)
      alert(`Error: ${error instanceof Error ? error.message : 'Failed to save membership'}`)
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this membership?')) return
    
    try {
      const res = await fetch(`/api/memberships/${id}`, { method: 'DELETE' })
      if (res.ok) fetchMemberships()
    } catch (error) {
      console.error('Error deleting membership:', error)
      alert('Error deleting membership')
    }
  }

  const handleEdit = (membership: Membership) => {
    setFormData({
      name: membership.name,
      roleName: membership.roleName,
      description: membership.description || '',
      price: membership.price,
      color: membership.color,
    })
    setEditingId(membership.id)
    setIsOpen(true)
  }

  const resetForm = () => {
    setFormData({
      name: '',
      roleName: '',
      description: '',
      price: 0,
      color: '#6366f1',
    })
    setEditingId(null)
    setIsOpen(false)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Membership Management</h1>
          <p className="text-muted-foreground">Create and manage membership roles (DIAMOND, GOLD, etc.)</p>
        </div>

        <div className="mb-6">
          <Button onClick={() => { resetForm(); setIsOpen(true) }} className="bg-primary">
            <Plus className="h-4 w-4 mr-2" />
            Add Membership
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Memberships</CardTitle>
          </CardHeader>
          <CardContent>
            {memberships.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No memberships yet. Create one to get started!
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Price/Month</TableHead>
                      <TableHead>Color</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {memberships.map((m) => (
                      <TableRow key={m.id}>
                        <TableCell className="font-medium">{m.name}</TableCell>
                        <TableCell><Badge variant="outline">{m.roleName}</Badge></TableCell>
                        <TableCell>${m.price}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div
                              className="w-6 h-6 rounded border"
                              style={{ backgroundColor: m.color }}
                            />
                            {m.color}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={m.isActive ? 'default' : 'secondary'}>
                            {m.isActive ? 'Active' : 'Inactive'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEdit(m)}
                            >
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(m.id)}
                              className="text-red-500 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingId ? 'Edit Membership' : 'Create New Membership'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Membership Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., Diamond"
                />
              </div>
              <div>
                <Label htmlFor="roleName">Role Name *</Label>
                <Input
                  id="roleName"
                  value={formData.roleName}
                  onChange={(e) => setFormData({ ...formData, roleName: e.target.value.toUpperCase() })}
                  placeholder="e.g., DIAMOND"
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe this membership..."
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="price">Price per Month ($) *</Label>
                <Input
                  id="price"
                  type="number"
                  min="0"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
                />
              </div>
              <div>
                <Label htmlFor="color">Color</Label>
                <div className="flex gap-2">
                  <input
                    id="color"
                    type="color"
                    value={formData.color}
                    onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                    className="w-12 h-10 rounded cursor-pointer"
                  />
                  <Input
                    value={formData.color}
                    onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                    placeholder="#6366f1"
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={resetForm}>Cancel</Button>
              <Button onClick={handleSave} disabled={loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                {editingId ? 'Update' : 'Create'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      <Footer />
    </div>
  )
}
