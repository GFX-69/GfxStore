'use client'

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Alert, AlertDescription } from '@/components/ui/alert'

export default function PaymentPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [amount, setAmount] = useState('')
  const [method, setMethod] = useState('nagad')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState('')

  if (status === 'loading') return <div>Loading...</div>
  if (status === 'unauthenticated') {
    router.push('/auth/signin')
    return null
  }

  const handleDeposit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!amount || parseFloat(amount) <= 0) {
      setError('Please enter a valid amount')
      return
    }

    setLoading(true)
    setError('')
    setResult(null)

    try {
      const res = await fetch('/api/payment/deposit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: parseFloat(amount), method })
      })

      if (!res.ok) throw new Error('Payment failed')
      const data = await res.json()
      setResult(data)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-1 container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Add Funds to Wallet</CardTitle>
              <CardDescription>Deposit money using Nagad or bKash</CardDescription>
            </CardHeader>
            <CardContent>
              {result ? (
                <Alert className="mb-4">
                  <AlertDescription>
                    <p className="font-bold text-lg mb-2">{result.message}</p>
                    <p className="text-sm">Transaction ID: {result.transaction.id}</p>
                  </AlertDescription>
                </Alert>
              ) : (
                <form onSubmit={handleDeposit} className="space-y-4">
                  <div>
                    <Label>Amount ($)</Label>
                    <Input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="Enter amount"
                      min="0"
                      step="0.01"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label>Payment Method</Label>
                    <RadioGroup value={method} onValueChange={setMethod}>
                      <div className="flex items-center gap-2">
                        <RadioGroupItem value="nagad" id="nagad" />
                        <label htmlFor="nagad" className="cursor-pointer">
                          Nagad
                        </label>
                      </div>
                      <div className="flex items-center gap-2">
                        <RadioGroupItem value="bkash" id="bkash" />
                        <label htmlFor="bkash" className="cursor-pointer">
                          bKash
                        </label>
                      </div>
                    </RadioGroup>
                  </div>

                  {error && (
                    <Alert variant="destructive">
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <Button type="submit" disabled={loading} className="w-full">
                    {loading ? 'Processing...' : 'Continue'}
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
      <Footer />
    </div>
  )
}
