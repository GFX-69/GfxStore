import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  // Create categories
  const categories = [
    {
      name: 'Plugins',
      slug: 'plugins',
      description: 'Server plugins for Bukkit, Spigot, Paper, and more',
      icon: 'plugin',
      background: 'plugins-bg.jpg',
      sortOrder: 1,
    },
    {
      name: 'Mods',
      slug: 'mods',
      description: 'Client-side and server-side mods for Minecraft',
      icon: 'mod',
      background: 'mods-bg.jpg',
      sortOrder: 2,
    },
    {
      name: 'Texture Packs',
      slug: 'texture-packs',
      description: 'Custom textures and resource packs',
      icon: 'texture',
      background: 'textures-bg.jpg',
      sortOrder: 3,
    },
    {
      name: 'Maps',
      slug: 'maps',
      description: 'Custom maps and worlds',
      icon: 'map',
      background: 'maps-bg.jpg',
      sortOrder: 4,
    },
    {
      name: 'Shaders',
      slug: 'shaders',
      description: 'Visual enhancement shaders',
      icon: 'shader',
      background: 'shaders-bg.jpg',
      sortOrder: 5,
    },
    {
      name: 'Server Setups',
      slug: 'server-setups',
      description: 'Complete server configurations',
      icon: 'server',
      background: 'servers-bg.jpg',
      sortOrder: 6,
    },
  ]

  for (const categoryData of categories) {
    await prisma.category.upsert({
      where: { slug: categoryData.slug },
      update: categoryData,
      create: categoryData,
    })
  }

  // Create subcategories for plugins
  const pluginCategory = await prisma.category.findUnique({
    where: { slug: 'plugins' }
  })

  if (pluginCategory) {
    const pluginSubcategories = [
      { name: 'Economy', slug: 'economy', categoryId: pluginCategory.id },
      { name: 'Minigames', slug: 'minigames', categoryId: pluginCategory.id },
      { name: 'Utilities', slug: 'utilities', categoryId: pluginCategory.id },
      { name: 'Role-playing', slug: 'roleplaying', categoryId: pluginCategory.id },
      { name: 'World Editing', slug: 'world-editing', categoryId: pluginCategory.id },
    ]

    for (const subcategoryData of pluginSubcategories) {
      await prisma.subcategory.upsert({
        where: { slug: subcategoryData.slug },
        update: subcategoryData,
        create: subcategoryData,
      })
    }
  }

  // Create site settings
  await prisma.siteSettings.upsert({
    where: { id: 'default' },
    update: {
      siteName: 'GfxStore',
      siteLogo: '/logo.png',
      uploadLimit: 100,
    },
    create: {
      id: 'default',
      siteName: 'GfxStore',
      siteLogo: '/logo.png',
      uploadLimit: 100,
    },
  })

  console.log('Database seeded successfully!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })