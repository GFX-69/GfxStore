import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { join } from 'path'
import { existsSync, createReadStream } from 'fs'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const featured = searchParams.get('featured')
    const limit = parseInt(searchParams.get('limit') || '50')
    const category = searchParams.get('category')
    const status = searchParams.get('status')

    const whereClause: any = {}

    if (featured === 'true') {
      whereClause.featured = true
      whereClause.status = 'APPROVED'
    } else if (status) {
      whereClause.status = status
    } else {
      whereClause.status = 'APPROVED'
    }

    if (category) {
      whereClause.category = { slug: category }
    }

    // Get items with their files and screenshots
    const items = await db.item.findMany({
      where: whereClause,
      take: limit,
      include: {
        author: {
          select: {
            username: true
          }
        },
        category: {
          select: {
            name: true
          }
        },
        versions: {
          where: {
            isActive: true
          },
          orderBy: {
            createdAt: 'desc'
          },
          take: 1
        },
        screenshots: {
          orderBy: {
            sortOrder: 'asc'
          }
        },
        _count: {
          select: {
            reviews: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    // Process items to include file information
    const processedItems = items.map(item => {
      const latestVersion = item.versions[0]
      const screenshots = item.screenshots.map(screenshot => {
        let url = screenshot.url
        
        if (!url) {
          url = '/placeholder-item.png'
        }

        return {
          ...screenshot,
          url
        }
      })

      // Process logo URL
      let logo = item.logo
      if (!logo) {
        logo = '/placeholder-item.png'
      }

      return {
        ...item,
        logo,
        latestVersion,
        screenshots,
        hasFiles: latestVersion !== undefined,
        downloadUrl: latestVersion?.downloadUrl || null
      }
    })

    return NextResponse.json(processedItems)
  } catch (error) {
    return NextResponse.json(
      { 
        status: 'error', 
        message: 'Failed to fetch items',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}