import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user || (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { title, content } = await request.json()
    
    // Get all users
    const users = await db.user.findMany({ select: { id: true } })
    
    const globalSendNotification = (global as any).sendNotification
    if (globalSendNotification) {
      // Send to all users
      for (const user of users) {
        await globalSendNotification(user.id, {
          title: '📢 ' + title,
          content,
          type: 'ADMIN_ANNOUNCEMENT'
        })
      }
    }

    return NextResponse.json({ success: true, sent: users.length })
  } catch (error) {
    console.error('Error broadcasting announcement:', error)
    return NextResponse.json({ error: 'Failed to send announcement' }, { status: 500 })
  }
}
