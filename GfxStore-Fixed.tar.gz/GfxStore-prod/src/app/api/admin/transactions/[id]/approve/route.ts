import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

const BDT_TO_USD_RATE = 120 // 120 BDT = 1 USD

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const transaction = await db.transaction.findUnique({
      where: { id }
    })

    if (!transaction) {
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })
    }

    if (transaction.status !== 'PENDING') {
      return NextResponse.json({ error: 'Transaction is not pending' }, { status: 400 })
    }

    // Convert BDT to USD if payment method is Nagad/bKash
    let creditAmount = transaction.amount
    if (transaction.method.toUpperCase() === 'NAGAD' || transaction.method.toUpperCase() === 'BKASH') {
      // Convert BDT to USD: 120 BDT = 1 USD
      creditAmount = parseFloat((transaction.amount / BDT_TO_USD_RATE).toFixed(2))
    }

    console.log(`Transaction ${id}: ${transaction.amount} ${transaction.method} → ${creditAmount} USD`)

    // Update transaction status and add funds to user
    const [updatedTx] = await Promise.all([
      db.transaction.update({
        where: { id },
        data: { status: 'COMPLETED' }
      }),
      db.user.update({
        where: { id: transaction.userId },
        data: { walletBalance: { increment: creditAmount } }
      })
    ])

    // Send notification to user
    console.log('📢 Sending deposit approval notification to:', transaction.userId)
    if ((global as any).sendNotification) {
      try {
        await (global as any).sendNotification(transaction.userId, {
          title: '💰 Deposit Approved!',
          content: `Your deposit of ${transaction.amount} ${transaction.method} has been approved! You received ${creditAmount} USD to your wallet.`,
          type: 'DEPOSIT_APPROVED'
        })
        console.log('✅ Notification sent successfully')
      } catch (notifError) {
        console.error('❌ Failed to send notification:', notifError)
      }
    } else {
      console.warn('⚠️ sendNotification function not available')
    }

    return NextResponse.json({ 
      success: true, 
      transaction: updatedTx,
      conversionInfo: {
        originalAmount: transaction.amount,
        method: transaction.method,
        creditedAmount: creditAmount,
        exchangeRate: `1 USD = ${BDT_TO_USD_RATE} BDT`
      }
    })
  } catch (error) {
    console.error('Error approving transaction:', error)
    return NextResponse.json({ error: 'Failed to approve transaction' }, { status: 500 })
  }
}
