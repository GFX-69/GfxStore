import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST() {
  try {
    await db.$connect()

    // Delete all fake/sample data
    await db.item.deleteMany({})
    await db.itemVersion.deleteMany({})
    await db.screenshot.deleteMany({})
    await db.review.deleteMany({})
    await db.download.deleteMany({})
    await db.chatMessage.deleteMany({})
    await db.notification.deleteMany({})

    // Keep users and categories, but reset item-related data

    await db.$disconnect()

    return NextResponse.json({
      status: 'success',
      message: 'All fake data cleared. Ready for real uploads.',
      timestamp: new Date().toISOString()
    })
  } catch (error) {
    await db.$disconnect()
    return NextResponse.json(
      { 
        status: 'error', 
        message: 'Failed to clear fake data',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}