import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth/next'

export async function GET(
  request: Request,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    const { userId } = await params

    await db.$connect()

    const profile = await db.user.findUnique({
      where: { id: userId },
      include: {
        _count: {
          select: {
            items: true,
            downloadRecords: true,
            reviews: true
          }
        }
      }
    })

    if (!profile) {
      await db.$disconnect()
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    await db.$disconnect()

    return NextResponse.json({
      id: profile.id,
      username: profile.username,
      email: profile.email,
      role: profile.role,
      avatar: profile.avatar,
      bio: profile.bio,
      socialLinks: profile.socialLinks,
      createdAt: profile.createdAt,
      _count: {
        items: profile._count.items,
        downloads: profile._count.downloadRecords,
        reviews: profile._count.reviews
      }
    })
  } catch (error) {
    await db.$disconnect()
    return NextResponse.json(
      { 
        status: 'error', 
        message: 'Failed to fetch profile',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}

export async function PUT(request: Request) {
  try {
    const session = await getServerSession()
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const formData = await request.formData()
    const bio = formData.get('bio') as string
    const socialLinks = JSON.parse(formData.get('socialLinks') as string)
    const avatarFile = formData.get('avatar') as File

    await db.$connect()

    const updateData: any = {
      bio,
      socialLinks
    }

    // Handle avatar upload
    if (avatarFile) {
      const buffer = Buffer.from(await avatarFile.arrayBuffer())
      const fileName = `avatar-${session.user.id}-${Date.now()}.jpg`
      const filePath = `./uploads/${fileName}`
      
      // Save avatar file
      const { writeFile } = await import('fs/promises')
      await writeFile(filePath, buffer)
      
      updateData.avatar = `/uploads/${fileName}`
    }

    const updatedProfile = await db.user.update({
      where: { id: session.user.id },
      data: updateData,
      include: {
        _count: {
          select: {
            items: true,
            downloadRecords: true,
            reviews: true
          }
        }
      }
    })

    await db.$disconnect()

    return NextResponse.json({
      id: updatedProfile.id,
      username: updatedProfile.username,
      email: updatedProfile.email,
      role: updatedProfile.role,
      avatar: updatedProfile.avatar,
      bio: updatedProfile.bio,
      socialLinks: updatedProfile.socialLinks,
      createdAt: updatedProfile.createdAt,
      _count: {
        items: updatedProfile._count.items,
        downloads: updatedProfile._count.downloadRecords,
        reviews: updatedProfile._count.reviews
      }
    })
  } catch (error) {
    await db.$disconnect()
    return NextResponse.json(
      { 
        status: 'error', 
        message: 'Failed to update profile',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}