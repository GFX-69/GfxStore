'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useTheme } from 'next-themes'
import { io, Socket } from 'socket.io-client'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Users, 
  Package, 
  Settings, 
  BarChart3, 
  FileText, 
  TrendingUp, 
  Download,
  Shield,
  Check,
  X,
  Eye,
  Trash2,
  Edit,
  RefreshCw,
  AlertTriangle,
  Bell,
  Database,
  Globe,
  Mail,
  Palette as PaletteIcon,
  LayoutDashboard,
  Zap,
  ShoppingCart,
  FolderOpen,
  CreditCard,
  Server
} from 'lucide-react'
import Link from 'next/link'

interface DashboardStats {
  totalUsers: number
  totalItems: number
  totalDownloads: number
  totalRevenue: number
  activeUsers: number
  pendingItems: number
}

interface User {
  id: string
  username: string
  email: string
  role: string
  isActive: boolean
  isBanned: boolean
  walletBalance: number
  createdAt: string
  updatedAt: string
  _count?: {
    items: number
  }
}

interface Item {
  id: string
  title: string
  slug: string
  status: string
  downloads: number
  createdAt: string
  author: {
    username: string
  }
  category: {
    name: string
  }
}

export default function AdminDashboard() {
  const { data: session, status: authStatus } = useSession()
  const router = useRouter()
  const { theme, setTheme } = useTheme()
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    totalItems: 0,
    totalDownloads: 0,
    totalRevenue: 0,
    activeUsers: 0,
    pendingItems: 0
  })
  const [users, setUsers] = useState<User[]>([])
  const [items, setItems] = useState<Item[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')
  const [siteSettings, setSiteSettings] = useState({
    siteName: 'GfxStore',
    maintenance: false,
    uploadLimit: 100,
    announcement: '',
    nagadNumber: '',
    bkashNumber: ''
  })
  const [categories, setCategories] = useState<any[]>([])
  const [newCategory, setNewCategory] = useState({ name: '', description: '' })
  const socketRef = useRef<Socket | null>(null)

  // Real-time active users listener
  useEffect(() => {
    try {
      const socket = io(window.location.origin, {
        path: '/socket.io/',
        transports: ['websocket', 'polling'],
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        reconnectionAttempts: 5
      })

      socket.on('connect', () => {
        console.log('✅ Admin dashboard connected to real-time updates')
      })

      socket.on('onlineUsers', (count: number) => {
        console.log('👥 Real-time online users:', count)
        setStats(prev => ({
          ...prev,
          activeUsers: count
        }))
      })

      socket.on('disconnect', () => {
        console.log('❌ Admin dashboard disconnected')
      })

      socketRef.current = socket

      return () => {
        if (socketRef.current) {
          socketRef.current.disconnect()
        }
      }
    } catch (error) {
      console.error('Failed to initialize real-time updates:', error)
    }
  }, [])

  useEffect(() => {
    if (authStatus === 'loading') return
    
    if (authStatus === 'unauthenticated') {
      router.push('/auth/signin')
      return
    }

    if (session?.user?.role !== 'ADMIN' && session?.user?.role !== 'SUPER_ADMIN') {
      router.push('/')
      return
    }

    fetchStats()
    fetchUsers()
    fetchItems()
    fetchCategories()
  }, [authStatus, session, router])

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/admin/categories')
      if (response.ok) {
        const data = await response.json()
        setCategories(data)
      }
    } catch (error) {
      console.error('Failed to fetch categories:', error)
    }
  }

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/admin/stats')
      if (response.ok) {
        const data = await response.json()
        setStats(data)
      }
    } catch (error) {
      console.error('Failed to fetch admin stats:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchUsers = async () => {
    try {
      const response = await fetch('/api/admin/users')
      if (response.ok) {
        const data = await response.json()
        setUsers(Array.isArray(data) ? data : data.users || [])
      }
    } catch (error) {
      console.error('Failed to fetch users:', error)
    }
  }

  const fetchItems = async () => {
    try {
      const response = await fetch('/api/admin/items-all')
      if (response.ok) {
        const data = await response.json()
        setItems(Array.isArray(data) ? data : [])
      }
    } catch (error) {
      console.error('Failed to fetch items:', error)
    }
  }

  const updateUserRole = async (userId: string, newRole: string) => {
    try {
      const response = await fetch(`/api/admin/users/${userId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: newRole })
      })
      if (response.ok) {
        fetchUsers()
      }
    } catch (error) {
      console.error('Failed to update user role:', error)
    }
  }

  const updateItemStatus = async (itemSlug: string, newStatus: string) => {
    try {
      const response = await fetch(`/api/items/${itemSlug}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      })
      if (response.ok) {
        fetchItems()
        fetchStats()
      }
    } catch (error) {
      console.error('Failed to update item status:', error)
    }
  }

  const saveSiteSettings = async () => {
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          siteName: siteSettings.siteName,
          announcement: siteSettings.announcement,
          nagadNumber: siteSettings.nagadNumber,
          bkashNumber: siteSettings.bkashNumber
        })
      })
      const data = await res.json()
      if (res.ok) {
        alert('✓ Payment numbers saved successfully!')
      } else {
        alert('Error: ' + (data.error || 'Failed to save'))
      }
    } catch (error) {
      console.error('Failed to save settings:', error)
      alert('Failed to save settings: ' + String(error))
    }
  }

  const deleteUser = async (userId: string, username: string) => {
    if (!confirm(`Are you sure you want to delete user "${username}"? This cannot be undone.`)) return
    try {
      const response = await fetch(`/api/admin/users/${userId}`, { method: 'DELETE' })
      if (response.ok) {
        alert('User deleted successfully')
        fetchUsers()
        fetchStats()
      } else {
        const data = await response.json()
        alert('Error: ' + (data.error || 'Failed to delete user'))
      }
    } catch (error) {
      console.error('Failed to delete user:', error)
      alert('Failed to delete user')
    }
  }

  const viewUserDetails = (user: User) => {
    alert(`User Details:\n\nUsername: ${user.username}\nEmail: ${user.email}\nRole: ${user.role}\nStatus: ${user.isActive ? 'Active' : 'Inactive'}\nBalance: $${user.walletBalance.toFixed(2)}\nBanned: ${user.isBanned ? 'Yes' : 'No'}\nJoined: ${new Date(user.createdAt).toLocaleDateString()}\nItems: ${user._count?.items || 0}`)
  }

  const editUserBalance = async (user: User) => {
    const newBalance = prompt(`Edit wallet balance for ${user.username}\nCurrent: $${user.walletBalance.toFixed(2)}\n\nEnter new balance:`, user.walletBalance.toString())
    if (newBalance === null) return
    
    const amount = parseFloat(newBalance)
    if (isNaN(amount) || amount < 0) {
      alert('Invalid balance. Please enter a valid number.')
      return
    }

    try {
      const response = await fetch(`/api/admin/users/${user.id}/balance`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ walletBalance: amount })
      })
      if (response.ok) {
        alert('✓ User balance updated successfully!')
        fetchUsers()
      } else {
        const data = await response.json()
        alert('Error: ' + (data.error || 'Failed to update balance'))
      }
    } catch (error) {
      console.error('Failed to update balance:', error)
      alert('Failed to update balance')
    }
  }

  const toggleUserBan = async (user: User) => {
    const action = user.isBanned ? 'unban' : 'ban'
    if (!confirm(`Are you sure you want to ${action} ${user.username}?`)) return

    try {
      const response = await fetch(`/api/admin/users/${user.id}/ban`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isBanned: !user.isBanned })
      })
      if (response.ok) {
        alert(`✓ User ${action === 'ban' ? 'banned' : 'unbanned'} successfully!`)
        fetchUsers()
      } else {
        const data = await response.json()
        alert('Error: ' + (data.error || `Failed to ${action} user`))
      }
    } catch (error) {
      console.error(`Failed to ${action} user:`, error)
      alert(`Failed to ${action} user`)
    }
  }

  const deleteItem = async (slug: string) => {
    if (!confirm('Delete this item?')) return
    try {
      await fetch(`/api/admin/items/${slug}/delete`, { method: 'DELETE' })
      fetchItems()
      fetchStats()
    } catch (error) {
      console.error('Failed to delete item:', error)
    }
  }

  const addCategory = async () => {
    if (!newCategory.name.trim()) return
    try {
      const response = await fetch('/api/admin/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newCategory)
      })
      if (response.ok) {
        setNewCategory({ name: '', description: '' })
        fetchCategories()
      }
    } catch (error) {
      console.error('Failed to add category:', error)
    }
  }

  const deleteCategory = async (id: string) => {
    if (!confirm('Delete this category?')) return
    try {
      await fetch(`/api/admin/categories/${id}`, { method: 'DELETE' })
      fetchCategories()
    } catch (error) {
      console.error('Failed to delete category:', error)
    }
  }

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M'
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K'
    return num.toString()
  }

  const formatLastActive = (date: string) => {
    const now = new Date()
    const lastActive = new Date(date)
    const diff = now.getTime() - lastActive.getTime()
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(minutes / 60)
    const days = Math.floor(hours / 24)

    if (minutes < 1) return 'Just now'
    if (minutes < 60) return `${minutes}m ago`
    if (hours < 24) return `${hours}h ago`
    if (days < 7) return `${days}d ago`
    return lastActive.toLocaleDateString()
  }

  const isUserActive = (date: string) => {
    const now = new Date()
    const lastActive = new Date(date)
    const diff = now.getTime() - lastActive.getTime()
    const minutes = Math.floor(diff / 60000)
    return minutes < 60 // Active if seen in last hour
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'APPROVED': return 'bg-green-100 text-green-800'
      case 'PENDING': return 'bg-yellow-100 text-yellow-800'
      case 'REJECTED': return 'bg-red-100 text-red-800'
      case 'DRAFT': return 'bg-gray-100 text-gray-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'SUPER_ADMIN': return 'bg-purple-100 text-purple-800'
      case 'ADMIN': return 'bg-red-100 text-red-800'
      case 'MODERATOR': return 'bg-blue-100 text-blue-800'
      case 'CREATOR': return 'bg-green-100 text-green-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  if (authStatus === 'loading' || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!session || (session.user?.role !== 'ADMIN' && session.user?.role !== 'SUPER_ADMIN')) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-96">
          <CardHeader>
            <CardTitle className="text-center flex items-center justify-center gap-2">
              <Shield className="h-6 w-6 text-red-500" />
              Access Denied
            </CardTitle>
            <CardDescription className="text-center">
              You don't have permission to access the admin panel.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button className="w-full" onClick={() => router.push('/')}>
              Go to Homepage
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
              <Shield className="h-8 w-8 text-primary" />
              Admin Dashboard
            </h1>
            <p className="text-muted-foreground">
              Manage your Minecraft content marketplace
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => fetchStats()}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Link href="/">
              <Button variant="ghost">
                <Globe className="h-4 w-4 mr-2" />
                View Site
              </Button>
            </Link>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          <Card className="bg-gradient-to-br from-blue-500/10 to-blue-500/5">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <Users className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatNumber(stats.totalUsers)}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500/10 to-green-500/5">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Items</CardTitle>
              <Package className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatNumber(stats.totalItems)}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500/10 to-purple-500/5">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Downloads</CardTitle>
              <Download className="h-4 w-4 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatNumber(stats.totalDownloads)}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500/10 to-orange-500/5">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Revenue</CardTitle>
              <TrendingUp className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${stats.totalRevenue?.toFixed(2) || '0.00'}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-cyan-500/10 to-cyan-500/5">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Users</CardTitle>
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatNumber(stats.activeUsers)}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-yellow-500/10 to-yellow-500/5">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
              <AlertTriangle className="h-4 w-4 text-yellow-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.pendingItems}</div>
            </CardContent>
          </Card>
        </div>

        {/* Management Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <div className="bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 rounded-xl p-1 border border-slate-200 dark:border-slate-700 shadow-lg">
            <TabsList className="grid w-full grid-cols-4 md:grid-cols-8 bg-transparent h-auto p-0 gap-1">
              <TabsTrigger value="overview" className="flex items-center gap-2 rounded-lg transition-all hover:bg-slate-200 dark:hover:bg-slate-700">
                <LayoutDashboard className="h-4 w-4" />
                <span className="hidden sm:inline text-sm">Overview</span>
              </TabsTrigger>
              <TabsTrigger value="moderation" className="flex items-center gap-2 rounded-lg transition-all hover:bg-slate-200 dark:hover:bg-slate-700">
                <Shield className="h-4 w-4" />
                <span className="hidden sm:inline text-sm">Moderation</span>
              </TabsTrigger>
              <TabsTrigger value="users" className="flex items-center gap-2 rounded-lg transition-all hover:bg-slate-200 dark:hover:bg-slate-700">
                <Users className="h-4 w-4" />
                <span className="hidden sm:inline text-sm">Users</span>
              </TabsTrigger>
              <TabsTrigger value="items" className="flex items-center gap-2 rounded-lg transition-all hover:bg-slate-200 dark:hover:bg-slate-700">
                <ShoppingCart className="h-4 w-4" />
                <span className="hidden sm:inline text-sm">Items</span>
              </TabsTrigger>
              <TabsTrigger value="categories" className="hidden md:flex items-center gap-2 rounded-lg transition-all hover:bg-slate-200 dark:hover:bg-slate-700">
                <FolderOpen className="h-4 w-4" />
                <span className="hidden lg:inline text-sm">Categories</span>
              </TabsTrigger>
              <TabsTrigger value="transactions" className="flex items-center gap-2 rounded-lg transition-all hover:bg-slate-200 dark:hover:bg-slate-700">
                <CreditCard className="h-4 w-4" />
                <span className="hidden sm:inline text-sm">Transactions</span>
              </TabsTrigger>
              <TabsTrigger value="memberships" className="flex items-center gap-2 rounded-lg transition-all hover:bg-slate-200 dark:hover:bg-slate-700">
                <Zap className="h-4 w-4" />
                <span className="hidden sm:inline text-sm">Memberships</span>
              </TabsTrigger>
              <TabsTrigger value="plans" className="flex items-center gap-2 rounded-lg transition-all hover:bg-slate-200 dark:hover:bg-slate-700">
                <Server className="h-4 w-4" />
                <span className="hidden sm:inline text-sm">Plans</span>
              </TabsTrigger>
              <TabsTrigger value="settings" className="flex items-center gap-2 rounded-lg transition-all hover:bg-slate-200 dark:hover:bg-slate-700">
                <Settings className="h-4 w-4" />
                <span className="hidden sm:inline text-sm">Settings</span>
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Users</CardTitle>
                  <CardDescription>Latest registered users</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {users.slice(0, 5).map((user) => (
                      <div key={user.id} className="flex items-center justify-between p-2 border rounded-lg">
                        <div>
                          <p className="font-medium">{user.username}</p>
                          <p className="text-sm text-muted-foreground">{user.email}</p>
                        </div>
                        <Badge className={getRoleColor(user.role)}>{user.role}</Badge>
                      </div>
                    ))}
                  </div>
                  <Button variant="outline" className="w-full mt-4" onClick={() => setActiveTab('users')}>
                    View All Users
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Pending Items</CardTitle>
                  <CardDescription>Items awaiting approval</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {items.filter(i => i.status === 'PENDING').slice(0, 5).map((item) => (
                      <div key={item.id} className="flex items-center justify-between p-2 border rounded-lg">
                        <div>
                          <p className="font-medium">{item.title}</p>
                          <p className="text-sm text-muted-foreground">by {item.author?.username}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="ghost" onClick={() => updateItemStatus(item.slug, 'APPROVED')}>
                            <Check className="h-4 w-4 text-green-500" />
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => updateItemStatus(item.slug, 'REJECTED')}>
                            <X className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </div>
                    ))}
                    {items.filter(i => i.status === 'PENDING').length === 0 && (
                      <p className="text-center text-muted-foreground py-4">No pending items</p>
                    )}
                  </div>
                  <Button variant="outline" className="w-full mt-4" onClick={() => setActiveTab('items')}>
                    View All Items
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="moderation" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Pending Items Moderation</CardTitle>
                <CardDescription>Review and approve/reject pending content submissions</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Author</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Submitted</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items.filter(i => i.status === 'PENDING').map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.title}</TableCell>
                        <TableCell>{item.author?.username}</TableCell>
                        <TableCell>{item.category?.name}</TableCell>
                        <TableCell>{new Date(item.createdAt).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button size="sm" variant="default" onClick={() => updateItemStatus(item.slug, 'APPROVED')}>
                              <Check className="h-4 w-4 mr-1" />
                              Approve
                            </Button>
                            <Button size="sm" variant="destructive" onClick={() => updateItemStatus(item.slug, 'REJECTED')}>
                              <X className="h-4 w-4 mr-1" />
                              Reject
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => deleteItem(item.slug)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                {items.filter(i => i.status === 'PENDING').length === 0 && (
                  <p className="text-center text-muted-foreground py-8">No pending items for moderation</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
                <CardDescription>Manage user accounts and permissions</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Username</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Balance</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id} className={user.isBanned ? 'opacity-60' : ''}>
                        <TableCell className="font-medium">{user.username}{user.isBanned && ' (BANNED)'}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>
                          <Select value={user.role} onValueChange={(value) => updateUserRole(user.id, value)}>
                            <SelectTrigger className="w-32">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="USER">User</SelectItem>
                              <SelectItem value="CREATOR">Creator</SelectItem>
                              <SelectItem value="MODERATOR">Moderator</SelectItem>
                              <SelectItem value="ADMIN">Admin</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <Button size="sm" variant="outline" onClick={() => editUserBalance(user)}>
                            ${user.walletBalance.toFixed(2)}
                          </Button>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Badge variant={user.isActive ? 'default' : 'secondary'}>
                              {user.isActive ? 'Active' : 'Inactive'}
                            </Badge>
                            {user.isBanned && <Badge variant="destructive">Banned</Badge>}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1 flex-wrap">
                            <Button size="sm" variant="ghost" onClick={() => viewUserDetails(user)} title="View details">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => toggleUserBan(user)} title={user.isBanned ? 'Unban' : 'Ban'}>
                              <AlertTriangle className={`h-4 w-4 ${user.isBanned ? 'text-yellow-500' : 'text-orange-500'}`} />
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => deleteUser(user.id, user.username)} title="Delete user">
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="items" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Item Management</CardTitle>
                <CardDescription>Review and manage submitted content</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Author</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Downloads</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.title}</TableCell>
                        <TableCell>{item.author?.username}</TableCell>
                        <TableCell>{item.category?.name}</TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(item.status)}>{item.status}</Badge>
                        </TableCell>
                        <TableCell>{formatNumber(item.downloads)}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Link href={`/items/${item.slug}`}>
                              <Button size="sm" variant="ghost">
                                <Eye className="h-4 w-4" />
                              </Button>
                            </Link>
                            <Button size="sm" variant="ghost" onClick={() => deleteItem(item.slug)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="categories" className="space-y-4">
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="md:col-span-1">
                <CardHeader>
                  <CardTitle>Add Category</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Input 
                    placeholder="Category name" 
                    value={newCategory.name}
                    onChange={(e) => setNewCategory({...newCategory, name: e.target.value})}
                  />
                  <Input 
                    placeholder="Description" 
                    value={newCategory.description}
                    onChange={(e) => setNewCategory({...newCategory, description: e.target.value})}
                  />
                  <Button onClick={addCategory} className="w-full">Add Category</Button>
                </CardContent>
              </Card>

              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Categories</CardTitle>
                  <CardDescription>Manage content categories</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Items</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {categories.map((cat) => (
                        <TableRow key={cat.id}>
                          <TableCell className="font-medium">{cat.name}</TableCell>
                          <TableCell className="text-sm text-muted-foreground">{cat.description}</TableCell>
                          <TableCell>{cat._count?.items || 0}</TableCell>
                          <TableCell>
                            <Button size="sm" variant="ghost" onClick={() => deleteCategory(cat.id)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    Platform Overview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Total Users</span>
                      <span className="font-bold">{formatNumber(stats.totalUsers)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Total Items</span>
                      <span className="font-bold">{formatNumber(stats.totalItems)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Total Downloads</span>
                      <span className="font-bold">{formatNumber(stats.totalDownloads)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Pending Items</span>
                      <span className="font-bold">{stats.pendingItems}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5" />
                    System Health
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Database</span>
                      <Badge className="bg-green-100 text-green-800">Healthy</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Storage</span>
                      <Badge className="bg-green-100 text-green-800">Available</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Real-time</span>
                      <Badge className="bg-green-100 text-green-800">Connected</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">API</span>
                      <Badge className="bg-green-100 text-green-800">Online</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="transactions" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Pending Transactions</CardTitle>
                <CardDescription>Review and approve deposit transactions from users</CardDescription>
              </CardHeader>
              <CardContent>
                <iframe src="/admin/transactions" className="w-full h-96 border rounded-lg" />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="memberships" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Membership Management</CardTitle>
                <CardDescription>Create and manage membership roles (DIAMOND, GOLD, etc.)</CardDescription>
              </CardHeader>
              <CardContent>
                <iframe src="/admin/memberships" className="w-full h-screen border rounded-lg" />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="plans" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>VPS & Server Plans</CardTitle>
                <CardDescription>Manage hosting plans, pricing, features, and styling options</CardDescription>
              </CardHeader>
              <CardContent>
                <iframe src="/admin/plans" className="w-full h-screen border rounded-lg" />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4">
            <div className="grid md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Site Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="siteName">Site Name</Label>
                    <Input 
                      id="siteName" 
                      value={siteSettings.siteName}
                      onChange={(e) => setSiteSettings(prev => ({ ...prev, siteName: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="uploadLimit">Upload Limit (MB)</Label>
                    <Input 
                      id="uploadLimit" 
                      type="number"
                      value={siteSettings.uploadLimit}
                      onChange={(e) => setSiteSettings(prev => ({ ...prev, uploadLimit: parseInt(e.target.value) }))}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Maintenance Mode</Label>
                      <p className="text-sm text-muted-foreground">Put the site in maintenance mode</p>
                    </div>
                    <Switch 
                      checked={siteSettings.maintenance}
                      onCheckedChange={(checked) => setSiteSettings(prev => ({ ...prev, maintenance: checked }))}
                    />
                  </div>
                  <Button className="w-full">Save Settings</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="h-5 w-5" />
                    Announcements
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="announcement">Site Announcement</Label>
                    <Input 
                      id="announcement" 
                      placeholder="Enter announcement message..."
                      value={siteSettings.announcement}
                      onChange={(e) => setSiteSettings(prev => ({ ...prev, announcement: e.target.value }))}
                    />
                  </div>
                  <Button className="w-full">Post Announcement</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Mail className="h-5 w-5" />
                    Email Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Configure email notifications and templates for user communications.
                  </p>
                  <Button variant="outline" className="w-full">Configure Email</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PaletteIcon className="h-5 w-5" />
                    Theme Customization
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Change the admin panel theme appearance
                  </p>
                  <div className="space-y-3">
                    <div className="flex gap-2">
                      <Button 
                        variant={theme === 'light' ? 'default' : 'outline'} 
                        className="flex-1"
                        onClick={() => setTheme('light')}
                      >
                        ☀️ Light
                      </Button>
                      <Button 
                        variant={theme === 'dark' ? 'default' : 'outline'} 
                        className="flex-1"
                        onClick={() => setTheme('dark')}
                      >
                        🌙 Dark
                      </Button>
                      <Button 
                        variant={theme === 'system' ? 'default' : 'outline'} 
                        className="flex-1"
                        onClick={() => setTheme('system')}
                      >
                        🖥️ System
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5" />
                    Database Tools
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Manage database operations and backups.
                  </p>
                  <div className="flex gap-2">
                    <Button variant="outline" className="flex-1">Backup</Button>
                    <Button variant="outline" className="flex-1">Optimize</Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Mail className="h-5 w-5" />
                    Payment Methods Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="nagadNumber">Nagad Phone Number</Label>
                    <Input 
                      id="nagadNumber" 
                      placeholder="e.g., 01700000001"
                      value={siteSettings.nagadNumber || ''}
                      onChange={(e) => setSiteSettings(prev => ({ ...prev, nagadNumber: e.target.value }))}
                    />
                    <p className="text-xs text-muted-foreground">Users will send payment to this number</p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bkashNumber">bKash Phone Number</Label>
                    <Input 
                      id="bkashNumber" 
                      placeholder="e.g., 01700000002"
                      value={siteSettings.bkashNumber || ''}
                      onChange={(e) => setSiteSettings(prev => ({ ...prev, bkashNumber: e.target.value }))}
                    />
                    <p className="text-xs text-muted-foreground">Users will send payment to this number</p>
                  </div>
                  <Button className="w-full" onClick={() => saveSiteSettings()}>Save Payment Numbers</Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
