import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  eslint: {
    ignoreDuringBuilds: true,
  },
  allowedDevOrigins: [
    'https://62a48dbb-5702-4438-8ceb-a1d6b1344f74-00-1ce5n9gwtv4hf.sisko.replit.dev',
    '*.sisko.replit.dev',
    '*.replit.dev'
  ],
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'Cache-Control',
            value: 'no-store, no-cache, must-revalidate, proxy-revalidate',
          },
        ],
      },
    ];
  },
};

export default nextConfig;
