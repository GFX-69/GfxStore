import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    await db.$connect()

    // Get categories with real-time counts
    const categories = await db.category.findMany({
      include: {
        _count: {
          select: {
            items: true
          }
        }
      },
      orderBy: [
        { sortOrder: 'asc' },
        { name: 'asc' }
      ]
    })

    await db.$disconnect()

    return NextResponse.json(categories)
  } catch (error) {
    await db.$disconnect()
    return NextResponse.json(
      { 
        status: 'error', 
        message: 'Failed to fetch categories',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const { name, slug, description, icon, background } = await request.json()

    if (!name || !slug) {
      return NextResponse.json(
        { error: 'Name and slug are required' },
        { status: 400 }
      )
    }

    await db.$connect()

    // Check if slug already exists
    const existingCategory = await db.category.findUnique({
      where: { slug }
    })

    if (existingCategory) {
      await db.$disconnect()
      return NextResponse.json(
        { error: 'Category with this slug already exists' },
        { status: 400 }
      )
    }

    // Create new category
    const newCategory = await db.category.create({
      data: {
        name,
        slug,
        description,
        icon,
        background,
        isActive: true,
        sortOrder: 999 // Put new categories at the end
      }
    })

    await db.$disconnect()

    return NextResponse.json({
      message: 'Category created successfully',
      category: newCategory
    })
  } catch (error) {
    await db.$disconnect()
    return NextResponse.json(
      { 
        status: 'error', 
        message: 'Failed to create category',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}