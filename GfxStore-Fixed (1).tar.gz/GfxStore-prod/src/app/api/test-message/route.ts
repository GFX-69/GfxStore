import { NextRequest, NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function GET(req: NextRequest) {
  try {
    const msg = await prisma.chatMessage.create({
      data: {
        userId: 'test-demo-user',
        content: 'Hello everyone! 👋 Chat system is working perfectly! Messages are saved to database and broadcasting in real-time! 🎮',
        type: 'PUBLIC',
        roomId: null
      },
      include: { user: { select: { username: true } } }
    })

    return NextResponse.json({ 
      success: true, 
      message: 'Test message sent!',
      data: msg 
    })
  } catch (error: any) {
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    )
  }
}
