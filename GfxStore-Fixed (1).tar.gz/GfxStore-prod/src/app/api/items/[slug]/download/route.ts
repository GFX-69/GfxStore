import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const session = await getServerSession(authOptions)
    const { slug } = await params
    const { versionId } = await request.json()

    // Find the item
    const item = await db.item.findUnique({
      where: { slug },
      include: {
        versions: {
          where: {
            id: versionId,
            isActive: true,
          },
        },
      },
    })

    if (!item) {
      return NextResponse.json(
        { error: 'Item not found' },
        { status: 404 }
      )
    }

    if (item.status !== 'APPROVED') {
      return NextResponse.json(
        { error: 'Item not available' },
        { status: 403 }
      )
    }

    if (item.versions.length === 0) {
      return NextResponse.json(
        { error: 'Version not found' },
        { status: 404 }
      )
    }

    const version = item.versions[0]

    // Record download
    await db.download.create({
      data: {
        itemId: item.id,
        userId: session?.user?.id || null,
        versionId: versionId,
        ipAddress: request.ip || request.headers.get('x-forwarded-for') || 'unknown',
        userAgent: request.headers.get('user-agent') || 'unknown',
      },
    })

    // Update download count
    await db.item.update({
      where: { id: item.id },
      data: {
        downloads: {
          increment: 1,
        },
      },
    })

    return NextResponse.json({
      success: true,
      downloadUrl: version.downloadUrl,
    })
  } catch (error) {
    console.error('Error downloading item:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}