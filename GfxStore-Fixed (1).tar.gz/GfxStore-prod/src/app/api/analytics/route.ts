import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  const url = request.nextUrl
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'

  // Get site statistics
  const [
    totalUsers,
    totalItems,
    totalDownloads,
    totalViews,
    recentItems,
    topCategories,
    activeUsers
  ] = await Promise.all([
    db.user.count(),
    db.item.count({ where: { status: 'APPROVED' } }),
    db.item.aggregate({ _sum: { downloads: true } }),
    db.item.aggregate({ _sum: { views: true } }),
    db.item.findMany({
      where: { status: 'APPROVED' },
      orderBy: { createdAt: 'desc' },
      take: 10,
      include: {
        category: { select: { name: true } },
        author: { select: { username: true } },
      },
    }),
    db.category.findMany({
      include: {
        _count: {
          select: {
            items: {
              where: { status: 'APPROVED' },
            },
          },
        },
      },
      orderBy: { _count: { items: 'desc' } },
      take: 5,
    }),
    db.user.count({
      where: {
        createdAt: {
          gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        },
      },
    }),
  ])

  // Calculate growth metrics
  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
  const [newUsers, newItems] = await Promise.all([
    db.user.count({
      where: { createdAt: { gte: thirtyDaysAgo } },
    }),
    db.item.count({
      where: { 
        status: 'APPROVED',
        createdAt: { gte: thirtyDaysAgo },
      },
    }),
  ])

  const stats = {
    overview: {
      totalUsers,
      totalItems,
      totalDownloads: totalDownloads._sum.downloads || 0,
      totalViews: totalViews._sum.views || 0,
      activeUsers,
    },
    growth: {
      newUsersThisMonth: newUsers,
      newItemsThisMonth: newItems,
      userGrowthRate: totalUsers > 0 ? ((newUsers / totalUsers) * 100).toFixed(2) : '0',
      itemGrowthRate: totalItems > 0 ? ((newItems / totalItems) * 100).toFixed(2) : '0',
    },
    recentActivity: {
      recentItems: recentItems.map(item => ({
        id: item.id,
        title: item.title,
        slug: item.slug,
        category: item.category.name,
        author: item.author.username,
        createdAt: item.createdAt,
        downloads: item.downloads,
        likes: item.likes,
      })),
    },
    topCategories: topCategories.map(cat => ({
      name: cat.name,
      itemCount: cat._count.items,
    })),
    engagement: {
      avgDownloadsPerItem: totalItems > 0 ? Math.round((totalDownloads._sum.downloads || 0) / totalItems) : 0,
      avgViewsPerItem: totalItems > 0 ? Math.round((totalViews._sum.views || 0) / totalItems) : 0,
      totalEngagement: (totalDownloads._sum.downloads || 0) + (totalViews._sum.views || 0),
    },
  }

  // Return JSON with appropriate headers for analytics
  return NextResponse.json(stats, {
    headers: {
      'Cache-Control': 'public, s-maxage=300', // Cache for 5 minutes
      'Content-Type': 'application/json',
    },
  })
}