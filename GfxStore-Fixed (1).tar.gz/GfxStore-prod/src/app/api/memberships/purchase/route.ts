import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { membershipId } = body

    if (!membershipId) {
      return NextResponse.json({ error: 'Membership ID required' }, { status: 400 })
    }

    // Get membership
    const membership = await db.membership.findUnique({
      where: { id: membershipId }
    })

    if (!membership || !membership.isActive) {
      return NextResponse.json({ error: 'Membership not found' }, { status: 404 })
    }

    // Get user with wallet balance
    const user = await db.user.findUnique({
      where: { id: session.user.id },
      select: { id: true, walletBalance: true, role: true }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Check wallet balance
    if ((user.walletBalance || 0) < membership.price) {
      return NextResponse.json({ error: 'Insufficient wallet balance' }, { status: 400 })
    }

    // Update user: deduct balance and set role
    const updatedUser = await db.user.update({
      where: { id: session.user.id },
      data: {
        walletBalance: (user.walletBalance || 0) - membership.price,
        role: membership.roleName
      }
    })

    // Create transaction record
    await db.transaction.create({
      data: {
        userId: session.user.id,
        amount: membership.price,
        type: 'MEMBERSHIP_PURCHASE',
        method: 'WALLET',
        status: 'COMPLETED',
        membershipId: membershipId,
        reference: `Purchased ${membership.name}`
      }
    })

    return NextResponse.json({
      success: true,
      message: `Successfully purchased ${membership.name}!`,
      newRole: membership.roleName,
      newBalance: updatedUser.walletBalance
    }, { status: 200 })

  } catch (error) {
    console.error('Error purchasing membership:', error)
    return NextResponse.json({ error: 'Failed to purchase membership' }, { status: 500 })
  }
}
