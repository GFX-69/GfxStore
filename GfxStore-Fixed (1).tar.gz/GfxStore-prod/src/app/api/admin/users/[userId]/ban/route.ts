import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const adminUser = await db.user.findUnique({
      where: { id: session.user.id },
      select: { role: true }
    })

    if (!adminUser || !['ADMIN', 'SUPER_ADMIN'].includes(adminUser.role)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const { userId } = await params
    const { isBanned } = await request.json()

    if (typeof isBanned !== 'boolean') {
      return NextResponse.json({ error: 'Invalid ban status' }, { status: 400 })
    }

    const user = await db.user.update({
      where: { id: userId },
      data: { isBanned }
    })

    return NextResponse.json(user)
  } catch (error) {
    console.error('Failed to update user ban status:', error)
    return NextResponse.json({ error: 'Failed to update ban status' }, { status: 500 })
  }
}
