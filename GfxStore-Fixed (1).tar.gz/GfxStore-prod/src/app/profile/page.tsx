'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { User, Mail, MapPin, Globe, Github, Twitter, Edit, Upload, X, Camera, MessageCircle } from 'lucide-react'

interface UserProfile {
  id: string
  username: string
  email: string
  role: string
  avatar?: string
  bio?: string
  coverImage?: string
  socialLinks?: {
    website?: string
    github?: string
    twitter?: string
    discord?: string
  }
  createdAt: string
  _count: {
    items: number
    downloads: number
    reviews: number
  }
}

export default function Profile() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [pageLoading, setPageLoading] = useState(true)
  const [editForm, setEditForm] = useState<{
    bio: string
    socialLinks: {
      website: string
      github: string
      twitter: string
      discord: string
    }
  }>({
    bio: '',
    socialLinks: {
      website: '',
      github: '',
      twitter: '',
      discord: ''
    }
  })
  const [avatarPreview, setAvatarPreview] = useState('')
  const [avatarFile, setAvatarFile] = useState<File | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState('')

  useEffect(() => {
    if (status === 'loading') return
    
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
      return
    }

    fetchProfile()
  }, [status, router])

  const fetchProfile = async () => {
    try {
      const response = await fetch(`/api/users/${session?.user?.id}/profile`)
      if (response.ok) {
        const data = await response.json()
        setProfile(data)
        const socialLinks = data.socialLinks || {}
        setEditForm({
          bio: data.bio || '',
          socialLinks: {
            website: socialLinks.website || '',
            github: socialLinks.github || '',
            twitter: socialLinks.twitter || '',
            discord: socialLinks.discord || ''
          }
        })
      }
    } catch (error) {
      console.error('Failed to fetch profile:', error)
    } finally {
      setPageLoading(false)
    }
  }

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setAvatarFile(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSave = async () => {
    setIsLoading(true)
    setMessage('')

    try {
      const formData = new FormData()
      formData.append('bio', editForm.bio)
      formData.append('socialLinks', JSON.stringify(editForm.socialLinks))
      
      if (avatarPreview) {
        // Convert base64 to file
        const base64Data = avatarPreview.split(',')[1]
        const byteCharacters = atob(base64Data)
        const byteNumbers = new Array(byteCharacters.length)
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i)
        }
        const byteArray = new Uint8Array(byteNumbers)
        const blob = new Blob([byteArray], { type: 'image/jpeg' })
        formData.append('avatar', blob)
      }

      const response = await fetch('/api/users/profile', {
        method: 'PUT',
        body: formData
      })

      if (response.ok) {
        const updatedProfile = await response.json()
        setProfile(updatedProfile)
        setIsEditing(false)
        setAvatarPreview('')
        setAvatarFile(null)
        setMessage('Profile updated successfully!')
        setTimeout(() => {
          window.location.reload()
        }, 1500)
      } else {
        const errorData = await response.json()
        setMessage(`Failed to update profile: ${errorData.error}`)
      }
    } catch (error) {
      setMessage('An error occurred while updating profile')
    } finally {
      setIsLoading(false)
    }
  }

  const handleCancel = () => {
    setIsEditing(false)
    setAvatarPreview('')
    setMessage('')
    if (profile) {
      const socialLinks = profile.socialLinks || {}
      setEditForm({
        bio: profile.bio || '',
        socialLinks: {
          website: socialLinks.website || '',
          github: socialLinks.github || '',
          twitter: socialLinks.twitter || '',
          discord: socialLinks.discord || ''
        }
      })
    }
  }

  if (status === 'loading' || pageLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!profile) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Failed to load profile</p>
          <Button onClick={() => fetchProfile()}>Retry</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Profile</h1>
          <p className="text-muted-foreground">
            Manage your public profile and account information
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Profile Overview */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Profile Overview</CardTitle>
                  {!isEditing ? (
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                      <Edit className="h-4 w-4 mr-2" />
                      Edit Profile
                    </Button>
                  ) : (
                    <div className="flex gap-2">
                      <Button variant="ghost" size="sm" onClick={handleCancel}>
                        <X className="h-4 w-4" />
                      </Button>
                      <Button size="sm" onClick={handleSave} disabled={isLoading}>
                        {isLoading ? 'Saving...' : 'Save Changes'}
                      </Button>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {message && (
                  <div className={`p-3 rounded-lg text-sm ${
                    message.includes('success') ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {message}
                  </div>
                )}

                {/* Avatar Section */}
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <Avatar className="h-24 w-24">
                      <AvatarImage src={profile.avatar} alt={profile.username} />
                      <AvatarFallback className="text-lg">
                        {profile.username.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    {isEditing && (
                      <div className="absolute -bottom-2 -right-2">
                        <Label htmlFor="avatar-upload" className="cursor-pointer">
                          <div className="bg-primary text-primary-foreground rounded-full p-2">
                            <Upload className="h-4 w-4" />
                          </div>
                        </Label>
                        <Input
                          id="avatar-upload"
                          type="file"
                          accept="image/*"
                          onChange={handleAvatarChange}
                          className="hidden"
                        />
                      </div>
                    )}
                  </div>
                  
                  <div>
                    <h3 className="text-2xl font-bold">{profile.username}</h3>
                    <Badge variant={profile.role === 'ADMIN' ? 'default' : 'secondary'}>
                      {profile.role}
                    </Badge>
                  </div>
                </div>

                {/* Bio Section */}
                <div className="space-y-2">
                  <Label>Bio</Label>
                  {isEditing ? (
                    <Textarea
                      value={editForm.bio}
                      onChange={(e) => setEditForm(prev => ({ ...prev, bio: e.target.value }))}
                      placeholder="Tell us about yourself..."
                      rows={4}
                    />
                  ) : (
                    <p className="text-muted-foreground">
                      {profile.bio || 'No bio provided'}
                    </p>
                  )}
                </div>

                {/* Social Links */}
                <div className="space-y-4">
                  <Label>Social Links</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="website">Website</Label>
                      {isEditing ? (
                        <Input
                          id="website"
                          value={editForm.socialLinks.website}
                          onChange={(e) => setEditForm(prev => ({
                            ...prev,
                            socialLinks: { ...prev.socialLinks, website: e.target.value }
                          }))}
                          placeholder="https://yourwebsite.com"
                        />
                      ) : (
                        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                          <Globe className="h-4 w-4" />
                          {profile.socialLinks?.website || 'No website'}
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="github">GitHub</Label>
                      {isEditing ? (
                        <Input
                          id="github"
                          value={editForm.socialLinks.github}
                          onChange={(e) => setEditForm(prev => ({
                            ...prev,
                            socialLinks: { ...prev.socialLinks, github: e.target.value }
                          }))}
                          placeholder="username"
                        />
                      ) : (
                        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                          <Github className="h-4 w-4" />
                          {profile.socialLinks?.github || 'No GitHub'}
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="twitter">Twitter</Label>
                      {isEditing ? (
                        <Input
                          id="twitter"
                          value={editForm.socialLinks.twitter}
                          onChange={(e) => setEditForm(prev => ({
                            ...prev,
                            socialLinks: { ...prev.socialLinks, twitter: e.target.value }
                          }))}
                          placeholder="@username"
                        />
                      ) : (
                        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                          <Twitter className="h-4 w-4" />
                          {profile.socialLinks?.twitter || 'No Twitter'}
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="discord">Discord</Label>
                      {isEditing ? (
                        <Input
                          id="discord"
                          value={editForm.socialLinks.discord}
                          onChange={(e) => setEditForm(prev => ({
                            ...prev,
                            socialLinks: { ...prev.socialLinks, discord: e.target.value }
                          }))}
                          placeholder="username#1234"
                        />
                      ) : (
                        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                          <MessageCircle className="h-4 w-4" />
                          {profile.socialLinks?.discord || 'No Discord'}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Account Info */}
                <div className="space-y-4 pt-4 border-t">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center space-x-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span>{profile.email}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span>Joined {new Date(profile.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Stats Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Statistics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">{profile._count.items}</div>
                  <div className="text-sm text-muted-foreground">Items Created</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">{profile._count.downloads}</div>
                  <div className="text-sm text-muted-foreground">Total Downloads</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">{profile._count.reviews}</div>
                  <div className="text-sm text-muted-foreground">Reviews</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}