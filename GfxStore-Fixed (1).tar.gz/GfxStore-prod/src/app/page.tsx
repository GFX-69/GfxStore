'use client'

import { useState, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { ChatWidget } from '@/components/chat/chat-widget'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Download, Star, Users, Package, Search, Upload, Shield, MessageSquare, TrendingUp, Sparkles, Zap, Globe, ArrowRight, Check, Server } from 'lucide-react'
import Link from 'next/link'

interface Stats {
  totalUsers: number
  totalItems: number
  totalDownloads: number
}

interface FeaturedItem {
  id: string
  title: string
  slug: string
  shortDesc?: string
  downloads: number
  likes: number
  category: {
    name: string
  }
  author: {
    username: string
  }
}

interface ServerPlan {
  id: string
  name: string
  description: string
  price: number
  features?: string[]
  specs?: Record<string, any>
  isActive: boolean
  sortOrder: number
}

export default function Home() {
  const [isChatOpen, setIsChatOpen] = useState(false)
  const [stats, setStats] = useState<Stats>({ totalUsers: 0, totalItems: 0, totalDownloads: 0 })
  const [featuredItems, setFeaturedItems] = useState<FeaturedItem[]>([])
  const [vpsPlans, setVpsPlans] = useState<ServerPlan[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStats()
    fetchFeaturedItems()
    fetchVpsPlans()
  }, [])
  
  const fetchVpsPlans = async () => {
    try {
      const response = await fetch('/api/admin/plans?public=true')
      if (response.ok) {
        const data = await response.json()
        setVpsPlans(Array.isArray(data.plans) ? data.plans : [])
      }
    } catch (error) {
      console.error('Failed to fetch VPS plans:', error)
      setVpsPlans([])
    }
  }

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/public-stats')
      if (response.ok) {
        const data = await response.json()
        setStats(data)
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error)
    }
  }

  const fetchFeaturedItems = async () => {
    try {
      const response = await fetch('/api/items?featured=true&limit=6')
      if (response.ok) {
        const data = await response.json()
        setFeaturedItems(data.items || [])
      }
    } catch (error) {
      console.error('Failed to fetch featured items:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M'
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K'
    return num.toString()
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar onChatToggle={() => setIsChatOpen(!isChatOpen)} />
      
      {/* Hero Section */}
      <section className="relative py-24 px-4 text-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-purple-500/10"></div>
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
        <div className="container mx-auto relative z-10">
          <Badge variant="secondary" className="mb-6 px-4 py-1">
            <Sparkles className="w-3 h-3 mr-1" />
            The #1 Minecraft Content Platform
          </Badge>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-primary via-purple-500 to-primary bg-clip-text text-transparent">
            Discover Amazing<br />Minecraft Content
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Download plugins, mods, texture packs, and more from our community of creators. 
            Join thousands of Minecraft enthusiasts enhancing their gameplay experience.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/browse">
              <Button size="lg" className="text-lg px-8 shadow-lg shadow-primary/25">
                <Search className="mr-2 h-5 w-5" />
                Browse Content
              </Button>
            </Link>
            <Link href="/upload">
              <Button variant="outline" size="lg" className="text-lg px-8">
                <Upload className="mr-2 h-5 w-5" />
                Start Creating
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 bg-muted/50 border-y">
        <div className="container mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="space-y-2">
              <div className="text-4xl font-bold text-primary">{formatNumber(stats.totalDownloads) || '10K+'}</div>
              <div className="text-sm text-muted-foreground flex items-center justify-center gap-1">
                <Download className="h-4 w-4" />
                Downloads
              </div>
            </div>
            <div className="space-y-2">
              <div className="text-4xl font-bold text-primary">{formatNumber(stats.totalItems) || '500+'}</div>
              <div className="text-sm text-muted-foreground flex items-center justify-center gap-1">
                <Package className="h-4 w-4" />
                Items
              </div>
            </div>
            <div className="space-y-2">
              <div className="text-4xl font-bold text-primary">{formatNumber(stats.totalUsers) || '100+'}</div>
              <div className="text-sm text-muted-foreground flex items-center justify-center gap-1">
                <Users className="h-4 w-4" />
                Creators
              </div>
            </div>
            <div className="space-y-2">
              <div className="text-4xl font-bold text-primary">24/7</div>
              <div className="text-sm text-muted-foreground flex items-center justify-center gap-1">
                <Globe className="h-4 w-4" />
                Support
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Items Section */}
      {featuredItems.length > 0 && (
        <section className="py-16 px-4">
          <div className="container mx-auto">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold flex items-center gap-2">
                  <TrendingUp className="h-8 w-8 text-primary" />
                  Featured Content
                </h2>
                <p className="text-muted-foreground mt-2">Handpicked by our community</p>
              </div>
              <Link href="/browse?featured=true">
                <Button variant="ghost">
                  View All <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredItems.map((item) => (
                <Link key={item.id} href={`/items/${item.slug}`}>
                  <Card className="hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer h-full">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <Badge variant="secondary">{item.category?.name}</Badge>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          {item.likes}
                        </div>
                      </div>
                      <CardTitle className="mt-2">{item.title}</CardTitle>
                      <CardDescription className="line-clamp-2">
                        {item.shortDesc || 'No description available'}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <span>by {item.author?.username}</span>
                        <span className="flex items-center gap-1">
                          <Download className="h-4 w-4" />
                          {formatNumber(item.downloads)}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Categories Section */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Explore Categories</h2>
            <p className="text-muted-foreground">Find the perfect content for your Minecraft experience</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Link href="/browse?category=plugins">
              <Card className="hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer group">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-blue-500/10 group-hover:bg-blue-500/20 transition-colors">
                      <Zap className="h-6 w-6 text-blue-500" />
                    </div>
                    Plugins
                  </CardTitle>
                  <CardDescription>
                    Enhance your server with powerful plugins for economy, minigames, and more
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>

            <Link href="/browse?category=mods">
              <Card className="hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer group">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-purple-500/10 group-hover:bg-purple-500/20 transition-colors">
                      <Star className="h-6 w-6 text-purple-500" />
                    </div>
                    Mods
                  </CardTitle>
                  <CardDescription>
                    Transform your gameplay with amazing mods that add new features
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>

            <Link href="/browse?category=texture-packs">
              <Card className="hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer group">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-green-500/10 group-hover:bg-green-500/20 transition-colors">
                      <Package className="h-6 w-6 text-green-500" />
                    </div>
                    Texture Packs
                  </CardTitle>
                  <CardDescription>
                    Redesign your world with beautiful textures and resource packs
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>

            <Link href="/browse?category=maps">
              <Card className="hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer group">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-orange-500/10 group-hover:bg-orange-500/20 transition-colors">
                      <Globe className="h-6 w-6 text-orange-500" />
                    </div>
                    Maps
                  </CardTitle>
                  <CardDescription>
                    Explore incredible custom maps, adventure worlds, and parkour challenges
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>

            <Link href="/browse?category=shaders">
              <Card className="hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer group">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-pink-500/10 group-hover:bg-pink-500/20 transition-colors">
                      <Sparkles className="h-6 w-6 text-pink-500" />
                    </div>
                    Shaders
                  </CardTitle>
                  <CardDescription>
                    Add stunning visual effects, realistic lighting, and beautiful graphics
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>

            <Link href="/browse?category=server-setups">
              <Card className="hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer group">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-cyan-500/10 group-hover:bg-cyan-500/20 transition-colors">
                      <Shield className="h-6 w-6 text-cyan-500" />
                    </div>
                    Server Setups
                  </CardTitle>
                  <CardDescription>
                    Complete server configurations ready to deploy instantly
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose GfxStore?</h2>
            <p className="text-muted-foreground">Everything you need for the ultimate Minecraft experience</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg">
              <CardContent className="pt-6">
                <div className="w-14 h-14 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-green-500/25">
                  <Shield className="h-7 w-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Safe & Secure</h3>
                <p className="text-muted-foreground">
                  All files are scanned for malware and viruses. Download with complete confidence.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardContent className="pt-6">
                <div className="w-14 h-14 bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-blue-500/25">
                  <Users className="h-7 w-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Community Driven</h3>
                <p className="text-muted-foreground">
                  Join a thriving community of creators and Minecraft enthusiasts worldwide.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardContent className="pt-6">
                <div className="w-14 h-14 bg-gradient-to-br from-purple-400 to-purple-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/25">
                  <Zap className="h-7 w-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Fast Downloads</h3>
                <p className="text-muted-foreground">
                  High-speed CDN ensures quick downloads for all users worldwide.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardContent className="pt-6">
                <div className="w-14 h-14 bg-gradient-to-br from-orange-400 to-orange-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-orange-500/25">
                  <TrendingUp className="h-7 w-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Creator Analytics</h3>
                <p className="text-muted-foreground">
                  Track your downloads, views, and earnings with detailed analytics.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardContent className="pt-6">
                <div className="w-14 h-14 bg-gradient-to-br from-pink-400 to-pink-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-pink-500/25">
                  <MessageSquare className="h-7 w-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Real-time Chat</h3>
                <p className="text-muted-foreground">
                  Connect with creators and users instantly through our live chat system.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardContent className="pt-6">
                <div className="w-14 h-14 bg-gradient-to-br from-cyan-400 to-cyan-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-cyan-500/25">
                  <Globe className="h-7 w-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Global Access</h3>
                <p className="text-muted-foreground">
                  Available 24/7 with servers around the world for the best experience.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* VPS & Server Plans Section */}
      {vpsPlans.length > 0 && (
        <section className="py-16 px-4">
          <div className="container mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4 flex items-center justify-center gap-2">
                <Server className="h-8 w-8 text-primary" />
                VPS & Server Plans
              </h2>
              <p className="text-muted-foreground">Powerful hosting solutions for your Minecraft server</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {vpsPlans.map((plan) => (
                <Card key={plan.id} className="hover:shadow-lg transition-all hover:-translate-y-1 flex flex-col h-full border-2 border-transparent hover:border-primary/30">
                  <CardHeader>
                    <CardTitle>{plan.name}</CardTitle>
                    <CardDescription>{plan.description}</CardDescription>
                    <div className="mt-4">
                      <span className="text-3xl font-bold">${plan.price}</span>
                      <span className="text-muted-foreground">/month</span>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1 flex flex-col">
                    {plan.features && plan.features.length > 0 && (
                      <div className="space-y-3 mb-6">
                        {plan.features.map((feature, idx) => (
                          <div key={idx} className="flex items-start gap-2">
                            <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                            <span className="text-sm">{feature}</span>
                          </div>
                        ))}
                      </div>
                    )}
                    <Link href="/vps" className="mt-auto">
                      <Button className="w-full">
                        View Details
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-primary/10 via-purple-500/10 to-primary/10">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of Minecraft players already using GfxStore to discover and share amazing content
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/signup">
              <Button size="lg" className="text-lg px-8 shadow-lg shadow-primary/25">
                Sign Up Free
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/browse">
              <Button variant="outline" size="lg" className="text-lg px-8">
                <MessageSquare className="mr-2 h-5 w-5" />
                Join Community
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />

      {/* Chat Widget */}
      <ChatWidget isOpen={isChatOpen} onToggle={() => setIsChatOpen(!isChatOpen)} />
    </div>
  )
}
