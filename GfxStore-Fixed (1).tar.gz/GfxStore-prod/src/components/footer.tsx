import Link from 'next/link'
import { Globe, Users, Zap, Shield } from 'lucide-react'

export function Footer() {
  return (
    <footer className="relative bg-gradient-to-b from-slate-900 via-slate-950 to-black text-white overflow-hidden">
      {/* Decorative curved element */}
      <div className="absolute -left-32 top-32 w-96 h-96 rounded-full border-4 border-blue-500/20 pointer-events-none"></div>
      <div className="absolute -right-40 bottom-0 w-96 h-96 rounded-full bg-gradient-to-br from-blue-500/5 to-transparent pointer-events-none"></div>

      <div className="container py-16 md:py-24 relative z-10">
        {/* Feature Boxes */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {/* Global Access Box */}
          <div className="group p-6 rounded-2xl bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-blue-500/20 hover:border-blue-500/50 shadow-lg hover:shadow-2xl transition-all duration-300 backdrop-blur-sm hover:translate-y-[-4px]">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500/30 to-cyan-500/20 group-hover:scale-110 group-hover:from-blue-500/50 group-hover:to-cyan-500/40 transition-all">
                <Globe className="h-6 w-6 text-blue-400" />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-lg mb-1 text-white">Global Access</h4>
                <p className="text-sm text-gray-400 group-hover:text-gray-300 transition-colors">Available 24/7 with servers around the world for the best experience.</p>
              </div>
            </div>
          </div>

          {/* Community Box */}
          <div className="group p-6 rounded-2xl bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-blue-500/20 hover:border-blue-500/50 shadow-lg hover:shadow-2xl transition-all duration-300 backdrop-blur-sm hover:translate-y-[-4px]">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-xl bg-gradient-to-br from-purple-500/30 to-pink-500/20 group-hover:from-purple-500/50 group-hover:to-pink-500/40 transition-all group-hover:scale-110">
                <Users className="h-6 w-6 text-purple-400" />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-lg mb-1 text-white">Community First</h4>
                <p className="text-sm text-gray-400 group-hover:text-gray-300 transition-colors">Join thousands of creators and download quality content daily.</p>
              </div>
            </div>
          </div>

          {/* Fast Performance Box */}
          <div className="group p-6 rounded-2xl bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-blue-500/20 hover:border-blue-500/50 shadow-lg hover:shadow-2xl transition-all duration-300 backdrop-blur-sm hover:translate-y-[-4px]">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-xl bg-gradient-to-br from-orange-500/30 to-yellow-500/20 group-hover:from-orange-500/50 group-hover:to-yellow-500/40 transition-all group-hover:scale-110">
                <Zap className="h-6 w-6 text-orange-400" />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-lg mb-1 text-white">Lightning Fast</h4>
                <p className="text-sm text-gray-400 group-hover:text-gray-300 transition-colors">Optimized for speed with instant downloads and uploads.</p>
              </div>
            </div>
          </div>

          {/* Secure Box */}
          <div className="group p-6 rounded-2xl bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-blue-500/20 hover:border-blue-500/50 shadow-lg hover:shadow-2xl transition-all duration-300 backdrop-blur-sm hover:translate-y-[-4px]">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-xl bg-gradient-to-br from-green-500/30 to-emerald-500/20 group-hover:from-green-500/50 group-hover:to-emerald-500/40 transition-all group-hover:scale-110">
                <Shield className="h-6 w-6 text-green-400" />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-lg mb-1 text-white">Secure & Safe</h4>
                <p className="text-sm text-gray-400 group-hover:text-gray-300 transition-colors">Your data is protected with industry-leading security measures.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-blue-500/30 to-transparent mb-12"></div>

        {/* Footer Links */}
        <div className="grid grid-cols-2 gap-8 lg:grid-cols-4 mb-12">
          {/* Product */}
          <div>
            <h4 className="font-semibold mb-4 text-white text-lg">Product</h4>
            <ul className="space-y-2">
              <li><Link href="/browse" className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200 hover:translate-x-1 inline-block">→ Browse</Link></li>
              <li><Link href="/categories" className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200 hover:translate-x-1 inline-block">→ Categories</Link></li>
              <li><Link href="/creators" className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200 hover:translate-x-1 inline-block">→ Creators</Link></li>
              <li><Link href="/upload" className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200 hover:translate-x-1 inline-block">→ Upload</Link></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-semibold mb-4 text-white text-lg">Support</h4>
            <ul className="space-y-2">
              <li><Link href="/help" className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200 hover:translate-x-1 inline-block">→ Help Center</Link></li>
              <li><Link href="/docs" className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200 hover:translate-x-1 inline-block">→ Documentation</Link></li>
              <li><Link href="/contact" className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200 hover:translate-x-1 inline-block">→ Contact Us</Link></li>
              <li><Link href="/status" className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200 hover:translate-x-1 inline-block">→ Status</Link></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-semibold mb-4 text-white text-lg">Legal</h4>
            <ul className="space-y-2">
              <li><Link href="/privacy" className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200 hover:translate-x-1 inline-block">→ Privacy Policy</Link></li>
              <li><Link href="/terms" className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200 hover:translate-x-1 inline-block">→ Terms of Service</Link></li>
              <li><Link href="/guidelines" className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200 hover:translate-x-1 inline-block">→ Guidelines</Link></li>
              <li><Link href="/dmca" className="text-sm text-gray-400 hover:text-blue-400 transition-colors duration-200 hover:translate-x-1 inline-block">→ DMCA</Link></li>
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h4 className="font-semibold mb-4 text-white text-lg">Connect</h4>
            <div className="flex gap-3">
              <Link href="https://github.com" target="_blank" rel="noopener noreferrer" className="p-2 rounded-lg bg-slate-800/50 hover:bg-blue-600 text-gray-300 hover:text-blue-300 transition-all duration-300 hover:scale-110 border border-slate-700 hover:border-blue-500">
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>
              </Link>
              <Link href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="p-2 rounded-lg bg-slate-800/50 hover:bg-blue-600 text-gray-300 hover:text-blue-300 transition-all duration-300 hover:scale-110 border border-slate-700 hover:border-blue-500">
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24"><path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2s9 5 20 5a9.5 9.5 0 00-9-5.5c4.75 2.25 7-7 7-7s1.1 5.2-5.2 8.3A15.326 15.326 0 0123 3z"/></svg>
              </Link>
              <Link href="https://discord.com" target="_blank" rel="noopener noreferrer" className="p-2 rounded-lg bg-slate-800/50 hover:bg-blue-600 text-gray-300 hover:text-blue-300 transition-all duration-300 hover:scale-110 border border-slate-700 hover:border-blue-500">
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24"><path d="M20.317 4.37a19.791 19.791 0 00-4.885-1.515.074.074 0 00-.079.037c-.211.375-.444.864-.607 1.25a18.27 18.27 0 00-5.487 0c-.163-.386-.395-.875-.608-1.25a.077.077 0 00-.079-.037A19.736 19.736 0 003.677 4.37a.07.07 0 00-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 00.031.057 19.9 19.9 0 005.993 3.03.078.078 0 00.084-.028c.462-.63.873-1.295 1.226-1.994a.076.076 0 00-.042-.106 13.107 13.107 0 01-1.872-.892.077.077 0 01-.009-.128 10.2 10.2 0 00.372-.294.074.074 0 01.076-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 01.077.009c.12.098.246.198.373.294a.077.077 0 01-.006.127 12.299 12.299 0 01-1.873.892.076.076 0 00-.041.107c.359.698.77 1.364 1.225 1.994a.077.077 0 00.084.028 19.963 19.963 0 006.002-3.03.077.077 0 00.032-.057c.5-4.565-.838-8.535-3.549-12.047a.061.061 0 00-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.974-2.419 2.157-2.419 1.183 0 2.157 1.086 2.157 2.419 0 1.334-.974 2.419-2.157 2.419zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.974-2.419 2.157-2.419 1.183 0 2.157 1.086 2.157 2.419 0 1.334-.974 2.419-2.157 2.419z"/></svg>
              </Link>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-slate-700/50 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-gray-400">© {new Date().getFullYear()} GfxStore. All rights reserved.</p>
          <p className="text-sm text-gray-400">Made with <span className="text-red-500 animate-pulse">❤</span> for the Minecraft community</p>
        </div>
      </div>
    </footer>
  )
}