'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Loader2, Check, X } from 'lucide-react'
import { Textarea } from '@/components/ui/textarea'

interface Order {
  id: string
  userId: string
  user?: { username: string; email: string }
  plan: { name: string }
  amount: number
  paymentMethod: string
  transactionRef?: string
  status: string
  serverInfo?: any
  createdAt: string
}

export default function VPSOrdersAdminPage() {
  const { data: session, status: authStatus } = useSession()
  const router = useRouter()
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<Order | null>(null)
  const [approving, setApproving] = useState(false)
  const [serverInfo, setServerInfo] = useState('')

  useEffect(() => {
    if (authStatus === 'loading') return
    if (authStatus === 'unauthenticated' || session?.user?.role !== 'ADMIN') {
      router.push('/')
      return
    }
    fetchOrders()
  }, [authStatus, session, router])

  const fetchOrders = async () => {
    try {
      const res = await fetch('/api/admin/vps-orders')
      if (res.ok) {
        const data = await res.json()
        setOrders(data)
      }
    } catch (error) {
      console.error('Failed to fetch orders:', error)
    } finally {
      setLoading(false)
    }
  }

  const openApprove = (order: Order) => {
    setSelected(order)
    setServerInfo(order.serverInfo ? JSON.stringify(order.serverInfo, null, 2) : '')
  }

  const handleApprove = async () => {
    if (!selected) return
    setApproving(true)
    try {
      const res = await fetch(`/api/admin/vps-orders/${selected.id}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ serverInfo: serverInfo ? JSON.parse(serverInfo) : {} })
      })
      if (!res.ok) throw new Error('Failed to approve')
      setSelected(null)
      fetchOrders()
    } catch (err) {
      alert(String(err))
    } finally {
      setApproving(false)
    }
  }

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">VPS Orders</h2>
      {loading ? (
        <Loader2 className="animate-spin" />
      ) : (
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>User</TableCell>
              <TableCell>Plan</TableCell>
              <TableCell>Amount</TableCell>
              <TableCell>Method</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {orders.map((o) => (
              <TableRow key={o.id}>
                <TableCell>{o.user?.username || o.userId}</TableCell>
                <TableCell>{o.plan.name}</TableCell>
                <TableCell>${o.amount}</TableCell>
                <TableCell>{o.paymentMethod}</TableCell>
                <TableCell><Badge>{o.status}</Badge></TableCell>
                <TableCell>
                  {o.status !== 'APPROVED' && (
                    <Button size="sm" onClick={() => openApprove(o)}>
                      Process
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Process Order</DialogTitle>
            <DialogDescription>Fill server information and approve order.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {selected && (
              <div className="text-sm">
                <p><strong>User:</strong> {selected.user?.username}</p>
                <p><strong>Plan:</strong> {selected.plan.name}</p>
                <p><strong>Amount:</strong> ${selected.amount}</p>
                <p><strong>Method:</strong> {selected.paymentMethod}</p>
                {selected.transactionRef && (
                  <p><strong>Ref:</strong> {selected.transactionRef}</p>
                )}
              </div>
            )}
            <Textarea
              className="font-mono text-xs"
              rows={6}
              value={serverInfo}
              onChange={(e) => setServerInfo(e.target.value)}
              placeholder="e.g. IP, username, password, etc."
            />
            <div className="flex gap-4 justify-end">
              <Button variant="outline" onClick={() => setSelected(null)} disabled={approving}>Cancel</Button>
              <Button onClick={handleApprove} disabled={approving}>{approving ? 'Approving...' : 'Approve'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
