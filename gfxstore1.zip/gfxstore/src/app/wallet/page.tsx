'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Wallet, Zap, DollarSign } from 'lucide-react'

interface UserData {
  walletBalance?: number
  username?: string
  email?: string
}

interface Transaction {
  id: string
  amount: number
  method: string
  type: string
  status: string
  createdAt: string
}

interface Membership {
  id: string
  name: string
  price: number
  description?: string
  owned?: boolean
}

export default function WalletPage() {
  const { status } = useSession()
  const router = useRouter()
  const [data, setData] = useState<{
    user: UserData | null
    txs: Transaction[]
    mems: Membership[]
  }>({ user: null, txs: [], mems: [] })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
      return
    }
    if (status === 'authenticated') {
      load()
    }
  }, [status])

  const load = async () => {
    try {
      const [user, txs, mems] = await Promise.all([
        fetch('/api/users/me').then(r => r.ok ? r.json() : null).catch(() => null),
        fetch('/api/transactions').then(r => r.ok ? r.json() : []).catch(() => []),
        fetch('/api/user/memberships').then(r => r.ok ? r.json() : []).catch(() => [])
      ])
      setData({
        user: user || {},
        txs: Array.isArray(txs) ? txs : [],
        mems: Array.isArray(mems) ? mems : []
      })
    } catch (e) {
      console.error('Load error:', e)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <div className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">My Wallet</h1>
        <Tabs defaultValue="balance">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="balance">Balance</TabsTrigger>
            <TabsTrigger value="memberships">Memberships ({data.mems.length})</TabsTrigger>
            <TabsTrigger value="history">History ({data.txs.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="balance" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Wallet className="h-5 w-5" />Your Balance</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <p className="text-4xl font-bold text-primary">${(((data.user?.walletBalance) || 0) * 120).toFixed(2)}</p>
                  <p className="text-sm text-muted-foreground mt-2">BDT (USD: ${((data.user?.walletBalance) || 0).toFixed(2)})</p>
                </div>
                <Button onClick={() => router.push('/payment')} size="lg" className="w-full"><DollarSign className="mr-2 h-4 w-4" />Deposit Funds</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="memberships" className="space-y-6">
            {data.mems.length === 0 ? (
              <Alert><AlertDescription>No memberships available</AlertDescription></Alert>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {data.mems.map((m: Membership) => (
                  <Card key={m.id}>
                    <CardHeader><CardTitle>{m.name}</CardTitle></CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-2xl font-bold text-primary">${m.price.toFixed(2)}</p>
                      {m.description && <p className="text-sm text-muted-foreground">{m.description}</p>}
                      {m.owned ? (
                        <Badge className="w-full justify-center">✅ Active Membership</Badge>
                      ) : (
                        <Button className="w-full">Subscribe Now</Button>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            {data.txs.length === 0 ? (
              <Alert><AlertDescription>No transaction history yet</AlertDescription></Alert>
            ) : (
              <div className="space-y-2">
                {data.txs.map((t: Transaction) => (
                  <Card key={t.id}>
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-semibold capitalize">{t.method}</p>
                          <p className="text-xs text-muted-foreground">{new Date(t.createdAt).toLocaleString()}</p>
                        </div>
                        <div className="text-right">
                          <p className={`font-bold text-lg ${t.type === 'DEPOSIT' ? 'text-green-600' : 'text-red-600'}`}>
                            {t.type === 'DEPOSIT' ? '+' : '-'}${t.amount.toFixed(2)}
                          </p>
                          <Badge variant="secondary">{t.status}</Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
      <Footer />
    </div>
  )
}
