import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { withRetry } from '@/lib/db-retry'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    let user = await withRetry(
      () => db.user.findUnique({ where: { id: session.user.id } }),
      'Fetch user by ID'
    )

    if (!user) {
      console.log('User not found by ID, checking by email:', session.user.email)
      if (session.user.email) {
        user = await withRetry(
          () => db.user.findUnique({ where: { email: session.user.email } }),
          'Find user by email'
        )
      }
      
      if (!user) {
        console.log('Creating new user from session:', session.user.id)
        try {
          const timestamp = Date.now()
          const baseUsername = session.user.username || session.user.name || 'user'
          const uniqueUsername = `${baseUsername}-${timestamp}`.substring(0, 50)
          
          user = await withRetry(
            () => db.user.create({
              data: {
                id: session.user.id,
                email: session.user.email || `user-${session.user.id}@gfxstore.local`,
                username: uniqueUsername,
                password: 'session-user',
                role: session.user.role || 'USER'
              }
            }),
            'Create new user'
          )
          console.log('User created successfully:', user.id)
        } catch (createError: any) {
          console.error('Error creating user:', createError.message)
          throw createError
        }
      }
    }

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    return NextResponse.json(user)
  } catch (error) {
    console.error('Error fetching user:', error)
    return NextResponse.json({ error: 'Failed to fetch user' }, { status: 500 })
  }
}
