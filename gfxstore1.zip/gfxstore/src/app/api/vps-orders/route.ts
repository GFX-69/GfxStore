import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

// Public & authenticated endpoints for VPS orders
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const orders = await db.vPSOrder.findMany({
      where: { userId: session.user.id },
      include: { plan: true },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ orders })
  } catch (error) {
    console.error('Error fetching user VPS orders', error)
    return NextResponse.json({ error: 'Failed to fetch orders' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { planId, paymentMethod, amount } = body

    if (!planId || !paymentMethod || typeof amount !== 'number') {
      return NextResponse.json({ error: 'Invalid payload' }, { status: 400 })
    }

    const order = await db.vPSOrder.create({
      data: {
        userId: session.user.id,
        planId,
        paymentMethod,
        amount,
        status: 'PENDING'
      }
    })

    if ((global as any).broadcastToAdmins) {
      await (global as any).broadcastToAdmins({
        type: 'VPS_ORDER_SUBMITTED',
        payload: { orderId: order.id }
      })
    }

    return NextResponse.json({ success: true, order })
  } catch (error) {
    console.error('Error creating VPS order', error)
    return NextResponse.json({ error: 'Failed to create order' }, { status: 500 })
  }
}
