import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id || (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { id } = await params
    const body = await request.json()
    const { serverInfo } = body

    const order = await db.vPSOrder.findUnique({ where: { id }, include: { plan: true } })
    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }
    if (order.status === 'APPROVED') {
      return NextResponse.json({ error: 'Order already approved' }, { status: 400 })
    }

    const updated = await db.vPSOrder.update({
      where: { id },
      data: {
        status: 'APPROVED',
        serverInfo: serverInfo || {}
      }
    })

    // send notification to user
    if ((global as any).sendNotification) {
      try {
        await (global as any).sendNotification(order.userId, {
          title: '✅ VPS Order Approved',
          content: `Your order for ${order.plan.name} has been approved.\n` +
            `Server details: ${JSON.stringify(serverInfo ?? {})}`,
          type: 'VPS_ORDER_APPROVED'
        })
      } catch (notifErr) {
        console.error('Failed to send invitation notification', notifErr)
      }
    }

    // optionally create a support chat message with details
    try {
      await db.chatMessage.create({
        data: {
          userId: order.userId,
          content: `Your VPS order has been approved. Server information: ${JSON.stringify(serverInfo ?? {})}`,
          type: 'SUPPORT'
        }
      })
    } catch (chatErr) {
      console.error('Failed to log support chat message', chatErr)
    }

    return NextResponse.json({ success: true, order: updated })
  } catch (error) {
    console.error('Error approving VPS order:', error)
    return NextResponse.json({ error: 'Failed to approve order' }, { status: 500 })
  }
}
