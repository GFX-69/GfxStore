import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { amount, method, transactionId, senderName, proof } = body

    if (!amount || !method || !transactionId || amount <= 0) {
      return NextResponse.json({ error: 'Invalid transaction data' }, { status: 400 })
    }

    try {
      // First, ensure user exists in database
      let user = await db.user.findUnique({
        where: { id: session.user.id }
      })

      if (!user) {
        console.log('User not found by ID, checking by email:', session.user.email)
        // Try to find existing user by email
        if (session.user.email) {
          user = await db.user.findUnique({
            where: { email: session.user.email }
          })
        }
        
        // If still not found, create new user
        if (!user) {
          console.log('Creating new user for transaction:', session.user.id)
          try {
            // Generate unique username with timestamp to avoid conflicts
            const timestamp = Date.now()
            const baseUsername = session.user.name || 'user'
            const uniqueUsername = `${baseUsername}-${timestamp}`.substring(0, 50)
            
            user = await db.user.create({
              data: {
                id: session.user.id,
                email: session.user.email || `user-${session.user.id}@gfxstore.local`,
                username: uniqueUsername,
                password: 'oauth-user',
                role: 'USER'
              }
            })
          } catch (createError: any) {
            console.error('Error creating user for transaction:', createError.message)
            throw createError
          }
        }
      }

      if (!user) {
        return NextResponse.json({ error: 'Failed to ensure user exists' }, { status: 500 })
      }

      // Create transaction with PENDING status
      const transaction = await db.transaction.create({
        data: {
          userId: user.id,
          amount: parseFloat(String(amount)),
          method: String(method),
          type: 'DEPOSIT',
          reference: String(transactionId),
          status: 'PENDING',
        }
      })

      console.log('Transaction submitted:', {
        transactionId: transaction.id,
        userId: user.id,
        amount,
        method,
        senderName,
        proof
      })

      return NextResponse.json({
        success: true,
        transactionId: transaction.id,
        message: 'Transaction submitted for admin review'
      })
    } catch (dbError: any) {
      console.error('Database error submitting transaction:', dbError)
      throw dbError
    }
  } catch (error) {
    console.error('Error submitting transaction:', error)
    const errorMsg = error instanceof Error ? error.message : 'Failed to submit transaction'
    return NextResponse.json({ error: errorMsg }, { status: 500 })
  }
}
