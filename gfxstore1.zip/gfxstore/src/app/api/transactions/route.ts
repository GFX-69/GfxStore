import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { withRetry } from '@/lib/db-retry'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json([], { status: 200 })
    }

    const transactions = await withRetry(
      () => db.transaction.findMany({
        where: { userId: session.user.id },
        orderBy: { createdAt: 'desc' },
        take: 100
      }),
      'Fetch transactions'
    )

    return NextResponse.json(transactions || [], { status: 200 })
  } catch (error) {
    console.error('Transactions fetch error:', error)
    return NextResponse.json([], { status: 200 })
  }
}
