import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { withRetry } from '@/lib/db-retry'

export async function GET(request: NextRequest) {
  try {
    const memberships = await withRetry(
      () => db.membership.findMany({
        where: { isActive: true },
        orderBy: { sortOrder: 'asc' }
      }),
      'Fetch memberships'
    )
    return NextResponse.json(memberships || [])
  } catch (error) {
    console.error('Memberships fetch error:', error)
    return NextResponse.json([])
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id || !['ADMIN', 'SUPER_ADMIN'].includes(session.user?.role)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { name, roleName, description, price, features, color, sortOrder } = body

    const membership = await withRetry(
      () => db.membership.create({
        data: {
          name,
          roleName,
          description,
          price: parseFloat(price),
          features: features || [],
          color: color || '#6366f1',
          sortOrder: parseInt(sortOrder) || 0,
          isActive: true
        }
      }),
      'Create membership'
    )

    return NextResponse.json(membership, { status: 201 })
  } catch (error) {
    console.error('Create membership error:', error)
    return NextResponse.json({ error: 'Failed to create membership' }, { status: 500 })
  }
}
