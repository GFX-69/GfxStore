'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Check, Loader2 } from 'lucide-react'
import Link from 'next/link'

interface Plan {
  id: string
  name: string
  description: string
  price: number
  features?: string[]
  specs?: Record<string, any>
  isActive: boolean
  sortOrder: number
}

export default function VPSPage() {
  const { data: session } = useSession()
  const [plans, setPlans] = useState<Plan[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchPlans()
  }, [])

  const fetchPlans = async () => {
    try {
      const response = await fetch('/api/admin/plans?public=true')
      if (response.ok) {
        const data = await response.json()
        setPlans(Array.isArray(data.plans) ? data.plans : [])
      }
    } catch (error) {
      console.error('Failed to fetch plans:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="flex-1 container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">VPS & Server Plans</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Reliable and secure Minecraft server hosting solutions for any scale
          </p>
          {session?.user && (
            <Link href="/vps/orders" className="text-sm text-primary underline mt-2 inline-block">
              My Orders
            </Link>
          )}
        </div>

        {plans.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No plans available at this time.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {plans.map((plan, idx) => {
              const planImage = plan.specs?.planImage
              const planGif = plan.specs?.planGif
              const hasImage = planImage || planGif
              const imageUrl = planGif || planImage
              
              return (
                <div
                  key={plan.id}
                  className={`relative flex flex-col rounded-lg overflow-hidden border h-full transition-transform ${idx === 1 ? 'md:scale-105 border-primary shadow-lg' : 'border-input'} bg-card`}
                >
                  {hasImage && imageUrl && (
                    <div className="relative w-full h-48 bg-muted overflow-hidden">
                      <img 
                        src={imageUrl} 
                        alt={plan.name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = 'none'
                        }}
                      />
                    </div>
                  )}
                  
                  {idx === 1 && (
                    <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 z-10">
                      Most Popular
                    </Badge>
                  )}
                  
                  <div className="relative z-10 flex flex-col h-full p-6">
                    <div>
                      <h3 className="text-2xl font-bold mb-2">
                        {plan.name}
                      </h3>
                      <p className="text-sm mb-4 text-muted-foreground">
                        {plan.description}
                      </p>
                    </div>

                    <div className="flex-1 flex flex-col justify-between gap-6">
                      <div>
                        <span className="text-4xl font-bold">
                          ${plan.price}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          /month
                        </span>
                      </div>

                      <Link href={`/vps/checkout/${plan.id}`} className="w-full"><Button className="w-full bg-primary hover:bg-primary/90">Get Started</Button></Link>

                      <div className="space-y-3">
                        {plan.features && plan.features.length > 0 ? (
                          plan.features.map((feature, fidx) => (
                            <div key={fidx} className="flex items-start gap-3">
                              <Check className="h-5 w-5 flex-shrink-0 mt-0.5 text-green-600" />
                              <span className="text-sm">
                                {feature}
                              </span>
                            </div>
                          ))
                        ) : (
                          <p className="text-sm text-muted-foreground">
                            No features listed
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}

        <div className="mt-16 bg-muted rounded-lg p-8 max-w-2xl mx-auto">
          <h3 className="text-xl font-bold mb-4">FAQ</h3>
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Can I upgrade my plan?</h4>
              <p className="text-muted-foreground">Yes! You can upgrade anytime and we'll prorate your billing.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">What locations are available?</h4>
              <p className="text-muted-foreground">We offer servers in US, EU, and Asia regions for optimal performance.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Is there a money-back guarantee?</h4>
              <p className="text-muted-foreground">Yes, 30-day money-back guarantee on all plans!</p>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
