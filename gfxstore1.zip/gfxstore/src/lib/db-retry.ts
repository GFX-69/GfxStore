import { db, reconnectDatabase } from './db'

export async function withRetry<T>(
  operation: () => Promise<T>,
  operationName: string = 'database operation',
  maxRetries: number = 3
): Promise<T> {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await operation()
    } catch (error: any) {
      const isConnectionError = 
        error?.message?.includes('Engine is not yet connected') ||
        error?.message?.includes('Response from the Engine was empty') ||
        error?.message?.includes('Can\'t reach database') ||
        error?.code === 'ECONNREFUSED'

      if (isConnectionError && attempt < maxRetries) {
        console.warn(`⚠️ ${operationName}: Connection lost (attempt ${attempt}/${maxRetries}), reconnecting...`)
        await reconnectDatabase()
        await new Promise(resolve => setTimeout(resolve, 500 * attempt))
        continue
      }
      throw error
    }
  }
}
