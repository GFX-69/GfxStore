import { PrismaClient } from '@prisma/client'

const globalForPrisma = global as unknown as {
  prisma: PrismaClient | undefined
}

let connectionReady = false
let reconnectAttempts = 0
const MAX_RECONNECT_ATTEMPTS = 3

function createPrismaClient() {
  return new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['error', 'warn'] : ['error'],
    errorFormat: 'colorless'
  })
}

// Create single global instance
if (!globalForPrisma.prisma) {
  globalForPrisma.prisma = createPrismaClient()
}

export const db = globalForPrisma.prisma

// Initialize database connection
export async function ensureDatabaseReady() {
  if (connectionReady) return
  
  try {
    // Test connection with a simple query
    await db.$queryRaw`SELECT 1`
    connectionReady = true
    reconnectAttempts = 0
    console.log('✅ Database connection established and verified')
  } catch (error) {
    console.error('❌ Database connection check failed:', error)
    connectionReady = false
  }
}

// Reconnect when connection is lost
export async function reconnectDatabase() {
  try {
    if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
      console.error('❌ Max reconnect attempts reached')
      connectionReady = false
      return
    }

    reconnectAttempts++
    console.log(`🔄 Attempting to reconnect to database (attempt ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})...`)
    
    // Disconnect first
    await db.$disconnect()
    
    // Wait a moment before reconnecting
    await new Promise(resolve => setTimeout(resolve, 1000 * reconnectAttempts))
    
    // Test connection
    await db.$queryRaw`SELECT 1`
    connectionReady = true
    reconnectAttempts = 0
    console.log('✅ Database reconnected successfully')
  } catch (error) {
    console.error('❌ Database reconnection failed:', error)
    connectionReady = false
  }
}