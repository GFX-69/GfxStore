#!/bin/bash

echo "╔════════════════════════════════════════════╗"
echo "║   GfxStore Admin API Testing Script       ║"
echo "║   Admin: kakmare.pa@gmail.com             ║"
echo "╚════════════════════════════════════════════╝"
echo ""

# Color codes
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}Note: Admin APIs require browser session authentication.${NC}"
echo "To test them:"
echo "1. Log in at: http://localhost:5000/auth/signin"
echo "2. Use: kakmare.pa@gmail.com / akash9x1"
echo "3. Then access admin panel: http://localhost:5000/admin"
echo ""

echo -e "${GREEN}✅ PUBLIC ENDPOINTS (No Auth Needed)${NC}"
echo "1. Categories: curl http://localhost:5000/api/categories"
echo "2. Items: curl http://localhost:5000/api/items"
echo "3. Stats: curl http://localhost:5000/api/public-stats"
echo "4. Settings: curl http://localhost:5000/api/admin/settings"
echo "5. Memberships: curl http://localhost:5000/api/memberships"
echo ""

echo -e "${RED}❌ ADMIN ENDPOINTS (Requires Auth/Session)${NC}"
echo "1. Admin Stats: curl http://localhost:5000/api/admin/stats"
echo "2. All Users: curl http://localhost:5000/api/admin/users"
echo "3. All Categories: curl http://localhost:5000/api/admin/categories"
echo "4. All Items: curl http://localhost:5000/api/admin/items-all"
echo "5. Transactions: curl http://localhost:5000/api/admin/transactions"
echo "6. Plans: curl http://localhost:5000/api/admin/plans"
echo "7. Check Access: curl http://localhost:5000/api/admin/check-access"
echo ""

echo -e "${YELLOW}🧪 TESTING PUBLIC APIs...${NC}"
echo ""
echo "Categories:"
curl -s http://localhost:5000/api/categories | head -100
echo ""

echo "Public Stats:"
curl -s http://localhost:5000/api/public-stats
echo ""

echo -e "${YELLOW}Test Complete!${NC}"
