import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3'
import { getSignedUrl } from '@aws-sdk/s3-request-presigner'

const s3Client = new S3Client({
  endpoint: process.env.S3_API_ENDPOINT,
  region: process.env.S3_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY!,
    secretAccessKey: process.env.S3_SECRET_KEY!,
  },
  forcePathStyle: true,
})

export class FileStorageService {
  private bucket = process.env.S3_BUCKET!

  async uploadFile(
    key: string,
    body: Buffer | Uint8Array | Blob | string,
    contentType: string,
    metadata?: Record<string, string>
  ): Promise<string> {
    const command = new PutObjectCommand({
      Bucket: this.bucket,
      Key: key,
      Body: body,
      ContentType: contentType,
      Metadata: metadata,
    })

    await s3Client.send(command)
    return this.getFileUrl(key)
  }

  async getFileUrl(key: string): Promise<string> {
    const command = new GetObjectCommand({
      Bucket: this.bucket,
      Key: key,
    })

    return await getSignedUrl(s3Client, command, { expiresIn: 3600 * 24 }) // 24 hours
  }

  async getPresignedUploadUrl(key: string, contentType: string): Promise<string> {
    const command = new PutObjectCommand({
      Bucket: this.bucket,
      Key: key,
      ContentType: contentType,
    })

    return await getSignedUrl(s3Client, command, { expiresIn: 3600 }) // 1 hour
  }

  async deleteFile(key: string): Promise<void> {
    const command = new DeleteObjectCommand({
      Bucket: this.bucket,
      Key: key,
    })

    await s3Client.send(command)
  }

  generateFileKey(type: string, filename: string, userId: string): string {
    const timestamp = Date.now()
    const extension = filename.split('.').pop()
    return `${type}/${userId}/${timestamp}.${extension}`
  }

  generateItemFileKey(itemId: string, version: string, filename: string): string {
    const timestamp = Date.now()
    const extension = filename.split('.').pop()
    return `items/${itemId}/v${version}/${timestamp}.${extension}`
  }

  generateScreenshotKey(itemId: string, filename: string): string {
    const timestamp = Date.now()
    const extension = filename.split('.').pop()
    return `screenshots/${itemId}/${timestamp}.${extension}`
  }

  generateAvatarKey(userId: string, filename: string): string {
    const timestamp = Date.now()
    const extension = filename.split('.').pop()
    return `avatars/${userId}/${timestamp}.${extension}`
  }
}

export const fileStorage = new FileStorageService()