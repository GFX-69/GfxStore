'use client'

import { useState, useEffect, createContext, useContext, ReactNode } from 'react'
import { useSession } from 'next-auth/react'
import { io, Socket } from 'socket.io-client'

interface Notification {
  id: string
  title: string
  content: string
  type: 'ITEM_APPROVED' | 'ITEM_REJECTED' | 'NEW_REVIEW' | 'DOWNLOAD_COMPLETE' | 'SYSTEM_ANNOUNCEMENT' | 'USER_MENTIONED' | 'DEPOSIT_APPROVED' | 'TRANSACTION_APPROVED' | 'ITEM_LIKED' | 'NEW_MESSAGE' | 'ADMIN_ANNOUNCEMENT'
  isRead: boolean
  createdAt: Date
  itemId?: string
}

interface NotificationContextType {
  notifications: Notification[]
  unreadCount: number
  markAsRead: (id: string) => void
  clearAll: () => void
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined)

export function NotificationProvider({ children }: { children: ReactNode }) {
  const { data: session } = useSession()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [socket, setSocket] = useState<Socket | null>(null)

  const unreadCount = notifications.filter(n => !n.isRead).length

  useEffect(() => {
    if (!session) return

    // Initialize socket connection for real-time notifications
    const notificationSocket = io('/notifications', {
      transports: ['websocket', 'polling']
    })
    
    notificationSocket.on('connect', () => {
      console.log('Connected to notification service')
      
      // Join user's notification room
      notificationSocket.emit('join', {
        userId: session.user.id,
        role: session.user.role
      })
    })

    notificationSocket.on('notification', (notification: Notification) => {
      setNotifications(prev => [notification, ...prev])
      
      // Show browser notification if permission granted
      if (Notification.permission === 'granted') {
        new Notification(notification.title, {
          body: notification.content,
          icon: '/favicon.ico'
        })
      }
    })

    notificationSocket.on('notifications', (userNotifications: Notification[]) => {
      setNotifications(userNotifications)
    })

    setSocket(notificationSocket)

    // Request notification permission
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission()
    }

    return () => {
      notificationSocket.disconnect()
    }
  }, [session])

  const markAsRead = async (id: string) => {
    try {
      const response = await fetch('/api/notifications/read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      })

      if (response.ok) {
        setNotifications(prev => 
          prev.map(n => n.id === id ? { ...n, isRead: true } : n)
        )
      }
    } catch (error) {
      console.error('Failed to mark notification as read:', error)
    }
  }

  const clearAll = async () => {
    try {
      const response = await fetch('/api/notifications/clear', {
        method: 'POST'
      })

      if (response.ok) {
        setNotifications([])
      }
    } catch (error) {
      console.error('Failed to clear notifications:', error)
    }
  }

  return (
    <NotificationContext.Provider value={{
      notifications,
      unreadCount,
      markAsRead,
      clearAll
    }}>
      {children}
    </NotificationContext.Provider>
  )
}

export function useNotifications() {
  const context = useContext(NotificationContext)
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider')
  }
  return context
}