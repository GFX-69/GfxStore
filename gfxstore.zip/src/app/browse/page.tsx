'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Search, Download, Star, Eye, Image as ImageIcon } from 'lucide-react'

interface ItemWithFiles {
  id: string
  title: string
  slug: string
  description: string
  shortDesc: string
  downloads: number
  likes: number
  views: number
  price: number
  featured: boolean
  status: string
  logo?: string
  author: { username: string }
  category: { name: string }
  screenshots: Array<{ id: string; url: string; alt: string }>
  latestVersion?: { fileName: string; downloadUrl: string; fileSize: number }
  hasFiles: boolean
  downloadUrl: string
  _count: { reviews: number }
}

export default function Browse() {
  const router = useRouter()
  const [items, setItems] = useState<ItemWithFiles[]>([])
  const [categories, setCategories] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [sortBy, setSortBy] = useState('createdAt')
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    fetchItems()
    fetchCategories()
  }, [searchTerm, selectedCategory, sortBy])

  const fetchItems = async () => {
    try {
      const params = new URLSearchParams({
        ...(searchTerm && { search: searchTerm }),
        ...(selectedCategory && selectedCategory !== 'all' && { category: selectedCategory }),
        sort: sortBy,
      })

      const response = await fetch(`/api/items?${params}`)
      if (!response.ok) {
        setError('Unable to load items. The service is temporarily unavailable.')
        setItems([])
        return
      }
      const data = await response.json()
      const itemsArray = Array.isArray(data) ? data : (data?.items || [])
      setItems(itemsArray || [])
      setError('')
    } catch (error) {
      console.error('Error fetching items:', error)
      setError('Unable to load items. Please try again later.')
      setItems([])
    } finally {
      setIsLoading(false)
    }
  }

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/categories')
      if (!response.ok) {
        setCategories([])
        return
      }
      const data = await response.json()
      setCategories(Array.isArray(data) ? data : [])
    } catch (error) {
      console.error('Error fetching categories:', error)
      setCategories([])
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          <h1 className="text-3xl font-bold">Browse Items</h1>
          
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search for items..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="createdAt">Latest</SelectItem>
                <SelectItem value="downloads">Most Downloaded</SelectItem>
                <SelectItem value="likes">Most Liked</SelectItem>
                <SelectItem value="views">Most Viewed</SelectItem>
                <SelectItem value="name">Name</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Error Alert */}
        {error && (
          <Card className="mb-8 border-destructive bg-destructive/5">
            <CardContent className="pt-6">
              <p className="text-destructive text-sm">{error}</p>
            </CardContent>
          </Card>
        )}

        {/* Results */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="aspect-video bg-muted rounded-t-lg"></div>
                <CardHeader>
                  <div className="h-4 bg-muted rounded w-3/4"></div>
                  <div className="h-3 bg-muted rounded w-1/2"></div>
                </CardHeader>
              </Card>
            ))}
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-12">
            <div className="space-y-4">
              <ImageIcon className="mx-auto h-16 w-16 text-muted-foreground" />
              <h3 className="text-lg font-semibold">No items found</h3>
              <p className="text-muted-foreground">
                {searchTerm || selectedCategory !== 'all' 
                  ? 'Try adjusting your search or filters' 
                  : 'Be the first to upload content!'
                }
              </p>
              <a href="/upload">
                <Button>Upload First Item</Button>
              </a>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {items.map((item) => (
              <div key={item.id} onClick={() => router.push(`/items/${item.slug}`)} className="hover:shadow-lg transition-shadow cursor-pointer">
                <Card className="group overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <div className="flex-shrink-0">
                        <div className="w-24 h-24 md:w-32 md:h-32 bg-muted rounded-lg relative overflow-hidden flex items-center justify-center group-hover:scale-105 transition-transform">
                          {item.logo ? (
                            <img src={item.logo} alt={item.title} className="w-full h-full object-cover" onError={(e) => {const t = e.target as HTMLImageElement; t.src = '/placeholder-item.png'}} />
                          ) : item.screenshots && item.screenshots.length > 0 ? (
                            <img src={item.screenshots[0]?.url} alt={item.title} className="w-full h-full object-cover" onError={(e) => {const t = e.target as HTMLImageElement; t.src = '/placeholder-item.png'}} />
                          ) : (
                            <ImageIcon className="h-8 w-8 text-muted-foreground" />
                          )}
                          {item.featured && <Badge className="absolute top-1 right-1" variant="secondary">Featured</Badge>}
                        </div>
                      </div>
                      <div className="flex-1 flex flex-col justify-between">
                        <div>
                          <CardTitle className="text-lg hover:text-primary">{item.title}</CardTitle>
                          <CardDescription className="text-sm">{item.shortDesc || item.description}</CardDescription>
                          <div className="flex gap-4 text-sm text-muted-foreground mt-2">
                            <span className="flex items-center gap-1"><Download className="h-3 w-3" />{item.downloads}</span>
                            <span className="flex items-center gap-1"><Star className="h-3 w-3" />{item.likes}</span>
                            <span className="flex items-center gap-1"><Eye className="h-3 w-3" />{item.views}</span>
                          </div>
                        </div>
                        <div className="flex justify-between items-center mt-3 pt-3 border-t">
                          <div className="flex gap-2">
                            <Badge variant="outline" className="text-xs">{item.category.name}</Badge>
                            <Badge variant="outline" className="text-xs">by {item.author.username}</Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold">{item.price > 0 ? `$${item.price}` : 'Free'}</span>
                            {item.hasFiles && item.downloadUrl && (
                              <Button size="sm" asChild>
                                <a href={item.downloadUrl} target="_blank" rel="noopener noreferrer">
                                  <Download className="h-3 w-3" />
                                </a>
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  )
}
