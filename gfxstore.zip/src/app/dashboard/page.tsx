'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Package, 
  Download, 
  TrendingUp, 
  Users, 
  Eye, 
  Star, 
  MessageSquare,
  BarChart3,
  Upload,
  Clock,
  DollarSign,
  FileText,
  Settings,
  Plus,
  Edit,
  Trash2,
  ExternalLink
} from 'lucide-react'
import Link from 'next/link'

interface DashboardStats {
  totalUsers: number
  totalItems: number
  totalDownloads: number
  totalRevenue: number
  activeUsers: number
  pendingItems: number
  recentActivity: Array<{
    id: string
    type: 'upload' | 'download' | 'review' | 'user'
    title: string
    timestamp: string
    user?: string
  }>
}

interface UserItem {
  id: string
  title: string
  slug: string
  downloads: number
  likes: number
  views: number
  status: string
  createdAt: string
  category: {
    name: string
  }
}

interface UserMembership {
  id: string
  name: string
  roleName: string
  price: number
  color: string
}

export default function Dashboard() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    totalItems: 0,
    totalDownloads: 0,
    totalRevenue: 0,
    activeUsers: 0,
    pendingItems: 0,
    recentActivity: []
  })
  const [userItems, setUserItems] = useState<UserItem[]>([])
  const [userMemberships, setUserMemberships] = useState<UserMembership[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === 'loading') return
    
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
      return
    }

    fetchDashboardData()
    fetchUserItems()
    fetchUserMemberships()
    const interval = setInterval(fetchUserMemberships, 2000)
    return () => clearInterval(interval)
  }, [status, router])

  const fetchDashboardData = async () => {
    try {
      const response = await fetch('/api/dashboard/stats')
      if (response.ok) {
        const data = await response.json()
        setStats(data)
      }
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchUserItems = async () => {
    try {
      const response = await fetch('/api/dashboard/my-items')
      if (response.ok) {
        const data = await response.json()
        setUserItems(Array.isArray(data) ? data : [])
      }
    } catch (error) {
      console.error('Failed to fetch user items:', error)
    }
  }

  const fetchUserMemberships = async () => {
    try {
      const response = await fetch('/api/user/memberships')
      if (response.ok) {
        const data = await response.json()
        setUserMemberships(Array.isArray(data) ? data : [])
      }
    } catch (error) {
      console.error('Failed to fetch user memberships:', error)
    }
  }

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M'
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K'
    return num.toString()
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString()
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'APPROVED': return 'bg-green-100 text-green-800'
      case 'PENDING': return 'bg-yellow-100 text-yellow-800'
      case 'REJECTED': return 'bg-red-100 text-red-800'
      case 'DRAFT': return 'bg-gray-100 text-gray-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  if (status === 'loading' || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
            <p className="text-muted-foreground">
              Welcome back, {session?.user?.username || session?.user?.name || 'User'}!
            </p>
          </div>
          <Button asChild>
            <Link href="/upload">
              <Plus className="h-4 w-4 mr-2" />
              Upload New
            </Link>
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">My Items</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{userItems.length}</div>
              <p className="text-xs text-muted-foreground">Content you created</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Downloads</CardTitle>
              <Download className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {formatNumber(userItems.reduce((sum, item) => sum + (item.downloads || 0), 0))}
              </div>
              <p className="text-xs text-muted-foreground">Across all your items</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Views</CardTitle>
              <Eye className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {formatNumber(userItems.reduce((sum, item) => sum + (item.views || 0), 0))}
              </div>
              <p className="text-xs text-muted-foreground">People viewed your content</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Likes</CardTitle>
              <Star className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {formatNumber(userItems.reduce((sum, item) => sum + (item.likes || 0), 0))}
              </div>
              <p className="text-xs text-muted-foreground">Community appreciation</p>
            </CardContent>
          </Card>
        </div>

        {/* Membership Section */}
        {userMemberships.length > 0 && (
          <Card className="mb-8 border-2 border-primary/30 bg-gradient-to-r from-primary/5 to-primary/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <span className="text-2xl">👑</span>
                My Memberships
              </CardTitle>
              <CardDescription>Active membership access</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {userMemberships.map((membership) => (
                  <div
                    key={membership.id}
                    className="p-4 rounded-lg border-2 transition-all hover:shadow-lg"
                    style={{ borderColor: membership.color + '40', backgroundColor: membership.color + '10' }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-bold text-lg">{membership.name}</h4>
                      <div
                        className="w-4 h-4 rounded-full"
                        style={{ backgroundColor: membership.color }}
                      />
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{membership.roleName}</p>
                    <div className="text-2xl font-bold text-primary">${membership.price}/mo</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>My Content</CardTitle>
                    <CardDescription>Manage your uploaded items</CardDescription>
                  </div>
                  <Button variant="outline" size="sm" asChild>
                    <Link href="/upload">
                      <Upload className="h-4 w-4 mr-2" />
                      Upload
                    </Link>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {userItems.length === 0 ? (
                  <div className="text-center py-12">
                    <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No content yet</h3>
                    <p className="text-muted-foreground mb-4">
                      Start sharing your Minecraft creations with the community
                    </p>
                    <Button asChild>
                      <Link href="/upload">Upload Your First Item</Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {userItems.map((item) => (
                      <div key={item.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-3 mb-2">
                            <h4 className="font-medium truncate">{item.title}</h4>
                            <Badge className={getStatusColor(item.status)}>
                              {item.status}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <Badge variant="outline">{item.category?.name || 'Uncategorized'}</Badge>
                            <span className="flex items-center gap-1">
                              <Download className="h-3 w-3" />
                              {formatNumber(item.downloads || 0)}
                            </span>
                            <span className="flex items-center gap-1">
                              <Eye className="h-3 w-3" />
                              {formatNumber(item.views || 0)}
                            </span>
                            <span className="flex items-center gap-1">
                              <Star className="h-3 w-3" />
                              {item.likes || 0}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button size="sm" variant="ghost" asChild>
                            <Link href={`/items/${item.slug}`}>
                              <ExternalLink className="h-4 w-4" />
                            </Link>
                          </Button>
                          <Button size="sm" variant="ghost">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {session?.user?.role === 'ADMIN' || session?.user?.role === 'SUPER_ADMIN' ? (
              <Card>
                <CardHeader>
                  <CardTitle>Platform Overview</CardTitle>
                  <CardDescription>Site-wide statistics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 bg-muted/50 rounded-lg">
                      <Users className="h-6 w-6 mx-auto mb-2 text-blue-500" />
                      <div className="text-2xl font-bold">{formatNumber(stats.totalUsers)}</div>
                      <div className="text-xs text-muted-foreground">Total Users</div>
                    </div>
                    <div className="text-center p-4 bg-muted/50 rounded-lg">
                      <Package className="h-6 w-6 mx-auto mb-2 text-green-500" />
                      <div className="text-2xl font-bold">{formatNumber(stats.totalItems)}</div>
                      <div className="text-xs text-muted-foreground">Total Items</div>
                    </div>
                    <div className="text-center p-4 bg-muted/50 rounded-lg">
                      <Download className="h-6 w-6 mx-auto mb-2 text-purple-500" />
                      <div className="text-2xl font-bold">{formatNumber(stats.totalDownloads)}</div>
                      <div className="text-xs text-muted-foreground">Downloads</div>
                    </div>
                    <div className="text-center p-4 bg-muted/50 rounded-lg">
                      <FileText className="h-6 w-6 mx-auto mb-2 text-orange-500" />
                      <div className="text-2xl font-bold">{stats.pendingItems}</div>
                      <div className="text-xs text-muted-foreground">Pending Review</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : null}
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Latest updates</CardDescription>
              </CardHeader>
              <CardContent>
                {stats.recentActivity.length === 0 ? (
                  <div className="text-center py-8">
                    <Clock className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">No recent activity</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {stats.recentActivity.slice(0, 8).map((activity) => (
                      <div key={activity.id} className="flex items-start gap-3 p-3 border rounded-lg">
                        <div className={`p-2 rounded-full ${
                          activity.type === 'upload' ? 'bg-blue-100' :
                          activity.type === 'download' ? 'bg-green-100' :
                          activity.type === 'review' ? 'bg-yellow-100' : 'bg-gray-100'
                        }`}>
                          {activity.type === 'upload' && <Upload className="h-4 w-4 text-blue-600" />}
                          {activity.type === 'download' && <Download className="h-4 w-4 text-green-600" />}
                          {activity.type === 'review' && <Star className="h-4 w-4 text-yellow-600" />}
                          {activity.type === 'user' && <Users className="h-4 w-4 text-gray-600" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{activity.title}</p>
                          <p className="text-xs text-muted-foreground">
                            {activity.user && `by ${activity.user} • `}{formatDate(activity.timestamp)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full justify-start" variant="outline" asChild>
                  <Link href="/upload">
                    <Upload className="h-4 w-4 mr-2" />
                    Upload New Content
                  </Link>
                </Button>
                <Button className="w-full justify-start" variant="outline" asChild>
                  <Link href="/browse">
                    <Package className="h-4 w-4 mr-2" />
                    Browse Marketplace
                  </Link>
                </Button>
                <Button className="w-full justify-start" variant="outline" asChild>
                  <Link href="/profile">
                    <Settings className="h-4 w-4 mr-2" />
                    Edit Profile
                  </Link>
                </Button>
                {(session?.user?.role === 'ADMIN' || session?.user?.role === 'SUPER_ADMIN') && (
                  <Button className="w-full justify-start" variant="outline" asChild>
                    <Link href="/admin">
                      <BarChart3 className="h-4 w-4 mr-2" />
                      Admin Panel
                    </Link>
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
