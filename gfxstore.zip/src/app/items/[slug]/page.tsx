'use client'

import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Separator } from '@/components/ui/separator'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Textarea } from '@/components/ui/textarea'
import { 
  Download, 
  Star, 
  Eye, 
  Calendar, 
  Package, 
  User, 
  Tag, 
  ExternalLink,
  Heart,
  Share2,
  Flag,
  Gamepad2,
  FileArchive,
  Info,
  MessageSquare,
  Send,
  Image as ImageIcon
} from 'lucide-react'
import Link from 'next/link'

interface Item {
  id: string
  title: string
  slug: string
  description: string
  shortDesc: string
  moreInfo?: string
  downloads: number
  likes: number
  views: number
  price: number
  createdAt: string
  updatedAt: string
  status: string
  tags: string[]
  featured: boolean
  author: {
    id: string
    username: string
    avatar?: string
  }
  category: {
    name: string
    slug: string
  }
  subcategory?: {
    name: string
    slug: string
  }
  versions: {
    id: string
    version: string
    fileName: string
    fileSize: number
    downloadUrl: string
    changelog?: string
    createdAt: string
  }[]
  screenshots: {
    id: string
    url: string
    alt?: string
    sortOrder: number
  }[]
  _count: {
    reviews: number
  }
}

export default function ItemPage() {
  const params = useParams()
  const slug = params.slug as string
  const { data: session } = useSession()
  const [item, setItem] = useState<Item | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [selectedVersion, setSelectedVersion] = useState<string>('')
  const [isLiked, setIsLiked] = useState(false)
  const [selectedScreenshotIndex, setSelectedScreenshotIndex] = useState(0)
  const [reviews, setReviews] = useState<any[]>([])
  const [newReview, setNewReview] = useState({ rating: 5, comment: '' })
  const [submittingReview, setSubmittingReview] = useState(false)

  useEffect(() => {
    if (slug) {
      fetchItem()
    }
  }, [slug])

  const fetchItem = async () => {
    try {
      const response = await fetch(`/api/items/${slug}`)
      if (response.ok) {
        const data = await response.json()
        setItem(data)
        if (data.versions.length > 0) {
          setSelectedVersion(data.versions[0].id)
        }
      }
    } catch (error) {
      console.error('Error fetching item:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleDownload = async () => {
    if (!item || !selectedVersion) return

    const version = item.versions.find(v => v.id === selectedVersion)
    if (!version) return

    try {
      await fetch(`/api/items/${item.slug}/download`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          versionId: version.id,
        }),
      })

      window.open(version.downloadUrl, '_blank')
      
      setItem(prev => prev ? {
        ...prev,
        downloads: prev.downloads + 1
      } : null)
    } catch (error) {
      console.error('Error downloading item:', error)
    }
  }

  const handleLike = async () => {
    if (!session) return
    if (!item) return

    try {
      const response = await fetch(`/api/items/${item.slug}/like`, {
        method: 'POST',
      })

      if (response.ok) {
        setIsLiked(!isLiked)
        setItem(prev => prev ? {
          ...prev,
          likes: isLiked ? prev.likes - 1 : prev.likes + 1
        } : null)
      }
    } catch (error) {
      console.error('Error liking item:', error)
    }
  }

  const handleShare = async () => {
    const itemUrl = window.location.href
    if (navigator.share) {
      try {
        await navigator.share({
          title: item?.title,
          text: item?.shortDesc,
          url: itemUrl,
        })
      } catch (error) {
        console.error('Error sharing:', error)
      }
    } else {
      navigator.clipboard.writeText(itemUrl)
      alert('Link copied to clipboard!')
    }
  }

  const handleSubmitComment = async () => {
    if (!session || !item) return
    if (!newReview.comment.trim()) return

    setSubmittingReview(true)
    try {
      const response = await fetch(`/api/items/${item.slug}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newReview),
      })

      if (response.ok) {
        const comment = await response.json()
        setReviews([comment, ...reviews])
        setNewReview({ rating: 5, comment: '' })
      }
    } catch (error) {
      console.error('Error submitting comment:', error)
    } finally {
      setSubmittingReview(false)
    }
  }

  const formatFileSize = (bytes: number) => {
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    if (bytes === 0) return '0 Bytes'
    const i = Math.floor(Math.log(bytes) / Math.log(1024))
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i]
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    })
  }

  const getImageUrl = (url: string) => {
    if (url.startsWith('data:') || url.startsWith('http')) {
      return url
    }
    return url
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-muted rounded w-3/4 mb-4"></div>
            <div className="h-4 bg-muted rounded w-1/2 mb-8"></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-4">
                <div className="h-96 bg-muted rounded-lg"></div>
                <div className="h-32 bg-muted rounded-lg"></div>
              </div>
              <div className="space-y-4">
                <div className="h-40 bg-muted rounded-lg"></div>
                <div className="h-56 bg-muted rounded-lg"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!item) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8 text-center">
          <h1 className="text-2xl font-bold mb-4">Item Not Found</h1>
          <p className="text-muted-foreground mb-4">The item you're looking for doesn't exist.</p>
          <Link href="/browse">
            <Button>Browse Items</Button>
          </Link>
        </div>
        <Footer />
      </div>
    )
  }

  const currentVersion = selectedVersion ? item.versions.find(v => v.id === selectedVersion) : item.versions[0]
  const mainScreenshot = item.screenshots.length > 0 ? item.screenshots[selectedScreenshotIndex] : null

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        {/* Logo and Header Section */}
        <div className="mb-8">
          <div className="flex flex-col lg:flex-row lg:items-start gap-8 mb-6">
            {/* Logo */}
            <div className="flex-shrink-0">
              <div className="w-40 h-40 bg-muted rounded-xl overflow-hidden flex items-center justify-center border-2 border-border">
                {item.logo ? (
                  <img
                    src={item.logo}
                    alt={item.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement
                      target.src = '/placeholder-item.png'
                    }}
                  />
                ) : item.screenshots && item.screenshots.length > 0 ? (
                  <img
                    src={item.screenshots[0]?.url}
                    alt={item.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement
                      target.src = '/placeholder-item.png'
                    }}
                  />
                ) : (
                  <ImageIcon className="h-12 w-12 text-muted-foreground" />
                )}
              </div>
            </div>

            {/* Title and Info */}
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-3 flex-wrap">
                <Link href={`/browse?category=${item.category.slug}`}>
                  <Badge variant="outline" className="cursor-pointer hover:bg-accent">
                    {item.category.name}
                  </Badge>
                </Link>
                {item.subcategory && (
                  <Link href={`/browse?subcategory=${item.subcategory.slug}`}>
                    <Badge variant="secondary" className="cursor-pointer hover:bg-accent">
                      {item.subcategory.name}
                    </Badge>
                  </Link>
                )}
                {item.featured && (
                  <Badge className="bg-yellow-500/90 hover:bg-yellow-600">
                    ⭐ Featured
                  </Badge>
                )}
              </div>
              <h1 className="text-4xl font-bold mb-3">{item.title}</h1>
              <p className="text-lg text-muted-foreground mb-4">{item.shortDesc}</p>
              
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Download className="h-4 w-4" />
                  {item.downloads.toLocaleString()} downloads
                </div>
                <div className="flex items-center gap-2">
                  <Eye className="h-4 w-4" />
                  {item.views.toLocaleString()} views
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  {formatDate(item.updatedAt)}
                </div>
              </div>

              <div className="flex items-center gap-2 mt-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleLike}
                  disabled={!session}
                  className={isLiked ? 'text-red-500 border-red-500' : ''}
                  title={session ? 'Like this item' : 'Sign in to like'}
                >
                  <Heart className={`h-4 w-4 mr-2 ${isLiked ? 'fill-current' : ''}`} />
                  {item.likes}
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleShare}
                  title="Share this item"
                >
                  <Share2 className="h-4 w-4 mr-2" />
                  Share
                </Button>
              </div>
            </div>
          </div>

          <Separator />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Main Screenshot Gallery */}
            {item.screenshots.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Gallery</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="aspect-video bg-muted rounded-lg overflow-hidden flex items-center justify-center">
                    {mainScreenshot && (
                      <img
                        src={getImageUrl(mainScreenshot.url)}
                        alt={mainScreenshot.alt || item.title}
                        className="w-full h-full object-contain"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement
                          target.src = '/placeholder-item.png'
                        }}
                      />
                    )}
                  </div>
                  
                  {item.screenshots.length > 1 && (
                    <div className="grid grid-cols-4 md:grid-cols-6 gap-2">
                      {item.screenshots.map((screenshot, index) => (
                        <button
                          key={screenshot.id}
                          onClick={() => setSelectedScreenshotIndex(index)}
                          className={`aspect-square rounded-lg overflow-hidden border-2 transition ${
                            selectedScreenshotIndex === index 
                              ? 'border-primary' 
                              : 'border-transparent hover:border-muted-foreground'
                          }`}
                        >
                          <img
                            src={getImageUrl(screenshot.url)}
                            alt={`Screenshot ${index + 1}`}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement
                              target.src = '/placeholder-item.png'
                            }}
                          />
                        </button>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Description */}
            <Card>
              <CardHeader>
                <CardTitle>Description</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose prose-sm dark:prose-invert max-w-none">
                  <p className="whitespace-pre-wrap text-foreground leading-relaxed">{item.description}</p>
                </div>
              </CardContent>
            </Card>

            {/* Additional Information */}
            {item.moreInfo && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Info className="h-5 w-5" />
                    Additional Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="prose prose-sm dark:prose-invert max-w-none">
                    <p className="whitespace-pre-wrap text-foreground leading-relaxed">{item.moreInfo}</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Tags */}
            {item.tags.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Tag className="h-5 w-5" />
                    Tags
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {item.tags.map((tag, index) => (
                      <Badge key={index} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Versions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5" />
                  Versions
                </CardTitle>
                <CardDescription>Available download versions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {item.versions.map((version) => (
                    <div 
                      key={version.id} 
                      className={`p-4 border rounded-lg cursor-pointer transition ${
                        selectedVersion === version.id 
                          ? 'border-primary bg-primary/5' 
                          : 'border-muted hover:border-muted-foreground'
                      }`}
                      onClick={() => setSelectedVersion(version.id)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold">v{version.version}</span>
                            <Badge variant="outline" className="text-xs">
                              <FileArchive className="h-3 w-3 mr-1" />
                              {formatFileSize(version.fileSize)}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {formatDate(version.createdAt)}
                          </p>
                          {version.changelog && (
                            <p className="text-sm text-foreground">{version.changelog}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Download Card */}
            <Card className="sticky top-6 border-primary/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-2xl">
                  {item.price && item.price > 0 ? `$${item.price.toFixed(2)}` : 'Free'}
                </CardTitle>
                <CardDescription>
                  {item.price > 0 ? 'One-time purchase' : 'No cost'}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {currentVersion && (
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Latest Version</span>
                      <span className="font-semibold">v{currentVersion.version}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">File Size</span>
                      <span className="font-semibold">{formatFileSize(currentVersion.fileSize)}</span>
                    </div>
                  </div>
                )}
                
                <Button onClick={handleDownload} className="w-full" size="lg">
                  <Download className="h-4 w-4 mr-2" />
                  Download Now
                </Button>
              </CardContent>
            </Card>

            {/* Author Card */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Author</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={item.author.avatar} />
                    <AvatarFallback>{item.author.username.charAt(0).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div>
                    <Link href={`/profile/${item.author.username}`}>
                      <p className="font-semibold hover:underline cursor-pointer">{item.author.username}</p>
                    </Link>
                    <p className="text-sm text-muted-foreground">Creator</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Details Card */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3 text-sm">
                  <div className="flex items-start gap-2">
                    <Gamepad2 className="h-5 w-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-muted-foreground">Minecraft Version</p>
                      <p className="font-semibold">Check item description for details</p>
                    </div>
                  </div>
                  <Separator />
                  <div className="flex items-start gap-2">
                    <Package className="h-5 w-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-muted-foreground">Total Downloads</p>
                      <p className="font-semibold">{item.downloads.toLocaleString()}</p>
                    </div>
                  </div>
                  <Separator />
                  <div className="flex items-start gap-2">
                    <Calendar className="h-5 w-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-muted-foreground">Last Updated</p>
                      <p className="font-semibold">{formatDate(item.updatedAt)}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
