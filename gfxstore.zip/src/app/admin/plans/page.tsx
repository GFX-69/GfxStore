'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Trash2, 
  Edit, 
  Plus, 
  Save, 
  X,
  Loader2
} from 'lucide-react'

interface Plan {
  id: string
  name: string
  description: string
  price: number
  features?: any[]
  specs?: any
  isActive: boolean
  sortOrder: number
  createdAt: string
  updatedAt: string
}

const BOX_TYPES = ['gradient', 'solid', 'image', 'card']
const COLORS = [
  '#6366f1', '#8b5cf6', '#d946ef', '#ec4899',
  '#f43f5e', '#f97316', '#eab308', '#22c55e',
  '#10b981', '#14b8a6', '#06b6d4', '#0ea5e9'
]

export default function AdminPlans() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [plans, setPlans] = useState<Plan[]>([])
  const [loading, setLoading] = useState(true)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    features: '',
    boxType: 'card',
    backgroundColor: '#6366f1',
    backgroundImage: '',
    planImage: '',
    planGif: '',
    isActive: true,
    sortOrder: 0
  })

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
    }
    if (status === 'authenticated') {
      checkAdminAccess()
      fetchPlans()
    }
  }, [status])

  const checkAdminAccess = async () => {
    try {
      const response = await fetch('/api/admin/check-access')
      if (!response.ok) {
        router.push('/dashboard')
      }
    } catch (error) {
      router.push('/dashboard')
    }
  }

  const fetchPlans = async () => {
    try {
      const response = await fetch('/api/admin/plans')
      if (response.ok) {
        const data = await response.json()
        setPlans(Array.isArray(data.plans) ? data.plans : [])
      } else {
        setPlans([])
      }
    } catch (error) {
      console.error('Failed to fetch plans:', error)
      setPlans([])
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    const payload = {
      name: formData.name,
      description: formData.description,
      price: formData.price,
      features: formData.features.split('\n').filter(f => f.trim()),
      specs: {
        boxType: formData.boxType,
        backgroundColor: formData.backgroundColor,
        backgroundImage: formData.backgroundImage,
        planImage: formData.planImage,
        planGif: formData.planGif
      },
      isActive: formData.isActive,
      sortOrder: formData.sortOrder
    }

    try {
      const url = editingId ? `/api/admin/plans/${editingId}` : '/api/admin/plans'
      const method = editingId ? 'PUT' : 'POST'
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })

      if (response.ok) {
        fetchPlans()
        resetForm()
      } else {
        console.error('Failed to save plan:', response.statusText)
        alert('Failed to save plan: ' + response.statusText)
      }
    } catch (error) {
      console.error('Failed to save plan:', error)
      alert('Failed to save plan')
    }
  }

  const handleEdit = (plan: Plan) => {
    setFormData({
      name: plan.name,
      description: plan.description,
      price: plan.price.toString(),
      features: (plan.features || []).join('\n'),
      boxType: plan.specs?.boxType || 'card',
      backgroundColor: plan.specs?.backgroundColor || '#6366f1',
      backgroundImage: plan.specs?.backgroundImage || '',
      planImage: plan.specs?.planImage || '',
      planGif: plan.specs?.planGif || '',
      isActive: plan.isActive,
      sortOrder: plan.sortOrder
    })
    setEditingId(plan.id)
    setShowForm(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this plan?')) return

    try {
      const response = await fetch(`/api/admin/plans/${id}`, { method: 'DELETE' })
      if (response.ok) {
        fetchPlans()
      }
    } catch (error) {
      console.error('Failed to delete plan:', error)
    }
  }

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      price: '',
      features: '',
      boxType: 'card',
      backgroundColor: '#6366f1',
      backgroundImage: '',
      planImage: '',
      planGif: '',
      isActive: true,
      sortOrder: 0
    })
    setEditingId(null)
    setShowForm(false)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">VPS & Server Plans</h1>
          <p className="text-muted-foreground">Manage hosting plans, pricing, and features</p>
        </div>

        <Tabs defaultValue="list" className="space-y-4">
          <TabsList>
            <TabsTrigger value="list">Plans ({plans.length})</TabsTrigger>
            <TabsTrigger value="create">Add New Plan</TabsTrigger>
          </TabsList>

          <TabsContent value="list">
            <div className="grid gap-4">
              {plans.length === 0 ? (
                <Card>
                  <CardContent className="pt-6 text-center text-muted-foreground">
                    No plans found. Create your first plan!
                  </CardContent>
                </Card>
              ) : (
                plans.map(plan => (
                  <Card key={plan.id}>
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            {plan.name}
                            {plan.isActive ? (
                              <Badge variant="outline" className="bg-green-500/10">Active</Badge>
                            ) : (
                              <Badge variant="outline" className="bg-red-500/10">Inactive</Badge>
                            )}
                          </CardTitle>
                          <CardDescription>{plan.description}</CardDescription>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold">${plan.price}</p>
                          <p className="text-xs text-muted-foreground">/month</p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {plan.features && plan.features.length > 0 && (
                        <div>
                          <p className="text-sm font-medium mb-2">Features:</p>
                          <ul className="text-sm space-y-1 text-muted-foreground">
                            {plan.features.map((f, i) => <li key={i}>• {f}</li>)}
                          </ul>
                        </div>
                      )}
                      
                      {plan.specs && (
                        <div className="space-y-3 pt-2 border-t">
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                            <div>
                              <p className="text-xs text-muted-foreground">Box Type</p>
                              <p className="text-sm font-medium">{plan.specs.boxType || 'card'}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Sort Order</p>
                              <p className="text-sm font-medium">{plan.sortOrder}</p>
                            </div>
                            {plan.specs.backgroundColor && (
                              <div>
                                <p className="text-xs text-muted-foreground">Background Color</p>
                                <div className="w-8 h-8 rounded border-2 border-primary" style={{ backgroundColor: plan.specs.backgroundColor }}></div>
                              </div>
                            )}
                            {plan.specs.backgroundImage && (
                              <div>
                                <p className="text-xs text-muted-foreground">Background Image</p>
                                <p className="text-xs truncate text-blue-500">✓ Image Set</p>
                              </div>
                            )}
                          </div>
                          {plan.specs.backgroundImage && (
                            <div className="relative w-full h-32 rounded-lg border overflow-hidden bg-muted">
                              <img 
                                src={plan.specs.backgroundImage} 
                                alt={plan.name}
                                className="w-full h-full object-cover"
                              />
                              <div className="absolute inset-0 bg-black/20"></div>
                            </div>
                          )}
                        </div>
                      )}

                      <div className="flex gap-2 pt-4 border-t">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEdit(plan)}
                          className="flex-1"
                        >
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDelete(plan.id)}
                          className="flex-1"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="create" className="space-y-4">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Plan Name *</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g., Basic Plan"
                    required
                  />
                </div>
                <div>
                  <Label>Price (USD) *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    placeholder="9.99"
                    required
                  />
                </div>
              </div>

              <div>
                <Label>Description *</Label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Brief description of the plan"
                  required
                />
              </div>

              <div>
                <Label>Features (one per line)</Label>
                <Textarea
                  value={formData.features}
                  onChange={(e) => setFormData({ ...formData, features: e.target.value })}
                  placeholder="2GB RAM&#10;20GB SSD Storage&#10;2 CPU Cores"
                  rows={5}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Box Type</Label>
                  <Select value={formData.boxType} onValueChange={(v) => setFormData({ ...formData, boxType: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {BOX_TYPES.map(type => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Background Color</Label>
                  <div className="flex gap-2 flex-wrap">
                    {COLORS.map(color => (
                      <button
                        key={color}
                        type="button"
                        onClick={() => setFormData({ ...formData, backgroundColor: color })}
                        className={`w-8 h-8 rounded border-2 ${
                          formData.backgroundColor === color ? 'border-foreground' : 'border-muted'
                        }`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <Label>Background Image URL</Label>
                <Input
                  value={formData.backgroundImage}
                  onChange={(e) => setFormData({ ...formData, backgroundImage: e.target.value })}
                  placeholder="https://example.com/image.jpg"
                />
                {formData.backgroundImage && (
                  <div className="mt-3 relative w-full h-40 rounded-lg border overflow-hidden bg-muted">
                    <img 
                      src={formData.backgroundImage} 
                      alt="Background preview"
                      className="w-full h-full object-cover"
                      onError={() => console.log('Image failed to load')}
                    />
                    <div className="absolute inset-0 bg-black/10"></div>
                    <p className="absolute bottom-2 left-2 text-xs bg-black/50 text-white px-2 py-1 rounded">Preview</p>
                  </div>
                )}
              </div>

              <div>
                <Label>Plan Image URL (displayed on plan card)</Label>
                <Input
                  value={formData.planImage}
                  onChange={(e) => setFormData({ ...formData, planImage: e.target.value })}
                  placeholder="https://example.com/plan-image.png"
                />
                {formData.planImage && (
                  <div className="mt-3 relative w-full h-32 rounded-lg border overflow-hidden bg-muted">
                    <img 
                      src={formData.planImage} 
                      alt="Plan preview"
                      className="w-full h-full object-contain p-2"
                    />
                  </div>
                )}
              </div>

              <div>
                <Label>Plan GIF URL (displayed on plan card)</Label>
                <Input
                  value={formData.planGif}
                  onChange={(e) => setFormData({ ...formData, planGif: e.target.value })}
                  placeholder="https://example.com/plan-animation.gif"
                />
                {formData.planGif && (
                  <div className="mt-3 relative w-full h-32 rounded-lg border overflow-hidden bg-muted">
                    <img 
                      src={formData.planGif} 
                      alt="Plan GIF preview"
                      className="w-full h-full object-contain p-2"
                    />
                  </div>
                )}
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Sort Order</Label>
                  <Input
                    type="number"
                    value={formData.sortOrder}
                    onChange={(e) => setFormData({ ...formData, sortOrder: parseInt(e.target.value) || 0 })}
                    placeholder="0"
                  />
                </div>

                <div className="flex items-end gap-2">
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={formData.isActive}
                      onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                    />
                    <Label>{formData.isActive ? 'Active' : 'Inactive'}</Label>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 pt-4 border-t">
                <Button type="submit" className="flex-1">
                  <Save className="h-4 w-4 mr-2" />
                  {editingId ? 'Update Plan' : 'Create Plan'}
                </Button>
                {editingId && (
                  <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                    <X className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                )}
              </div>
            </form>
          </TabsContent>
        </Tabs>
      </div>

      <Footer />
    </div>
  )
}
