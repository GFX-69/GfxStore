'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Loader2, Check, X } from 'lucide-react'

interface Transaction {
  id: string
  userId: string
  user?: { username: string; email: string }
  amount: number
  method: string
  reference: string
  status: string
  createdAt: string
}

export default function TransactionsAdminPage() {
  const { data: session, status: authStatus } = useSession()
  const router = useRouter()
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null)
  const [approving, setApproving] = useState(false)

  useEffect(() => {
    if (authStatus === 'loading') return
    
    if (authStatus === 'unauthenticated' || session?.user?.role !== 'ADMIN') {
      router.push('/')
      return
    }

    fetchTransactions()
  }, [authStatus, session, router])

  const fetchTransactions = async () => {
    try {
      const res = await fetch('/api/admin/transactions')
      if (res.ok) {
        const data = await res.json()
        setTransactions(data)
      }
    } catch (error) {
      console.error('Failed to fetch transactions:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleApprove = async (transactionId: string) => {
    setApproving(true)
    try {
      const res = await fetch(`/api/admin/transactions/${transactionId}/approve`, {
        method: 'POST'
      })

      if (res.ok) {
        alert('Transaction approved! Coins added to user account.')
        setSelectedTx(null)
        fetchTransactions()
      } else {
        alert('Failed to approve transaction')
      }
    } catch (error) {
      console.error('Approval failed:', error)
      alert('Approval failed')
    } finally {
      setApproving(false)
    }
  }

  const handleReject = async (transactionId: string) => {
    if (!confirm('Are you sure you want to reject this transaction?')) return

    try {
      const res = await fetch(`/api/admin/transactions/${transactionId}/reject`, {
        method: 'POST'
      })

      if (res.ok) {
        alert('Transaction rejected.')
        setSelectedTx(null)
        fetchTransactions()
      } else {
        alert('Failed to reject transaction')
      }
    } catch (error) {
      console.error('Rejection failed:', error)
      alert('Rejection failed')
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  const pendingTransactions = transactions.filter(tx => tx.status === 'PENDING')
  const completedTransactions = transactions.filter(tx => tx.status === 'COMPLETED')

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Transaction Management</h2>
        <p className="text-muted-foreground">Review and approve deposit transactions from users</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Pending Transactions</span>
            <Badge>{pendingTransactions.length}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {pendingTransactions.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No pending transactions</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Reference</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pendingTransactions.map((tx) => (
                    <TableRow key={tx.id}>
                      <TableCell className="font-medium">
                        {tx.user?.username || tx.userId}
                      </TableCell>
                      <TableCell>${tx.amount.toFixed(2)}</TableCell>
                      <TableCell className="capitalize">{tx.method}</TableCell>
                      <TableCell className="font-mono text-sm">{tx.reference}</TableCell>
                      <TableCell>
                        {new Date(tx.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          onClick={() => setSelectedTx(tx)}
                        >
                          Review
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Completed Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          {completedTransactions.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No completed transactions</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {completedTransactions.map((tx) => (
                    <TableRow key={tx.id}>
                      <TableCell className="font-medium">
                        {tx.user?.username || tx.userId}
                      </TableCell>
                      <TableCell>${tx.amount.toFixed(2)}</TableCell>
                      <TableCell className="capitalize">{tx.method}</TableCell>
                      <TableCell>
                        {new Date(tx.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <Badge>Completed</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Review Modal */}
      <Dialog open={!!selectedTx} onOpenChange={() => setSelectedTx(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Review Transaction</DialogTitle>
            <DialogDescription>
              Verify the transaction details before approving
            </DialogDescription>
          </DialogHeader>

          {selectedTx && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">User</p>
                  <p className="font-medium">{selectedTx.user?.username}</p>
                  <p className="text-xs text-muted-foreground">{selectedTx.user?.email}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Amount</p>
                  <p className="font-bold text-lg">${selectedTx.amount.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Method</p>
                  <p className="font-medium capitalize">{selectedTx.method}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Reference</p>
                  <p className="font-mono text-sm">{selectedTx.reference}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-sm text-muted-foreground">Date</p>
                  <p className="font-medium">
                    {new Date(selectedTx.createdAt).toLocaleString()}
                  </p>
                </div>
              </div>

              <div className="flex gap-2 pt-4">
                <Button
                  variant="destructive"
                  className="flex-1"
                  onClick={() => handleReject(selectedTx.id)}
                >
                  <X className="h-4 w-4 mr-2" />
                  Reject
                </Button>
                <Button
                  className="flex-1"
                  onClick={() => handleApprove(selectedTx.id)}
                  disabled={approving}
                >
                  {approving ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Approving...
                    </>
                  ) : (
                    <>
                      <Check className="h-4 w-4 mr-2" />
                      Approve
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
