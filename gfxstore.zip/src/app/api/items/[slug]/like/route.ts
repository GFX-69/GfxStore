import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const { slug } = await params

    // Find the item
    const item = await db.item.findUnique({
      where: { slug },
    })

    if (!item) {
      return NextResponse.json(
        { error: 'Item not found' },
        { status: 404 }
      )
    }

    if (item.status !== 'APPROVED') {
      return NextResponse.json(
        { error: 'Item not available' },
        { status: 403 }
      )
    }

    // Check if user already liked this item
    const existingLike = await db.review.findFirst({
      where: {
        itemId: item.id,
        userId: session.user.id,
      },
    })

    if (existingLike) {
      // Remove like
      await db.review.delete({
        where: {
          id: existingLike.id,
        },
      })

      // Update like count
      await db.item.update({
        where: { id: item.id },
        data: {
          likes: {
            decrement: 1,
          },
        },
      })

      return NextResponse.json({
        liked: false,
        likes: item.likes - 1,
      })
    } else {
      // Add like
      await db.review.create({
        data: {
          itemId: item.id,
          userId: session.user.id,
          rating: 5, // Default rating for likes
        },
      })

      // Update like count
      const updatedItem = await db.item.update({
        where: { id: item.id },
        data: {
          likes: {
            increment: 1,
          },
        },
      })

      // Send notification to item author
      try {
        const liker = await db.user.findUnique({ where: { id: session.user.id }, select: { username: true } })
        const globalSendNotification = (global as any).sendNotification
        if (globalSendNotification && liker) {
          await globalSendNotification(item.authorId, {
            title: '❤️ Your Item Got Liked!',
            content: `${liker.username} liked "${item.title}"`,
            type: 'ITEM_LIKED',
            itemId: item.id
          })
        }
      } catch (error) {
        console.error('Error sending like notification:', error)
      }

      return NextResponse.json({
        liked: true,
        likes: updatedItem.likes,
      })
    }
  } catch (error) {
    console.error('Error liking item:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}