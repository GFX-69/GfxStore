import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { writeFile, mkdir, unlink, rmdir } from 'fs/promises'
import { join } from 'path'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

const MAX_FILE_SIZE = 100 * 1024 * 1024 // 100MB
const MAX_SCREENSHOT_SIZE = 10 * 1024 * 1024 // 10MB
const MAX_FILES = 5
const MAX_SCREENSHOTS = 10

const ALLOWED_FILE_TYPES = [
  'application/zip',
  'application/x-zip-compressed',
  'application/x-rar-compressed',
  'application/java-archive',
  'application/octet-stream'
]

const ALLOWED_FILE_EXTENSIONS = ['.zip', '.rar', '.jar', '.mcworld', '.mcpack', '.mctemplate', '.mcaddon']

const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp']

function sanitizeFileName(filename: string): string {
  const ext = filename.split('.').pop() || ''
  const name = filename.slice(0, -(ext.length + 1))
  const safeName = name
    .replace(/[^a-zA-Z0-9._-]/g, '_')
    .replace(/__+/g, '_')
    .slice(0, 100)
  return `${safeName}.${ext}`
}

function generateUniqueSlug(title: string, timestamp: number): string {
  const baseSlug = title.toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
  return `${baseSlug}-${timestamp}`
}

function validateFileType(file: File, isScreenshot: boolean): { valid: boolean; error?: string } {
  if (isScreenshot) {
    if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
      return { valid: false, error: `Invalid image type: ${file.type}. Allowed: JPEG, PNG, GIF, WebP` }
    }
    if (file.size > MAX_SCREENSHOT_SIZE) {
      return { valid: false, error: `Screenshot ${file.name} exceeds 10MB limit` }
    }
  } else {
    const ext = `.${file.name.split('.').pop()?.toLowerCase()}`
    if (!ALLOWED_FILE_EXTENSIONS.includes(ext)) {
      return { valid: false, error: `Invalid file type: ${ext}. Allowed: ${ALLOWED_FILE_EXTENSIONS.join(', ')}` }
    }
    if (file.size > MAX_FILE_SIZE) {
      return { valid: false, error: `File ${file.name} exceeds 100MB limit` }
    }
  }
  return { valid: true }
}

export async function POST(request: Request) {
  let uploadDir: string | null = null
  let itemId: string | null = null
  
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized. Please sign in.' },
        { status: 401 }
      )
    }

    const formData = await request.formData()
    
    const title = formData.get('title') as string
    const description = formData.get('description') as string
    const shortDesc = formData.get('shortDesc') as string
    const categoryId = formData.get('categoryId') as string
    const priceValue = formData.get('price') as string
    const price = priceValue ? parseFloat(priceValue) : 0
    const tagsValue = formData.get('tags') as string
    const tags = tagsValue ? tagsValue.split(',').map(t => t.trim()).filter(t => t.length > 0) : []

    if (!title || !description || !categoryId) {
      return NextResponse.json(
        { error: 'Missing required fields: title, description, and category are required' },
        { status: 400 }
      )
    }

    if (title.length > 200) {
      return NextResponse.json(
        { error: 'Title must be 200 characters or less' },
        { status: 400 }
      )
    }

    const files = formData.getAll('files') as File[]
    const screenshots = formData.getAll('screenshots') as File[]
    const logoFile = formData.get('logo') as File

    if (files.length === 0) {
      return NextResponse.json(
        { error: 'At least one content file is required' },
        { status: 400 }
      )
    }

    if (files.length > MAX_FILES) {
      return NextResponse.json(
        { error: `Maximum ${MAX_FILES} files allowed` },
        { status: 400 }
      )
    }

    if (screenshots.length > MAX_SCREENSHOTS) {
      return NextResponse.json(
        { error: `Maximum ${MAX_SCREENSHOTS} screenshots allowed` },
        { status: 400 }
      )
    }

    for (const file of files) {
      const validation = validateFileType(file, false)
      if (!validation.valid) {
        return NextResponse.json({ error: validation.error }, { status: 400 })
      }
    }

    for (const screenshot of screenshots) {
      const validation = validateFileType(screenshot, true)
      if (!validation.valid) {
        return NextResponse.json({ error: validation.error }, { status: 400 })
      }
    }

    const timestamp = Date.now()
    const slug = generateUniqueSlug(title, timestamp)

    const item = await db.item.create({
      data: {
        title,
        slug,
        description,
        shortDesc: shortDesc || null,
        categoryId,
        authorId: session.user.id,
        price,
        tags,
        status: 'PENDING'
      }
    })

    itemId = item.id
    uploadDir = join(process.cwd(), 'uploads', item.id)
    await mkdir(uploadDir, { recursive: true })

    const savedFiles: string[] = []

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i]
        if (file.size > 0) {
          const buffer = Buffer.from(await file.arrayBuffer())
          const safeFileName = sanitizeFileName(file.name)
          const filePath = join(uploadDir, safeFileName)
          await writeFile(filePath, buffer)
          savedFiles.push(filePath)

          // Generate unique version per file to avoid constraint violations
          const fileVersion = `1.0.${i}`

          await db.itemVersion.create({
            data: {
              itemId: item.id,
              version: fileVersion,
              fileName: safeFileName,
              fileSize: file.size,
              filePath: `/uploads/${item.id}/${safeFileName}`,
              downloadUrl: `/api/download/${item.id}/${safeFileName}`,
              isActive: true
            }
          })
        }
      }

      for (const screenshot of screenshots) {
        if (screenshot.size > 0) {
          const buffer = Buffer.from(await screenshot.arrayBuffer())
          const safeFileName = sanitizeFileName(screenshot.name)
          const filePath = join(uploadDir, safeFileName)
          await writeFile(filePath, buffer)
          savedFiles.push(filePath)

          await db.screenshot.create({
            data: {
              itemId: item.id,
              url: `/uploads/${item.id}/${safeFileName}`,
              alt: screenshot.name.replace(/\.[^/.]+$/, '')
            }
          })
        }
      }

      // Handle logo upload
      if (logoFile && logoFile.size > 0) {
        const logoValidation = validateFileType(logoFile, true)
        if (logoValidation.valid) {
          const buffer = Buffer.from(await logoFile.arrayBuffer())
          const safeFileName = sanitizeFileName(logoFile.name)
          const filePath = join(uploadDir, safeFileName)
          await writeFile(filePath, buffer)
          savedFiles.push(filePath)

          // Update item with logo URL
          await db.item.update({
            where: { id: item.id },
            data: {
              logo: `/uploads/${item.id}/${safeFileName}`
            }
          })
        }
      }
    } catch (fileError) {
      for (const filePath of savedFiles) {
        try {
          await unlink(filePath)
        } catch {}
      }
      
      if (uploadDir) {
        try {
          await rmdir(uploadDir)
        } catch {}
      }
      
      if (itemId) {
        await db.itemVersion.deleteMany({ where: { itemId } })
        await db.screenshot.deleteMany({ where: { itemId } })
        await db.item.delete({ where: { id: itemId } })
      }
      
      throw fileError
    }

    if ((global as any).sendNotification) {
      const admins = await db.user.findMany({
        where: { role: { in: ['ADMIN', 'SUPER_ADMIN', 'MODERATOR'] } },
        select: { id: true }
      })
      
      for (const admin of admins) {
        await (global as any).sendNotification(admin.id, {
          title: 'New Item Pending Review',
          content: `"${title}" has been submitted and needs approval.`,
          type: 'ITEM_UPDATED',
          itemId: item.id
        })
      }
    }

    return NextResponse.json({
      message: 'Item uploaded successfully',
      item: {
        id: item.id,
        slug: item.slug,
        title: item.title
      }
    })
  } catch (error) {
    console.error('Upload error:', error)
    return NextResponse.json(
      { 
        status: 'error', 
        message: 'Failed to upload item',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}
