import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { amount, method, transactionId, senderName, proof } = body

    if (!amount || !method || !transactionId || amount <= 0) {
      return NextResponse.json({ error: 'Invalid transaction data' }, { status: 400 })
    }

    try {
      // Create transaction with PENDING status - trust the session
      const transaction = await db.transaction.create({
        data: {
          userId: session.user.id,
          amount: parseFloat(String(amount)),
          method: String(method),
          type: 'DEPOSIT',
          reference: String(transactionId),
          status: 'PENDING',
        }
      })

      console.log('Transaction submitted:', {
        transactionId: transaction.id,
        userId: session.user.id,
        amount,
        method,
        senderName,
        proof
      })

      return NextResponse.json({
        success: true,
        transactionId: transaction.id,
        message: 'Transaction submitted for admin review'
      })
    } catch (dbError: any) {
      // If user doesn't exist, create them automatically
      if (dbError.code === 'P2003' || dbError.message?.includes('foreign key')) {
        console.log('Creating user on-the-fly for transaction:', session.user.id)
        
        // Create user with data from session
        const newUser = await db.user.create({
          data: {
            id: session.user.id,
            email: session.user.email || `user-${session.user.id}@gfxstore.local`,
            username: session.user.name || `user-${session.user.id}`,
            password: 'oauth-user', // OAuth users don't have passwords
            role: 'USER'
          }
        })

        // Now create the transaction
        const transaction = await db.transaction.create({
          data: {
            userId: newUser.id,
            amount: parseFloat(String(amount)),
            method: String(method),
            type: 'DEPOSIT',
            reference: String(transactionId),
            status: 'PENDING',
          }
        })

        return NextResponse.json({
          success: true,
          transactionId: transaction.id,
          message: 'Transaction submitted for admin review'
        })
      }
      throw dbError
    }
  } catch (error) {
    console.error('Error submitting transaction:', error)
    const errorMsg = error instanceof Error ? error.message : 'Failed to submit transaction'
    return NextResponse.json({ error: errorMsg }, { status: 500 })
  }
}
