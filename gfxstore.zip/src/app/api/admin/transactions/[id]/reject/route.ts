import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const transaction = await db.transaction.findUnique({
      where: { id }
    })

    if (!transaction) {
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })
    }

    // Update transaction status to rejected
    const updatedTx = await db.transaction.update({
      where: { id },
      data: { status: 'REJECTED' }
    })

    return NextResponse.json({ success: true, transaction: updatedTx })
  } catch (error) {
    console.error('Error rejecting transaction:', error)
    return NextResponse.json({ error: 'Failed to reject transaction' }, { status: 500 })
  }
}
