import { NextRequest, NextResponse } from 'next/server'
import { join } from 'path'
import { existsSync, readFileSync } from 'fs'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ itemId: string; filename: string }> }
) {
  try {
    const { itemId, filename } = await params
    
    if (!itemId || !filename) {
      return NextResponse.json({ error: 'Missing parameters' }, { status: 400 })
    }

    const filePath = join(process.cwd(), 'uploads', itemId, filename)
    const uploadsDir = join(process.cwd(), 'uploads')
    
    if (!filePath.startsWith(uploadsDir)) {
      return NextResponse.json({ error: 'Invalid path' }, { status: 403 })
    }

    if (!existsSync(filePath)) {
      return NextResponse.json({ error: 'File not found' }, { status: 404 })
    }

    const ext = filename.split('.').pop()?.toLowerCase() || ''
    const contentTypeMap: { [key: string]: string } = {
      zip: 'application/zip',
      rar: 'application/x-rar-compressed',
      jar: 'application/java-archive',
      mcaddon: 'application/octet-stream',
      mcpack: 'application/octet-stream',
      mcworld: 'application/octet-stream',
      png: 'image/png',
      jpg: 'image/jpeg',
      jpeg: 'image/jpeg',
      gif: 'image/gif',
    }
    const contentType = contentTypeMap[ext] || 'application/octet-stream'

    const fileData = readFileSync(filePath)
    return new NextResponse(fileData, {
      headers: {
        'Content-Type': contentType,
        'Content-Length': fileData.length.toString(),
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Cache-Control': 'public, max-age=31536000',
      }
    })
  } catch (error) {
    console.error('File download error:', error)
    return NextResponse.json({ error: 'Failed to download file' }, { status: 500 })
  }
}
