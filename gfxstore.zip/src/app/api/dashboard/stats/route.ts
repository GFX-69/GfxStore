import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    await db.$connect()

    // Get real-time dashboard stats
    const [
      totalUsers,
      totalItems,
      totalDownloads,
      pendingItems,
      approvedItems
    ] = await Promise.all([
      db.user.count(),
      db.item.count(),
      db.item.aggregate({
        _sum: { downloads: true }
      }),
      db.item.count({
        where: { status: 'PENDING' }
      }),
      db.item.count({
        where: { status: 'APPROVED' }
      })
    ])

    // Calculate total revenue from paid items
    const revenueData = await db.item.aggregate({
      where: {
        status: 'APPROVED',
        price: { gt: 0 }
      },
      _sum: { price: true }
    })

    // Get recent activity
    const recentItems = await db.item.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      include: {
        author: {
          select: { username: true }
        }
      }
    })

    const recentDownloads = await db.download.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      include: {
        item: {
          select: { title: true }
        },
        user: {
          select: { username: true }
        }
      }
    })

    const recentReviews = await db.review.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      include: {
        item: {
          select: { title: true }
        },
        user: {
          select: { username: true }
        }
      }
    })

    // Combine and sort recent activity
    const recentActivity = [
      ...recentItems.map(item => ({
        id: item.id,
        type: 'upload' as const,
        title: `New item: ${item.title}`,
        timestamp: item.createdAt.toISOString(),
        user: item.author.username
      })),
      ...recentDownloads.map(download => ({
        id: download.id,
        type: 'download' as const,
        title: `Downloaded: ${download.item.title}`,
        timestamp: download.createdAt.toISOString(),
        user: download.user?.username
      })),
      ...recentReviews.map(review => ({
        id: review.id,
        type: 'review' as const,
        title: `Reviewed: ${review.item.title}`,
        timestamp: review.createdAt.toISOString(),
        user: review.user.username
      }))
    ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 10)

    // Simulate active users (in real app, this would be from session tracking)
    const activeUsers = Math.floor(totalUsers * 0.1) // Assume 10% are active

    await db.$disconnect()

    return NextResponse.json({
      totalUsers,
      totalItems,
      totalDownloads: totalDownloads._sum.downloads || 0,
      totalRevenue: revenueData._sum.price || 0,
      activeUsers,
      pendingItems,
      approvedItems,
      recentActivity
    })
  } catch (error) {
    await db.$disconnect()
    return NextResponse.json(
      { 
        status: 'error', 
        message: 'Failed to fetch dashboard stats',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}