import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { method } = body

    if (!method || !['nagad', 'bkash'].includes(method)) {
      return NextResponse.json({ error: 'Invalid payment method' }, { status: 400 })
    }

    const settings = await db.siteSettings.findFirst()
    
    if (!settings) {
      return NextResponse.json({ 
        error: `Payment method not configured by admin. Please contact support.` 
      }, { status: 400 })
    }

    const phoneNumber = method === 'nagad' ? settings.nagadNumber : settings.bkashNumber

    if (!phoneNumber || phoneNumber.trim() === '') {
      const methodName = method.charAt(0).toUpperCase() + method.slice(1)
      return NextResponse.json({ 
        error: `${methodName} payment is not configured yet. Please try again later or contact support.` 
      }, { status: 400 })
    }

    return NextResponse.json({ phoneNumber: phoneNumber.trim(), method, methodName: method.toUpperCase() })
  } catch (error) {
    console.error('Error getting payment info:', error)
    return NextResponse.json({ error: 'Failed to get payment information. Please try again.' }, { status: 500 })
  }
}
