import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST() {
  try {
    await db.$connect()

    // Get admin user and plugins category
    const adminUser = await db.user.findFirst({ where: { role: 'ADMIN' } })
    const pluginsCategory = await db.category.findFirst({ where: { slug: 'plugins' } })

    if (adminUser && pluginsCategory) {
      // Create a real test item with proper structure
      const testItem = await db.item.create({
        data: {
          title: 'Live Test Plugin',
          slug: 'live-test-plugin-' + Date.now(),
          description: 'This is a real test plugin uploaded through the system. It demonstrates the real-time file upload and management capabilities of GfxStore.',
          shortDesc: 'Real test plugin for demonstration',
          authorId: adminUser.id,
          categoryId: pluginsCategory.id,
          status: 'APPROVED', // Auto-approve for testing
          featured: true,
          downloads: 0,
          likes: 0,
          views: 0,
          price: 0
        }
      })

      // Create a version for the item
      await db.itemVersion.create({
        data: {
          itemId: testItem.id,
          version: '1.0.0',
          changelog: 'Initial release of real test plugin',
          fileName: 'real-test-plugin.jar',
          fileSize: 1024, // Simulate 1KB file
          filePath: '/uploads/real-test-plugin.jar',
          downloadUrl: `/api/download/${testItem.id}/real-test-plugin.jar`,
          isActive: true
        }
      })

      // Create a screenshot
      await db.screenshot.create({
        data: {
          itemId: testItem.id,
          url: '/placeholder-item.png', // Use placeholder for now
          alt: 'Real Test Plugin Screenshot',
          sortOrder: 0
        }
      })

      await db.$disconnect()

      return NextResponse.json({
        status: 'success',
        message: 'Real test item created successfully',
        item: {
          id: testItem.id,
          title: testItem.title,
          slug: testItem.slug
        }
      })
    } else {
      await db.$disconnect()
      return NextResponse.json(
        { error: 'Admin user or plugins category not found' },
        { status: 400 }
      )
    }
  } catch (error) {
    await db.$disconnect()
    return NextResponse.json(
      { 
        status: 'error', 
        message: 'Failed to create test item',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}