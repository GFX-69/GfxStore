import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    await db.$connect()

    // Get actual user and category IDs
    const adminUser = await db.user.findFirst({ where: { role: 'ADMIN' } })
    const pluginsCategory = await db.category.findFirst({ where: { slug: 'plugins' } })
    const textureCategory = await db.category.findFirst({ where: { slug: 'texture-packs' } })
    const mapsCategory = await db.category.findFirst({ where: { slug: 'maps' } })

    if (adminUser && pluginsCategory && textureCategory && mapsCategory) {
      // Create sample items with real IDs
      await db.item.create({
        data: {
          title: 'EssentialSpawn Plugin',
          slug: 'essential-spawn',
          description: 'A powerful spawn plugin with customizable spawn points, welcome messages, and teleportation features. Perfect for any server looking to enhance the new player experience.',
          shortDesc: 'Customizable spawn plugin with teleportation',
          authorId: adminUser.id,
          categoryId: pluginsCategory.id,
          status: 'APPROVED',
          featured: true,
          downloads: 15234,
          likes: 892,
          views: 45231,
          price: 0
        }
      })

      await db.item.create({
        data: {
          title: 'Medieval Texture Pack',
          slug: 'medieval-texture-pack',
          description: 'A beautiful medieval-themed texture pack that transforms your Minecraft world with authentic medieval architecture and textures.',
          shortDesc: 'Beautiful medieval-themed textures',
          authorId: adminUser.id,
          categoryId: textureCategory.id,
          status: 'APPROVED',
          featured: true,
          downloads: 8921,
          likes: 567,
          views: 23456,
          price: 0
        }
      })

      await db.item.create({
        data: {
          title: 'SkyBlock Adventure Map',
          slug: 'skyblock-adventure',
          description: 'A challenging SkyBlock map with custom islands, quests, and objectives. Test your survival skills in this unique sky-based adventure.',
          shortDesc: 'Challenging SkyBlock map with quests',
          authorId: adminUser.id,
          categoryId: mapsCategory.id,
          status: 'APPROVED',
          featured: false,
          downloads: 6543,
          likes: 432,
          views: 18976,
          price: 4.99
        }
      })
    }

    const itemCount = await db.item.count()
    await db.$disconnect()

    return NextResponse.json({
      status: 'success',
      message: 'Sample items created',
      itemCount
    })
  } catch (error) {
    await db.$disconnect()
    return NextResponse.json(
      { 
        status: 'error', 
        message: 'Failed to create sample items',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}