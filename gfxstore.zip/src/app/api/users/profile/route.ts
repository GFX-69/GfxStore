import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { writeFile, mkdir } from 'fs/promises'
import path from 'path'

export async function PUT(request: Request) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const formData = await request.formData()
    const bio = formData.get('bio') as string
    const socialLinksStr = formData.get('socialLinks') as string
    const avatarFile = formData.get('avatar') as File | null

    let socialLinks = {}
    try {
      socialLinks = socialLinksStr ? JSON.parse(socialLinksStr) : {}
    } catch (e) {
      socialLinks = {}
    }

    await db.$connect()

    const updateData: any = {
      bio,
      socialLinks
    }

    if (avatarFile && avatarFile.size > 0) {
      const uploadsDir = path.join(process.cwd(), 'uploads')
      await mkdir(uploadsDir, { recursive: true })
      
      const buffer = Buffer.from(await avatarFile.arrayBuffer())
      const fileName = `avatar-${session.user.id}-${Date.now()}.jpg`
      const filePath = path.join(uploadsDir, fileName)
      
      await writeFile(filePath, buffer)
      updateData.avatar = `/uploads/${fileName}`
    }

    const updatedProfile = await db.user.update({
      where: { id: session.user.id },
      data: updateData,
      include: {
        _count: {
          select: {
            items: true,
            downloadRecords: true,
            reviews: true
          }
        }
      }
    })

    await db.$disconnect()

    return NextResponse.json({
      id: updatedProfile.id,
      username: updatedProfile.username,
      email: updatedProfile.email,
      role: updatedProfile.role,
      avatar: updatedProfile.avatar,
      bio: updatedProfile.bio,
      socialLinks: updatedProfile.socialLinks,
      createdAt: updatedProfile.createdAt,
      _count: {
        items: updatedProfile._count.items,
        downloads: updatedProfile._count.downloadRecords,
        reviews: updatedProfile._count.reviews
      }
    })
  } catch (error) {
    console.error('Profile update error:', error)
    await db.$disconnect()
    return NextResponse.json(
      { 
        error: 'Failed to update profile',
        message: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}
