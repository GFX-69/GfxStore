import { createServer } from 'http'
import { parse } from 'url'
import next from 'next'
import { Server as SocketIOServer } from 'socket.io'
import { PrismaClient } from '@prisma/client'
import { getToken } from 'next-auth/jwt'
import { IncomingMessage } from 'http'
import { readFile } from 'fs/promises'
import { join } from 'path'
import { existsSync } from 'fs'
import { setupDatabase } from './src/lib/setup'

const dev = process.env.NODE_ENV !== 'production'
const hostname = '0.0.0.0'
const port = parseInt(process.env.PORT || '5000', 10)

const app = next({ dev, hostname, port })
const handle = app.getRequestHandler()
const prisma = new PrismaClient()

interface AuthenticatedUser {
  id: string
  username: string
  role: string
}

const chatUsers: Map<string, { id: string; username: string }> = new Map()

async function getAuthenticatedUser(req: IncomingMessage): Promise<AuthenticatedUser | null> {
  try {
    const token = await getToken({
      req: req as any,
      secret: process.env.NEXTAUTH_SECRET || process.env.SESSION_SECRET
    })
    
    if (!token?.sub) return null
    
    const user = await prisma.user.findUnique({
      where: { id: token.sub },
      select: { id: true, username: true, role: true }
    })
    
    return user
  } catch (error) {
    console.error('Auth error:', error)
    return null
  }
}

app.prepare().then(async () => {
  // Auto-setup database on first run
  await setupDatabase()

  const httpServer = createServer(async (req, res) => {
    try {
      const parsedUrl = parse(req.url!, true)
      
      // Serve static files from uploads directory
      if (parsedUrl.pathname?.startsWith('/uploads/')) {
        const filePath = join(process.cwd(), parsedUrl.pathname)
        if (existsSync(filePath)) {
          const fileBuffer = await readFile(filePath)
          const ext = filePath.split('.').pop()?.toLowerCase()
          const mimeTypes: Record<string, string> = {
            jpg: 'image/jpeg',
            jpeg: 'image/jpeg',
            png: 'image/png',
            gif: 'image/gif',
            webp: 'image/webp',
            jar: 'application/java-archive'
          }
          res.setHeader('Content-Type', mimeTypes[ext || ''] || 'application/octet-stream')
          res.setHeader('Cache-Control', 'public, max-age=3600')
          res.end(fileBuffer)
          return
        }
      }
      
      await handle(req, res, parsedUrl)
    } catch (err) {
      console.error('Error occurred handling', req.url, err)
      res.statusCode = 500
      res.end('internal server error')
    }
  })

  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: process.env.NODE_ENV === 'production' 
        ? [process.env.NEXTAUTH_URL || ''] 
        : '*',
      methods: ['GET', 'POST'],
      credentials: true
    },
    transports: ['websocket', 'polling']
  })

  const notificationNamespace = io.of('/notifications')
  const userSockets: Map<string, string> = new Map()

  // Simple chat on main namespace
  io.on('connection', async (socket) => {
    console.log('🔌 Client connected:', socket.id)
    let user: AuthenticatedUser | null = null

    // Try to get user from socket auth data (sent by client)
    const authData = (socket.handshake.auth as any)
    console.log('🔐 Auth data received:', authData)

    if (authData?.userId && authData?.username) {
      user = {
        id: authData.userId,
        username: authData.username,
        role: 'USER'
      }
      console.log('✅ User authenticated from client auth:', user.username)
    } else {
      try {
        user = await getAuthenticatedUser(socket.request)
        console.log('✅ Auth result for', socket.id, ':', user?.username || 'null')
      } catch (error) {
        console.error('❌ Auth error:', error)
      }
    }

    if (user) {
      chatUsers.set(socket.id, { id: user.id, username: user.username })
      console.log('👤 User added to chat:', user.username, 'Total users:', chatUsers.size)
      io.emit('onlineUsers', chatUsers.size)

      // Send recent messages
      try {
        const messages = await prisma.chatMessage.findMany({
          where: { roomId: null },
          include: { user: { select: { username: true } } },
          orderBy: { createdAt: 'desc' },
          take: 50
        })
        console.log('📨 Sending', messages.length, 'recent messages to', user.username)
        socket.emit('chatMessages', messages.reverse().map(m => ({
          id: m.id,
          username: m.user.username,
          message: m.content,
          timestamp: m.createdAt
        })))
      } catch (error) {
        console.error('❌ Error loading messages:', error)
      }
    } else {
      console.log('⚠️ User not authenticated, skipping chat for:', socket.id)
    }

    socket.on('sendMessage', async (data: { text: string, mentions?: string[] }) => {
      console.log('💬 Received message from', socket.id, ':', data)
      const userData = Array.from(chatUsers.entries()).find(([key]) => key === socket.id)?.[1]
      console.log('🔍 User data for', socket.id, ':', userData)
      
      if (!userData) {
        console.log('❌ No user data found, message rejected')
        return
      }
      
      if (!data?.text?.trim()) {
        console.log('❌ Empty message, rejected')
        return
      }

      try {
        console.log('💾 Saving message from', userData.username, 'Mentions:', data.mentions)
        const msg = await prisma.chatMessage.create({
          data: {
            userId: userData.id,
            content: data.text.trim().slice(0, 1000),
            type: 'PUBLIC',
            roomId: null
          },
          include: { user: { select: { username: true } } }
        })
        console.log('✅ Message saved:', msg.id)
        
        // Send notifications to mentioned users
        if (data.mentions && data.mentions.length > 0) {
          for (const mentionedUsername of data.mentions) {
            try {
              const mentionedUser = await prisma.user.findFirst({
                where: { username: mentionedUsername }
              })
              if (mentionedUser && (global as any).sendNotification) {
                await (global as any).sendNotification(mentionedUser.id, {
                  title: '💬 You were mentioned in chat',
                  content: `${userData.username} mentioned you: "${data.text.slice(0, 50)}..."`,
                  type: 'USER_MENTIONED'
                })
                console.log('📢 Mention notification sent to:', mentionedUsername)
              }
            } catch (mentionError) {
              console.error('Failed to send mention notification:', mentionError)
            }
          }
        }
        
        console.log('📣 Broadcasting message to all clients')
        io.emit('newMessage', {
          id: msg.id,
          username: msg.user.username,
          message: msg.content,
          timestamp: msg.createdAt,
          mentions: data.mentions
        })
      } catch (error) {
        console.error('❌ Failed to save message:', error)
      }
    })

    socket.on('disconnect', () => {
      chatUsers.delete(socket.id)
      io.emit('onlineUsers', chatUsers.size)
      console.log('Client disconnected:', socket.id)
    })
  })

  notificationNamespace.use(async (socket, next) => {
    try {
      const user = await getAuthenticatedUser(socket.request)
      if (user) {
        (socket as any).user = user
        next()
      } else {
        next(new Error('Authentication required'))
      }
    } catch (error) {
      next(new Error('Authentication failed'))
    }
  })

  notificationNamespace.on('connection', async (socket) => {
    const user = (socket as any).user as AuthenticatedUser
    
    if (!user) {
      socket.disconnect(true)
      return
    }

    console.log('Notification client connected:', socket.id, 'User:', user.username)

    userSockets.set(user.id, socket.id)
    socket.join(`user:${user.id}`)
    
    if (['ADMIN', 'SUPER_ADMIN', 'MODERATOR'].includes(user.role)) {
      socket.join('admins')
    }

    try {
      const notifications = await prisma.notification.findMany({
        where: { userId: user.id },
        orderBy: { createdAt: 'desc' },
        take: 50
      })
      socket.emit('notifications', notifications)
    } catch (error) {
      console.error('Error fetching notifications:', error)
    }

    socket.on('disconnect', () => {
      userSockets.delete(user.id)
      console.log('Notification client disconnected:', socket.id)
    })
  })

  const sendNotification = async (userId: string, notification: {
    title: string
    content: string
    type: string
    itemId?: string
  }) => {
    try {
      const savedNotification = await prisma.notification.create({
        data: {
          userId,
          title: notification.title,
          content: notification.content,
          type: notification.type as any,
          itemId: notification.itemId
        }
      })
      notificationNamespace.to(`user:${userId}`).emit('notification', savedNotification)
    } catch (error) {
      console.error('Error sending notification:', error)
    }
  }

  const broadcastToAdmins = (notification: any) => {
    notificationNamespace.to('admins').emit('adminNotification', notification)
  }

  ;(global as any).sendNotification = sendNotification
  ;(global as any).broadcastToAdmins = broadcastToAdmins
  ;(global as any).io = io

  httpServer.listen(port, hostname, () => {
    console.log(`> Server ready on http://${hostname}:${port}`)
    console.log(`> Real-time chat and notifications enabled (authenticated)`)
  })
})

process.on('SIGTERM', async () => {
  await prisma.$disconnect()
  process.exit(0)
})
