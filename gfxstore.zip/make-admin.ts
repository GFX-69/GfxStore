import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  try {
    const user = await prisma.user.update({
      where: { email: 'kakmare.pa@gmail.com' },
      data: { role: 'ADMIN' }
    })
    console.log(`✓ User ${user.username} (${user.email}) is now ADMIN`)
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : error)
  } finally {
    await prisma.$disconnect()
  }
}

main()
