# 🗄️ GfxStore Database Setup Guide

## 📋 Prerequisites
- Node.js 18+ installed
- PostgreSQL database access
- Prisma CLI installed
- Environment variables configured

## 🔧 Step 1: Configure Environment Variables

### ✅ **Update .env.local**
Make sure your `.env.local` file has the correct database connection strings:

```env
# Database
DATABASE_URL="postgresql://postgres.uoiudslabxgczdmzvayt:akashevan123@aws-1-ap-southeast-1.pooler.supabase.com:6543/postgres"
DIRECT_URL="postgresql://postgres.uoiudslabxgczdmzvayt:akashevan123@aws-1-ap-southeast-1.pooler.supabase.com:5432/postgres"

# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://uoiudslabxgczdmzvayt.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IjcxR1LlQm9mXoHrG5fzY1XhJccT51kRxOkILmGVc

# Filebase/S3 Storage
S3_API_ENDPOINT=https://s3.filebase.com
S3_ACCESS_KEY=3448F6BC334AC4919C64
S3_SECRET_KEY=PpQ0BNVJJuRWFMozAbRZNgjy3FTRxTxRxOkILmGVc
S3_REGION=us-east-1
S3_BUCKET=gfxstore-storage

# IPFS
IPFS_RPC_ENDPOINT=https://rpc.filebase.io
IPFS_API_KEY=MzQ0OEY2QzRkQjI0ODI1MjU4ZQyNjU4ZT5KJxOkILmGVc

# NextAuth
NEXTAUTH_SECRET=your-secret-key-here
NEXTAUTH_URL=http://localhost:3000

# App Configuration
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

## 🔧 Step 2: Generate Prisma Client

```bash
npx prisma generate
```

## 🔧 Step 3: Apply Database Schema

```bash
npx prisma db push
```

## 🔧 Step 4: Seed Initial Data

```bash
npx prisma db seed
```

## 📊 Step 5: Verify Database Connection

```bash
npx prisma db pull
```

## 🎯 **Alternative: Manual SQL Schema Setup**

If you prefer to use the SQL schema I provided, you can:

1. **Create the database manually:**
   ```sql
   -- Connect to your PostgreSQL database
   \i database-schema.sql
   ```

2. **Then generate Prisma schema:**
   ```bash
   npx prisma generate
   ```

3. **Then push the schema:**
   ```bash
   npx prisma db push
   ```

## 🚨 **Common Issues & Solutions**

### **Issue: "Database connection failed"
**Solution:**
- Check if your PostgreSQL server is running
- Verify the connection string format
- Ensure your database user has proper permissions
- Check if the database exists: `CREATE DATABASE gfxstore;`

### **Issue: "Prisma commands failed"
**Solution:**
- Ensure you're in the project root directory
- Check if environment variables are set correctly
- Run `npx prisma status` to check connection

### **Issue: "Schema mismatch"
**Solution:**
- Delete the existing database: `DROP DATABASE gfxstore;`
- Then run the schema creation script again

---

## 📝 **Database Tables Overview**

Your database will include these tables:

### **👥 Core Tables**
- **users** - User accounts with authentication
- **profiles** - Extended user information
- **categories** - Content categories
- **subcategories** - Subcategories under main categories
- **items** - Main content items (plugins, mods, etc.)
- **item_versions** - Version control
- **screenshots** - Item media
- **reviews** - User ratings and feedback
- **downloads** - Download tracking
- **chat_messages** - Real-time chat
- **notifications** - User notifications
- **server_plans** - Hosting plans
- **site_settings** - Global configuration

### **🔗️ Advanced Features**
- **UUID Primary Keys** - Better security and performance
- **JSONB Columns** - Flexible metadata storage
- **Proper Indexes** - Optimized queries
- **Triggers** - Automatic timestamp updates
- **Constraints** - Data integrity enforcement
- **Default Data** - Pre-populated with categories and settings

---

## 🚀 **Ready for Development**

Once set up, your database will be ready for the complete GfxStore platform with all features including:
- User management and authentication
- Content upload and versioning
- Real-time chat and notifications
- Analytics and reporting
- Admin controls and moderation
- SEO optimization
- File storage with CDN

The schema is production-ready and optimized for high traffic with thousands of users and content items! 🚀