# 🚀 GfxStore - Super Easy Setup Guide For Beginners

**Don't worry! Follow these simple steps and your marketplace will be running in 5 minutes!**

---

## ✅ Step 1: Download and Open Project

Copy and paste this command:

```bash
git clone <your-repo-url>
cd GfxStore
```

---

## ✅ Step 2: Install Everything

Copy and paste this ONE command:

```bash
npm install
```

**⏱️ Wait 2-5 minutes...**  
You'll see text scrolling down. That's normal! ✅

---

## ✅ Step 3: Create Settings File

Copy and paste this command:

```bash
touch .env.local
```

Now open `.env.local` file and paste this:

```
DATABASE_URL="file:./gfxstore.db"
NEXTAUTH_URL="http://localhost:5000"
NEXTAUTH_SECRET="my-secret-key-12345-abcde-very-long-string"
```

**Save the file!** (Ctrl+S or Cmd+S)

---

## ✅ Step 4: Setup Database

Copy and paste this command:

```bash
npm run prisma db push
```

When asked "Do you want to create it now?" → Type: `y` and press Enter

Then copy and paste this:

```bash
npx tsx prisma/seed.ts
```

**✅ Done! Your database is ready!**

---

## ✅ Step 5: Build the Project

Copy and paste this command:

```bash
npm run build
```

**Wait for it to finish...**

---

## ✅ Step 6: Start Your App!

Copy and paste this command:

```bash
npm run dev
```

You'll see something like:
```
> Server ready on http://0.0.0.0:5000
```

---

## 🎉 Open Your App!

Go to your browser and open:

### 🌐 **http://localhost:5000**

**Login with:**
- Email: `admin@gfxstore.com`
- Password: `admin123`

---

## 🛑 How to Stop the App

Press `Ctrl+C` in the terminal

---

## 🔄 How to Run Again

Just copy and paste:

```bash
npm run dev
```

---

## 📱 What You Can Do Now

✅ Login to admin panel  
✅ Upload Minecraft content  
✅ Browse marketplace  
✅ Create user accounts  
✅ Manage everything from admin panel

---

## 🆘 Something Went Wrong?

### Error: "Port 5000 already in use"
```bash
# Press Ctrl+C to stop other apps
# Then run again
npm run dev
```

### Error: "Module not found"
```bash
# Run this
npm install
npm run dev
```

### Database errors
```bash
# Run these
npm run prisma db push
npx tsx prisma/seed.ts
npm run dev
```

---

## 📝 Quick Command List

| What to do | Command |
|-----------|---------|
| Start app | `npm run dev` |
| Stop app | `Ctrl+C` |
| See database | `npx prisma studio` |
| Rebuild | `npm run build` |
| Fresh start | `npm install && npm run dev` |

---

## 🚀 Deploy to VPS (Later)

When ready, check the main README.md for VPS instructions!

---

## ✨ That's It!

You now have a working Minecraft marketplace! 🎮

**Need help?** Check the main README.md for detailed instructions.

---

**Happy building! 🚀**
