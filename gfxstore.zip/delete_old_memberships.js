const { PrismaClient } = require('@prisma/client')
const db = new PrismaClient()

async function deleteOld() {
  try {
    const deleted = await db.membership.deleteMany({
      where: {
        roleName: { in: ['GOLD', 'PLATINUM', 'DIAMOND'] }
      }
    })
    console.log(`✅ Deleted ${deleted.count} old memberships`)
    
    const remaining = await db.membership.findMany()
    console.log(`📊 Remaining memberships: ${remaining.length}`)
    remaining.forEach(m => console.log(`  - ${m.name} (${m.roleName}) $${m.price}`))
  } catch (err) {
    console.error('Error:', err.message)
  } finally {
    await db.$disconnect()
  }
}
deleteOld()
