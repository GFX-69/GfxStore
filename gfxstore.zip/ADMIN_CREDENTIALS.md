# Admin Login Credentials

**Email:** admin@gfxstore.com  
**Password:** admin123

These credentials are automatically created when the database is seeded.

## Pro User Credentials (if available)
**Email:** pro@gfxstore.com  
**Password:** pro123

## How to Login
1. Go to `/auth/signin`
2. Enter the email and password above
3. Click "Sign In"

## Reset Admin Password
If you need to reset, run:
```bash
npm run db:seed
```

This will reset all test users including admin.
