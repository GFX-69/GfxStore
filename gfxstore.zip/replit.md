# GfxStore - Minecraft Content Marketplace

## Overview

GfxStore is a comprehensive marketplace platform for Minecraft content, similar to Modrinth. Users can upload, download, and manage various types of Minecraft content including plugins, mods, texture packs, maps, shaders, server setups, and Bedrock Edition files. The platform features a role-based access control system, real-time chat, notifications, and comprehensive analytics.

## Recent Changes (Nov 30, 2025)

- Fixed TypeScript type errors with NextAuth session types
- Implemented secure real-time Socket.io server for chat and notifications
- Added authenticated WebSocket connections using NextAuth JWT tokens
- Fixed upload system with file type/size validation and transactional handling
- Configured application to run on port 5000 with integrated Socket.io
- Seeded database with content categories
- Enhanced homepage with dynamic stats, featured items section, and improved UI
- Expanded admin dashboard with user management, item moderation, analytics, and settings
- Fixed profile page with avatar upload, bio editing, and social links
- Fixed dashboard page with user stats and item management
- Created public stats API endpoint for homepage statistics
- Added admin user with credentials (admin@gfxstore.com / admin123)
- Fixed session handling to prevent redirect loops on protected pages

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Tooling**
- Next.js 15 with App Router for server-side rendering and routing
- TypeScript 5 for type safety across the codebase
- React 18 with server and client components pattern

**UI Layer**
- Tailwind CSS 4 for utility-first styling with custom theme configuration
- shadcn/ui component library built on Radix UI primitives
- Dark/light theme support via next-themes
- Responsive design with mobile-first approach

**State Management**
- NextAuth.js sessions for authentication state
- React Context API for notifications and chat state
- TanStack Query for server state management and caching

**Routing Structure**
- `/` - Landing page with hero section and feature highlights
- `/browse` - Content discovery with filtering and search
- `/upload` - Content upload interface for creators
- `/profile` - User profile management
- `/dashboard` - Personal analytics and content management
- `/admin` - Administrative controls and moderation
- `/analytics` - Platform-wide analytics dashboard

### Backend Architecture

**API Layer**
- Next.js API Routes for serverless functions
- RESTful endpoints organized by domain (items, users, auth, admin)
- Custom WebSocket server for real-time features

**Authentication & Authorization**
- NextAuth.js v4 with JWT strategy
- Credentials provider with bcryptjs password hashing
- Role-based access control (User, Creator, Moderator, Admin, Super Admin)
- Session management with secure cookies

**Data Access Pattern**
- Prisma ORM as the database abstraction layer
- Repository pattern for data access
- Connection pooling for optimized database connections
- Direct URL for migrations, pooled URL for queries

**Real-time Services**
- Socket.IO server integrated with Next.js custom server
- Separate chat service running on dedicated port
- WebSocket connections for chat, notifications, and live updates
- User presence tracking and typing indicators

### Database Architecture

**ORM & Schema**
- Prisma as the database toolkit
- PostgreSQL via Supabase for production database
- 15+ interconnected tables modeling the domain

**Key Entities**
- Users: Authentication, profiles, roles, and permissions
- Items: Content with versioning, metadata, and status tracking
- Categories/Subcategories: Hierarchical organization of content
- Reviews/Ratings: User feedback and scoring system
- Downloads: Tracking and analytics for content distribution
- Files: Version control with S3 references
- Screenshots: Image galleries for items
- ChatMessages/Notifications: Real-time communication

**Relationships**
- One-to-many: Users to Items, Items to Files
- Many-to-many: Items to Tags (via join table)
- Hierarchical: Categories to Subcategories

### File Storage System

**Storage Provider**
- Filebase (S3-compatible) as primary storage backend
- IPFS integration for decentralized content addressing
- AWS SDK v3 for S3 operations

**Upload Strategy**
- Presigned URLs for secure client-side uploads
- Chunked upload support for large files
- File validation and virus scanning hooks
- Automatic thumbnail generation for images

**File Types Supported**
- Server files: .jar (plugins/mods)
- Resource packs: .zip
- World files: .zip, .mcworld
- Bedrock addons: .mcpack, .mcaddon
- Screenshots: .jpg, .png, .webp

**Download Mechanism**
- Presigned download URLs with expiration
- Download count tracking
- Bandwidth optimization via CDN-ready architecture

### External Dependencies

**Database**
- Supabase PostgreSQL (managed PostgreSQL service)
- Connection pooling via PgBouncer
- Direct connection for schema migrations

**File Storage**
- Filebase S3-compatible object storage
- IPFS gateway for decentralized access
- Regional endpoints for performance

**Authentication**
- NextAuth.js for OAuth and credentials flows
- JWT tokens for stateless sessions
- Secure session management

**Real-time Communication**
- Socket.IO for WebSocket connections
- Custom server implementation (server.ts)
- Separate microservice for chat (mini-services/chat-service)

**Third-party Libraries**
- React Hook Form with Zod for form validation
- Framer Motion for animations (if used)
- MDX Editor for rich text content
- Radix UI for accessible component primitives

**Development Tools**
- ESLint for code quality
- TypeScript compiler for type checking
- Prisma CLI for database operations
- tsx for TypeScript execution in development