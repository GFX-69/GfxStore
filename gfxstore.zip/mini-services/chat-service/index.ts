import { createServer } from 'http'
import { Server } from 'socket.io'
import cors from 'cors'

const PORT = 3001

const httpServer = createServer()
const io = new Server(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
})

// Store connected users
const connectedUsers = new Map<string, { id: string; username: string; role: string }>()
// Store chat messages
const chatMessages: Array<{
  id: string
  username: string
  message: string
  timestamp: Date
  type: 'public' | 'admin' | 'system'
}> = []

io.on('connection', (socket) => {
  console.log(`User connected: ${socket.id}`)

  // Handle user joining
  socket.on('join', (userData: { id: string; username: string; role: string }) => {
    connectedUsers.set(socket.id, userData)
    
    // Send existing messages to new user
    socket.emit('messages', chatMessages)
    
    // Broadcast user joined message
    const joinMessage = {
      id: Date.now().toString(),
      username: 'System',
      message: `${userData.username} joined the chat`,
      timestamp: new Date(),
      type: 'system' as const
    }
    chatMessages.push(joinMessage)
    io.emit('message', joinMessage)
    
    // Update online users count
    io.emit('users', Array.from(connectedUsers.values()))
  })

  // Handle new messages
  socket.on('message', (data: { message: string; type?: 'public' | 'admin' }) => {
    const user = connectedUsers.get(socket.id)
    if (!user) return

    const chatMessage = {
      id: Date.now().toString(),
      username: user.username,
      message: data.message,
      timestamp: new Date(),
      type: data.type || 'public'
    }

    chatMessages.push(chatMessage)
    
    // Keep only last 100 messages
    if (chatMessages.length > 100) {
      chatMessages.shift()
    }

    io.emit('message', chatMessage)
  })

  // Handle typing indicators
  socket.on('typing', (isTyping: boolean) => {
    const user = connectedUsers.get(socket.id)
    if (!user) return

    socket.broadcast.emit('userTyping', {
      username: user.username,
      isTyping
    })
  })

  // Handle disconnection
  socket.on('disconnect', () => {
    const user = connectedUsers.get(socket.id)
    if (user) {
      connectedUsers.delete(socket.id)
      
      const leaveMessage = {
        id: Date.now().toString(),
        username: 'System',
        message: `${user.username} left the chat`,
        timestamp: new Date(),
        type: 'system' as const
      }
      chatMessages.push(leaveMessage)
      io.emit('message', leaveMessage)
      io.emit('users', Array.from(connectedUsers.values()))
    }
    
    console.log(`User disconnected: ${socket.id}`)
  })
})

// Start server
httpServer.listen(PORT, () => {
  console.log(`Chat service running on port ${PORT}`)
})